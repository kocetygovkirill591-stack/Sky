# NORD V11 — Raid Event Interaction Fix

Based on V10. Preserves V10 danger loot rarity and combat scaling.

Changes:
- Restored the proven delegated click path used in the previously working raid build.
- Added direct inline `onclick` to every raid event choice as a WebView-safe fallback.
- Removed the extra pointerup/touchend raid event interception that could suppress Android click delivery.
- Raised event layer z-index without changing gameplay logic.
