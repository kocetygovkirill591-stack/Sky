package com.kirill.nordrpg

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = true
            settings.allowFileAccessFromFileURLs = true
            settings.allowUniversalAccessFromFileURLs = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    // Native fallback in case Android WebView throttles page timers.
                    handler.postDelayed({
                        view.evaluateJavascript(
                            "(function(){try{if(window.__nordFinishBoot)window.__nordFinishBoot(!!window.__NORD_APP_READY);else{document.body.classList.remove('booting');var b=document.getElementById('bootScreen');if(b){b.classList.add('hide');setTimeout(function(){b.remove()},900)}}}catch(e){}})();",
                            null
                        )
                    }, 9000)
                }
            }
            setBackgroundColor(0x00000000)
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
