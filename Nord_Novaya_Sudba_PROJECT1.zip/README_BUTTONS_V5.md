# NORD — BUTTON FEEDBACK V5

This update changes only button interaction feedback.

- All regular buttons keep one neutral style at rest.
- A real tap shows a visible cyan press/glow animation for ~1.2 s.
- The action is replayed after a short 620 ms delay so the user can see the press before navigation/rerender.
- Dragging/scrolling cancels the press and suppresses accidental clicks.
- Music, world sounds, tavern, market, arena, profile, map, combat, and world-engine data are otherwise untouched.
