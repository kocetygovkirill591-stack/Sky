# NORD Stage 2.8 — NPC Memory + Important Jarl Orders

Changes:
- NPC memory: repeated conversations, help, gifts, walks and accepted quests are remembered in `knownPeople[].memory`.
- Relationship/trust state persists locally with the existing save system.
- NPC dialog now has contextual lines and new relationship actions.
- Tavern friendship button is hidden immediately after friendship is accepted.
- Ruler/Jarl dialog includes a separate important-order action.
- Important orders use multi-stage quests and real combat against stronger enemies.
- Rewards are larger but major orders are limited by a separate cooldown and do not bypass the normal active-quest limit.
- Existing weather, music, world sounds, tavern scene, location scenes, quest limits and NPC alignment remain unchanged.

Validation:
- Node syntax checked for game.js, main.js, index_script.js, script_1.js and _final_inline_1.js.
- ZIP integrity checked after packaging.
