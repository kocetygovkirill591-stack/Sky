# Stage 2.7 — Clean location scenes

Each location now renders from the clean world art set under `app/src/main/assets/world/`, while NPCs are created only by the live hotspot layer. The old UI screenshot-style location images are no longer used by the scene renderer. Whiterun uses a dedicated scenic crop plus a small visual cover for the one baked label still present in the source art.

No NPC label is intended to be part of the background scene anymore; interactive NPCs are DOM buttons created by the world engine and remain clickable.
