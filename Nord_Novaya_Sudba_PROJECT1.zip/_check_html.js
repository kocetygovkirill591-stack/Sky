
(function(){
  var start=Date.now(), total=8200, timer=null, done=false;
  var screen=document.getElementById('bootScreen'), bar=document.getElementById('bootProgress'), pct=document.getElementById('bootPercent'), msg=document.getElementById('bootMessage'), scene=document.getElementById('bootScene');
  var scenes=['Северные горы','Ночной Скайрим','Туманный лес','Дорога на Вайтран'];
  var messages=['Мир просыпается...','Загружаются города и дороги...','Судьбы жителей переплетаются...','Гильдии готовят новые дела...','Жители выходят на улицы...','Последние приготовления...'];
  if(scene) scene.textContent=scenes[Math.floor(Math.random()*scenes.length)];
  var loadingAudio=null;
  try{ loadingAudio=new Audio('music/loading_nord.ogg'); loadingAudio.preload='auto'; loadingAudio.loop=true; loadingAudio.volume=.42; try{window.stopWorldAmbient&&window.stopWorldAmbient();}catch(e){} var ap=loadingAudio.play(); if(ap&&ap.catch)ap.catch(function(){}); window.__nordLoadingAudio=loadingAudio; }catch(e){}
  function finish(){
    if(done)return; done=true; if(timer)clearInterval(timer);
    if(bar)bar.style.width='100%'; if(pct)pct.textContent='100%'; if(msg)msg.textContent='Добро пожаловать в Скайрим';
    if(screen){screen.classList.add('ready');setTimeout(function(){screen.classList.add('hide');document.body.classList.remove('booting');setTimeout(function(){if(screen&&screen.parentNode)screen.parentNode.removeChild(screen);},950);},600);}
    try{if(window.__nordLoadingAudio){window.__nordLoadingAudio.pause();window.__nordLoadingAudio=null;}}catch(e){}
    try{if(window.updateMusicForScreen)window.updateMusicForScreen('mainmenu');}catch(e){}
    // Never start world ambience while the loading screen is visible.
    try{if(window.stopWorldAmbient)window.stopWorldAmbient();}catch(e){}
    setTimeout(function(){
      try{if(window.updateAmbientForScreen && !document.body.classList.contains('booting')){window.updateAmbientForScreen(window.p&&window.p.characterCreated?'world':'create');}}catch(e){}
    },1000);
  }
  function tick(){var v=Math.min(100,Math.floor((Date.now()-start)/total*100));if(bar)bar.style.width=v+'%';if(pct)pct.textContent=v+'%';if(msg)msg.textContent=messages[Math.min(messages.length-1,Math.floor(v/18))];if(v>=100)finish();}
  tick(); timer=setInterval(tick,80); setTimeout(finish,8600);
})();


const main=document.getElementById('main');



const KEY='nord_rpg_save_v7';
const OLD_KEY='nord_rpg_save_v6';
const LEGACY_KEY='nord_rpg_save_v5';
const LEGACY2_KEY='nord_rpg_save_v2';
const races=['Норд','Имперец','Эльф','Тёмный эльф','Орк','Каджит','Аргонианин'];
const heroPortraits={
  'Норд':['nord_m1','nord_m2','nord_m3'],
  'Имперец':['imperial_m1','imperial_m2','imperial_m3'],
  'Эльф':['elf_m1','elf_m2','elf_m3'],
  'Тёмный эльф':['delf_m1','delf_m2','delf_m3'],
  'Орк':['orc_m1','orc_m2','orc_m3'],
  'Каджит':['khajiit_m1','khajiit_m2','khajiit_m3'],
  'Аргонианин':['argon_m1','argon_m2','argon_m3']
};
const heroPortraitsFemale={
  'Норд':['nord_f1','nord_f2','nord_f3'],
  'Имперец':['imperial_f1','imperial_f2','imperial_f3'],
  'Эльф':['elf_f1','elf_f2','elf_f3'],
  'Тёмный эльф':['delf_f1','delf_f2','delf_f3'],
  'Орк':['orc_f1','orc_f2','orc_f3'],
  'Каджит':['khajiit_f1','khajiit_f2','khajiit_f3'],
  'Аргонианин':['argon_f1','argon_f2','argon_f3']
};
function portraitList(r=p?.race,g=p?.gender){return g==='Женский'?(heroPortraitsFemale[r]||[]):(heroPortraits[r]||[])}
function portraitPath(k){const maleKeys=Object.values(heroPortraits).flat();return maleKeys.includes(String(k))?`heroes_male_v3/${String(k)}.jpg?v=30`:`heroes_v2/${String(k)}.jpg?v=30`}

const attrDefs=[['Сила','💪'],['Ловкость','🏹'],['Выносливость','❤️'],['Интеллект','📖'],['Воля','🔷'],['Харизма','💛']];
const raceBonuses={'Норд':{Сила:2,Выносливость:1},'Имперец':{Харизма:2,Воля:1},'Эльф':{Интеллект:2,Ловкость:1},'Тёмный эльф':{Интеллект:2,Воля:1},'Орк':{Сила:2,Выносливость:1},'Каджит':{Ловкость:2,Харизма:1},'Аргонианин':{Выносливость:2,Ловкость:1}};
const originOptions={
'Северные земли':{icon:'🏔️',desc:'Суровый край. Знаешь холод и северные дороги.',bonus:{Выносливость:1},skills:{'Одноручное оружие':2}},
'Город':{icon:'🏙️',desc:'Вырос среди торговцев, стражи и городской жизни.',bonus:{Харизма:1},skills:{'Красноречие':3}},
'Лесная деревня':{icon:'🌲',desc:'Охота, следопытство и жизнь рядом с природой.',bonus:{Ловкость:1},skills:{'Стрельба':3}},
'Шахтёрское поселение':{icon:'⛏️',desc:'С детства знаешь руду, камень и тяжёлый труд.',bonus:{Сила:1},skills:{'Алхимия':1,'Тяжёлая броня':2}},
'Дворянский дом':{icon:'🏰',desc:'Обучение манерам, истории и придворным правилам.',bonus:{Харизма:1,Интеллект:1},skills:{'Красноречие':2}},
'Военный лагерь':{icon:'⚔️',desc:'Жизнь среди солдат научила дисциплине и строю.',bonus:{Воля:1},skills:{'Блокирование':2,'Одноручное оружие':1}}
};
const pastOptions={
'Воин':{icon:'🛡️',desc:'Бывший солдат. Знаешь цену дисциплине.',skills:{'Одноручное оружие':5,'Блокирование':3}},
'Охотник':{icon:'🐾',desc:'Следопыт и охотник, привыкший выживать в лесу.',skills:{'Стрельба':6,'Скрытность':2}},
'Ученик мага':{icon:'📜',desc:'Учился у наставника, но ещё не раскрыл весь потенциал.',skills:{'Магия разрушения':6}},
'Вор':{icon:'🗝️',desc:'Знаешь замки, карманы и тёмные улицы.',skills:{'Взлом':4,'Скрытность':4}},
'Кузнец':{icon:'🔨',desc:'Работа с металлом научила терпению и силе.',skills:{'Тяжёлая броня':3,'Алхимия':3}},
'Купец':{icon:'💰',desc:'Знаешь цены, людей и силу хорошей сделки.',skills:{'Красноречие':6}},
'Бродяга':{icon:'🧳',desc:'Странствовал по северным дорогам и выживал как мог.',skills:{'Скрытность':2,'Красноречие':2,'Стрельба':2}}
};
const personalityOptions={'Воин':{icon:'⚔️',desc:'Прямолинейный и смелый.',bonus:{Сила:1}},'Мудрец':{icon:'🦉',desc:'Спокойный и наблюдательный.',bonus:{Интеллект:1}},'Изгой':{icon:'🌑',desc:'Привык полагаться только на себя.',bonus:{Воля:1}},'Добрый':{icon:'🤝',desc:'Легче завоёвывает доверие.',bonus:{Харизма:1}},'Хитрый':{icon:'🐍',desc:'Любит обходные пути.',bonus:{Ловкость:1}},'Честь':{icon:'🛡️',desc:'Слово важнее золота.',bonus:{Воля:1}}};
const signs={'Воин':{icon:'⚔️',desc:'Сила и стойкость.',bonus:{Выносливость:2}},'Маг':{icon:'🔮',desc:'Чутьё к магии.',bonus:{Интеллект:2}},'Вор':{icon:'🗝️',desc:'Тень и ловкость.',bonus:{Ловкость:2}},'Любовник':{icon:'❤️',desc:'Легче находишь общий язык.',bonus:{Харизма:2}},'Тень':{icon:'🌑',desc:'Лучше действуешь незаметно.',bonus:{Ловкость:1,Воля:1}},'Лорд':{icon:'👑',desc:'Влияние и уверенность.',bonus:{Харизма:1,Воля:1}},'Конь':{icon:'🐎',desc:'Выносливость в путешествиях.',bonus:{Выносливость:2}}};
const talents={'Крепкое тело':{icon:'❤️',desc:'+10% к максимальному здоровью.'},'Быстрый ум':{icon:'🧠',desc:'+10% к получаемому опыту.'},'Тихая тень':{icon:'🌑',desc:'+10% к скрытности.'},'Меткий глаз':{icon:'🎯',desc:'+10% к урону луком.'},'Прирождённый лидер':{icon:'👑',desc:'Лучшие отношения с союзниками и торговцами.'}};
const weaknesses={'Боязнь нежити':{icon:'💀',desc:'Урон от нежити +8%.',bonus:'При первом повышении уровня получаешь +1 очко развития.'},'Слабая магия':{icon:'🔮',desc:'Максимум магии -10.',bonus:'+2 к Силе на старте.'},'Плохая выносливость':{icon:'🟢',desc:'Расход выносливости +10%.',bonus:'+2 к Интеллекту на старте.'},'Алчность':{icon:'💰',desc:'Честные решения дают меньше репутации.',bonus:'+10% найденного золота.'},'Вспыльчивость':{icon:'🔥',desc:'Некоторые диалоги могут привести к драке.',bonus:'Сильная атака +5% урона.'},'Низкое красноречие':{icon:'🗣️',desc:'Труднее убеждать людей.',bonus:'+2 к Одноручному оружию.'}};
const combatStyles={'Меч и щит':{icon:'🛡️',desc:'Надёжная защита.',skills:{'Одноручное оружие':3,'Блокирование':3},gear:[['Железный меч',1],['Железный щит',1]]},'Два оружия':{icon:'⚔️',desc:'Быстрые агрессивные атаки.',skills:{'Одноручное оружие':6},gear:[['Железный кинжал',2]]},'Лук':{icon:'🏹',desc:'Дистанционный бой.',skills:{'Стрельба':6},gear:[['Железный кинжал',1]]},'Магия':{icon:'🔮',desc:'Удар из магической школы.',skills:{'Магия разрушения':6},gear:[['Свиток магии',1]]},'Двуручное':{icon:'🪓',desc:'Мощные удары ценой скорости.',skills:{'Двуручное оружие':6},gear:[['Древнее оружие',1]]},'Скрытность':{icon:'🥷',desc:'Избегай боя и бей неожиданно.',skills:{'Скрытность':5,'Взлом':2},gear:[['Железный кинжал',1]]}};
const alignments={'Законопослушный':{icon:'⚖️',desc:'Порядок и закон.'},'Нейтральный':{icon:'🧭',desc:'Сам решаешь, что правильно.'},'Авантюрист':{icon:'☠️',desc:'Риск ради свободы и богатства.'},'Преступник':{icon:'🩸',desc:'Правила существуют для других.'}};
const cityNames=['Вайтран','Ривервуд','Рифтен','Виндхельм','Солитьюд','Фолкрит','Морфал','Данстар','Айварстед','Рорикстед','Хелген','Драконий мост','Картвастен','Шорс-Стон','Каменные холмы','Торговый тракт','Ледяной берег','Черный перевал','Высокий Хротгар','Заброшенный форт','Снежная пещера','Старые руины','Туманный лес','Озеро Хьялмарк','Красный перевал','Долина охотников'];
const world={
'Вайтран':{type:'Город',desc:'Главный торговый город равнин. Рынок, дворец ярла, таверны и кузницы.',exits:['Ривервуд','Рифтен','Фолкрит','Рорикстед'],npcs:['Ярл Балгруф','Кузнец Адрианна','Караванщик Лод'],enemy:'Бандит',quests:['Защита торгового каравана','Кража из склада'],house:500},
'Ривервуд':{type:'Деревня',desc:'Деревня у реки. Здесь можно купить припасы и услышать слухи о руинах.',exits:['Вайтран','Хелген','Туманный лес'],npcs:['Гердур','Ортор','Фаэндаль'],enemy:'Волк',quests:['Пропавшая охотница'],house:350},
'Рифтен':{type:'Город',desc:'Город каналов и торговцев. Здесь сильны воры и подпольные сделки.',exits:['Вайтран','Фолкрит','Красный перевал'],npcs:['Бриньольф','Мариса','Торговец Мадези'],enemy:'Бандит',quests:['Долг торговца','Тайный заказ'],house:700},
'Виндхельм':{type:'Город',desc:'Древний северный город у ледяного моря. Здесь процветают кузницы.',exits:['Данстар','Вайтран','Ледяной берег'],npcs:['Вунферт','Кузнец Орит','Капитан стражи'],enemy:'Бандит',quests:['Караван в снегах'],house:650},
'Солитьюд':{type:'Город',desc:'Столичный город с дворцами, гильдиями и богатыми торговцами.',exits:['Драконий мост','Морфал','Озеро Хьялмарк'],npcs:['Тит Медиус','Фальк Огненный Борода','Сейда'],enemy:'Наемник',quests:['Письмо ярлу','Защита порта'],house:1000},
'Фолкрит':{type:'Город',desc:'Лесной город. Охотники, лесорубы и следопыты знают эти земли лучше всех.',exits:['Рифтен','Вайтран','Туманный лес'],npcs:['Нари','Денгейр','Охотник Сонд'],enemy:'Волк',quests:['След зверя','Охрана тракта'],house:450},
'Морфал':{type:'Город',desc:'Туманный болотный край. Алхимики собирают здесь редкие растения.',exits:['Солитьюд','Озеро Хьялмарк','Данстар'],npcs:['Лейла','Алхимик Лами','Мастер болот'],enemy:'Ведьма',quests:['Травы болот'],house:550},
'Данстар':{type:'Город',desc:'Снежный портовый город. Мороз здесь не отпускает даже летом.',exits:['Виндхельм','Морфал','Ледяной берег'],npcs:['Скалд','Капитан Хальд','Торговец Редди'],enemy:'Скелет',quests:['Ледяная шахта'],house:500},
'Aйварстед':{type:'Деревня',desc:'Поселение у подножия Высокого Хротгара.',exits:['Вайтран','Высокий Хротгар'],npcs:['Климмек','Жена лесника'],enemy:'Волк',quests:['Письмо монахам'],house:300},
'Рорикстед':{type:'Деревня',desc:'Маленькая фермерская деревня посреди равнин.',exits:['Вайтран','Драконий мост'],npcs:['Рорик','Юрга'],enemy:'Бандит',quests:['Пропавший урожай'],house:300},
'Хелген':{type:'Руины',desc:'Пограничный город после великой катастрофы. Вокруг много разбойников.',exits:['Ривервуд','Заброшенный форт'],npcs:['Выживший солдат','Бродячий торговец'],enemy:'Разбойник',quests:['Очистить руины'],house:250},
'Драконий мост':{type:'Поселение',desc:'Мост между северными дорогами. Здесь встречаются торговцы и наемники.',exits:['Солитьюд','Рорикстед','Картвастен'],npcs:['Хозяйка трактира','Старый ветеран'],enemy:'Наемник',quests:['Охрана моста'],house:400},
'Картвастен':{type:'Шахтерский поселок',desc:'Горный поселок с рудниками и суровыми шахтерами.',exits:['Драконий мост','Каменные холмы'],npcs:['Кузнец Ральф','Шахтер Эйнар'],enemy:'Паукообразный жук',quests:['Руда для кузницы'],house:380},
'Шорс-Стон':{type:'Поселок',desc:'Оловянные шахты и кузницы. Торговцы любят это место за руду.',exits:['Рифтен','Красный перевал'],npcs:['Шахтер Халдин','Скупщик руды'],enemy:'Паукообразный жук',quests:['Пропавшая руда'],house:420},
'Каменные холмы':{type:'Дикая местность',desc:'Каменистая долина с редкими стоянками и древними курганами.',exits:['Картвастен','Шорс-Стон','Старые руины'],npcs:['Охотник-отшельник'],enemy:'Скелет',quests:['Кости в кургане'],house:0},
'Торговый тракт':{type:'Дорога',desc:'Главный путь караванов между городами.',exits:['Вайтран','Рифтен','Солитьюд'],npcs:['Купец Алдар','Наемная охрана'],enemy:'Бандит',quests:['Пропавший обоз'],house:0},
'Ледяной берег':{type:'Побережье',desc:'Ледяной берег с обломками кораблей и пиратскими тайниками.',exits:['Виндхельм','Данстар','Черный перевал'],npcs:['Пират-перебежчик'],enemy:'Пират',quests:['Карта затонувшего корабля'],house:0},
'Черный перевал':{type:'Дикая местность',desc:'Мрачный перевал. Дорога опасна ночью.',exits:['Ледяной берег','Красный перевал'],npcs:['Следопыт'],enemy:'Разбойник',quests:['Ночной патруль'],house:0},
'Высокий Хротгар':{type:'Святилище',desc:'Древний монастырь в горах. Здесь изучают голос и древние искусства.',exits:['Айварстед','Старые руины'],npcs:['Учитель Голоса','Паломник'],enemy:'Драугр',quests:['Испытание голоса'],house:0},
'Заброшенный форт':{type:'Руины',desc:'Старый военный форт, занятый преступниками.',exits:['Хелген','Туманный лес','Черный перевал'],npcs:['Заключенный','Контрабандист'],enemy:'Разбойник',quests:['Очистить форт'],house:0},
'Снежная пещера':{type:'Пещера',desc:'Лабиринт под снегом. Здесь слышен вой и стук костей.',exits:['Снежный тракт'],npcs:['Пленник'],enemy:'Драугр',quests:['Знак из глубины'],house:0},
'Старые руины':{type:'Руины',desc:'Древний комплекс с тайными дверьми, ловушками и магическими залами.',exits:['Каменные холмы','Высокий Хротгар','Заброшенный форт'],npcs:['Исследователь'],enemy:'Драугр',quests:['Сердце руин'],house:0},
'Туманный лес':{type:'Лес',desc:'Лес с туманом, редкими кострами и скрытыми тропами.',exits:['Ривервуд','Фолкрит','Заброшенный форт'],npcs:['Следопытка Элия'],enemy:'Лесной призрак',quests:['Охота в тумане'],house:0},
'Озеро Хьялмарк':{type:'Болото',desc:'Большое озеро и болота с редкими травами и тайными хижинами.',exits:['Морфал','Солитьюд'],npcs:['Алхимик','Рыбак'],enemy:'Ведьма',quests:['Черный лотос'],house:0},
'Красный перевал':{type:'Перевал',desc:'Красные скалы и опасные тропы между восточными дорогами.',exits:['Рифтен','Шорс-Стон','Черный перевал'],npcs:['Караванщик'],enemy:'Наемник',quests:['Защита каравана'],house:0},
'Долина охотников':{type:'Дикая местность',desc:'Скрытая долина с богатыми охотничьими угодьями.',exits:['Фолкрит','Каменные холмы'],npcs:['Охотник Бран'],enemy:'Медведь',quests:['Большая добыча'],house:0}
};
// Fallback alias for accidental Cyrillic typo key
world['Айварстед']=world['Aйварстед']; delete world['Aйварстед'];
const enemyDb={
'Бандит':{image:'bandit',lvl:2,hp:55,icon:'🗡️',desc:'Обычный разбойник с железным оружием.',skills:['Удар','Слабый блок'],loot:[['Золото',25],['Железный кинжал',0.45]]},
'Разбойник':{image:'bandit',lvl:3,hp:68,icon:'🏴',desc:'Опытный преступник, который умеет использовать грязные приемы.',skills:['Удар','Кровотечение'],loot:[['Золото',35],['Зелье лечения',0.35]]},
'Волк':{image:'wolf',lvl:2,hp:42,icon:'🐺',desc:'Дикий волк, быстрый и опасный в первом раунде.',skills:['Укус','Рывок'],loot:[['Золото',8],['Шкура волка',0.7]]},
'Скелет':{image:'skeleton',lvl:4,hp:72,icon:'💀',desc:'Неупокоенный воин, устойчивый к страху.',skills:['Рубящий удар','Костяной щит'],loot:[['Золото',30],['Старый кость-клинок',0.3]]},
'Драугр':{image:'skeleton',lvl:6,hp:105,icon:'🧟',desc:'Древний северный воин из кургана.',skills:['Тяжёлый удар','Боевой крик'],loot:[['Золото',60],['Древнее оружие',0.35]]},
'Ведьма':{image:'cultist',lvl:7,hp:88,icon:'🧙',desc:'Темная заклинательница болот.',skills:['Ледяной осколок','Проклятие'],loot:[['Золото',70],['Свиток магии',0.45]]},
'Наемник':{image:'knight',lvl:5,hp:82,icon:'🛡️',desc:'Бывший солдат, продающий свой меч.',skills:['Удар','Блок','Контратака'],loot:[['Золото',55],['Железный шлем',0.4]]},
'Пират':{image:'bandit',lvl:5,hp:76,icon:'⚓',desc:'Грабитель морских путей.',skills:['Кинжал','Грязный удар'],loot:[['Золото',65],['Янтарь',0.4]]},
'Паукообразный жук':{image:'goblin',lvl:3,hp:48,icon:'🕷️',desc:'Ядовитое шахтное создание.',skills:['Укус','Яд'],loot:[['Золото',12],['Ядовитый мешок',0.5]]},
'Лесной призрак':{image:'cultist',lvl:8,hp:95,icon:'👻',desc:'Бесплотный дух, которому почти не нужен воздух.',skills:['Туман','Проклятие'],loot:[['Золото',80],['Эктоплазма',0.7]]},
'Медведь':{image:'wolf',lvl:4,hp:90,icon:'🐻',desc:'Большой бурый зверь.',skills:['Рывок','Размах'],loot:[['Золото',18],['Шкура медведя',0.75]]}};

// ===== NORD DANGER V1 — roadside danger: 70+ random enemy variants =====
const DANGER_ENEMY_VARIANTS=[
 ['Щитник-бандит','bandit',2,46,'🗡️'],['Северный головорез','bandit',4,72,'🗡️'],['Ветеран-бандит','bandit',7,108,'⚔️'],['Разбойник с топором','bandit',5,82,'🪓'],['Разбойник-лучник','bandit',6,76,'🏹'],['Главарь разбойников','bandit',11,155,'👑'],
 ['Дорожный наёмник','knight',4,70,'🛡️'],['Закалённый наёмник','knight',8,112,'🛡️'],['Капитан наёмников','knight',13,188,'👑'],['Восточный мечник','knight',6,92,'⚔️'],['Тяжёлый мечник','knight',10,146,'⚔️'],['Щитовой ветеран','knight',12,172,'🛡️'],
 ['Лесной волк','wolf',2,40,'🐺'],['Серый волк','wolf',3,52,'🐺'],['Матёрый волк','wolf',6,78,'🐺'],['Вожак стаи','wolf',10,132,'🐺'],['Белый волк','wolf',8,104,'🐺'],
 ['Лесной медведь','wolf',4,88,'🐻'],['Старый медведь','wolf',8,138,'🐻'],['Яростный медведь','wolf',12,196,'🐻'],['Лютый саблезуб','wolf',9,126,'🐯'],['Снежный саблезуб','wolf',14,205,'🐯'],
 ['Крыса-гигант','goblin',2,32,'🐀'],['Пещерный скивер','goblin',3,45,'🐀'],['Чумной скивер','goblin',7,70,'🐀'],['Ядовитый скивер','goblin',9,96,'🐀'],
 ['Морозный паук','goblin',4,54,'🕷️'],['Древний морозный паук','goblin',9,124,'🕷️'],['Гигантский паук','goblin',12,170,'🕷️'],['Матка пауков','goblin',16,238,'🕷️'],
 ['Скелет-разведчик','skeleton',3,58,'💀'],['Скелет-воин','skeleton',5,88,'💀'],['Скелет-ветеран','skeleton',9,132,'💀'],['Скелет-берсерк','skeleton',13,184,'💀'],['Костяной страж','skeleton',17,255,'💀'],
 ['Драугр-разведчик','skeleton',6,102,'☠️'],['Драугр-воин','skeleton',8,138,'☠️'],['Драугр-ветеран','skeleton',12,190,'☠️'],['Драугр-палач','skeleton',16,272,'☠️'],['Драугр-воевода','skeleton',20,365,'👑'],
 ['Фалмер-разведчик','goblin',7,108,'👹'],['Фалмер-охотник','goblin',10,156,'👹'],['Фалмер-воин','goblin',13,210,'👹'],['Фалмер-чемпион','goblin',18,315,'👑'],
 ['Чаурус-разведчик','goblin',7,100,'🦂'],['Чаурус-охотник','goblin',11,164,'🦂'],['Чаурус-воин','goblin',15,232,'🦂'],['Чаурус-жнец','goblin',20,350,'🦂'],
 ['Тролль','wolf',9,180,'🧌'],['Ледяной тролль','wolf',13,248,'🧌'],['Горный тролль','wolf',17,330,'🧌'],['Древний тролль','wolf',22,470,'🧌'],
 ['Болотная ведьма','cultist',8,112,'🧙'],['Ледяная ведьма','cultist',12,168,'🧙'],['Тёмная ведьма','cultist',16,246,'🧙'],['Ведьма-колдунья','cultist',21,360,'🧙'],
 ['Молодой вампир','cultist',9,118,'🧛'],['Ночной вампир','cultist',14,196,'🧛'],['Вампир-рыцарь','cultist',18,292,'🧛'],['Древний вампир','cultist',24,460,'👑'],
 ['Двемерский паук','goblin',8,122,'⚙️'],['Двемерская сфера','goblin',11,165,'⚙️'],['Усиленная двемерская сфера','goblin',16,252,'⚙️'],['Двемерский центурион','knight',22,440,'🤖'],['Древний центурион','knight',27,620,'👑'],
 ['Призрачный воин','cultist',10,138,'👻'],['Ледяной призрак','cultist',14,205,'👻'],['Проклятый рыцарь','knight',19,325,'👻'],['Дух кургана','cultist',23,430,'👻'],
 ['Культист','cultist',4,66,'☠️'],['Культист-воин','cultist',8,112,'☠️'],['Культист-мастер','cultist',14,210,'☠️'],['Жрец древнего культа','cultist',20,340,'☠️']
];
DANGER_ENEMY_VARIANTS.forEach(([name,image,lvl,hp,icon])=>{
  if(enemyDb[name]) return;
  enemyDb[name]={image,lvl,hp,icon,desc:'Случайный противник на дорогах и в опасных местах.',skills:['Удар','Особый приём'],loot:[['Золото',0.92]]};
});

const DANGER_EVENTS=[
 {id:'ambush',title:'Засада на дороге',icon:'⚔️',text:'Из кустов раздаётся свист стрел. Тебя окружили.',actions:[['fight','⚔️ Принять бой','Полный случайный противник.'],['run','🏃 Попытаться уйти','Шанс уйти без боя, но можно получить удар.']]},
 {id:'traveler',title:'Раненый путник',icon:'🩸',text:'На обочине лежит раненый человек. Он просит воды и помощи.',actions:[['help','🤝 Помочь','Опыт и хорошая репутация.'],['search','🔎 Обыскать','Есть шанс найти вещь, но можно потерять репутацию.'],['ignore','🚶 Пройти мимо','Без риска.']]},
 {id:'chest',title:'Старый дорожный сундук',icon:'🧰',text:'Полузарытый сундук покрыт грязью и снегом.',actions:[['open','🔓 Открыть','Очень редкий шанс на предмет.'],['check','🪤 Проверить ловушку','Ловкость уменьшает риск.'],['leave','🚶 Оставить','Безопасный выбор.']]},
 {id:'shrine',title:'Древний камень',icon:'🗿',text:'На камне вырезаны руны. Внутри чувствуется магия.',actions:[['touch','✋ Коснуться','Можно получить благословение или проклятие.'],['pray','🙏 Преклониться','Небольшое восстановление.'],['leave','🚶 Не трогать','Без последствий.']]},
 {id:'fog',title:'Туманная низина',icon:'🌫️',text:'Туман скрывает дорогу. В нём слышно тяжёлое дыхание.',actions:[['enter','🌫️ Войти','Очень широкий разброс силы врага.'],['wait','⏳ Подождать','Шанс избежать встречи.']]},
 {id:'caravan',title:'Остановленный караван',icon:'🐎',text:'Караванщик просит помочь отбиться от нападающих.',actions:[['defend','🛡️ Защитить караван','Бой и хорошая награда.'],['negotiate','💬 Договориться','Красноречие может решить всё.'],['leave','🚶 Уйти','Без риска.']]},
 {id:'collapse',title:'Трещина в дороге',icon:'🪨',text:'Земля под ногами обваливается. Ты почти падаешь вниз.',actions:[['jump','🏃 Прыгнуть','Можешь потерять здоровье.'],['climb','🪢 Забраться','Ловкость помогает.'],['leave','↩️ Отойти','Без риска.']]},
 {id:'hunter',title:'След охотника',icon:'🏹',text:'Следы крови ведут в лес. Здесь недавно кто-то сражался.',actions:[['follow','🔎 Идти по следу','Можно встретить зверя или найти добычу.'],['search','🌲 Осмотреть лагерь','Редкий шанс на вещь.'],['leave','🚶 Пройти мимо','Без риска.']]},
 {id:'roar',title:'Рёв вдалеке',icon:'🐉',text:'Горы содрогнулись. Что-то огромное поднялось в небе.',actions:[['hide','🫥 Спрятаться','Обычно безопасно.'],['look','👁️ Посмотреть','Шанс увидеть редкое существо.'],['run','🏃 Бежать','Можно получить травму.']]},
 {id:'merchant',title:'Странный торговец',icon:'🧥',text:'Незнакомец показывает тебе запечатанный свёрток.',actions:[['buy','💰 Купить тайник','Дорого, но внутри может быть редкость.'],['threat','⚔️ Пригрозить','Шанс получить предмет или бой.'],['leave','🚶 Уйти','Безопасно.']]},
 {id:'altar',title:'Осквернённый алтарь',icon:'☠️',text:'От алтаря идёт холод. Кажется, он питается чужой силой.',actions:[['cleanse','✨ Очистить','Нужна сила воли, риск проклятия.'],['touch','🩸 Коснуться','Высокий риск — высокая награда.'],['leave','🚶 Уйти','Безопасно.']]},
 {id:'campfire',title:'Заброшенный костёр',icon:'🔥',text:'Костёр недавно погас. Рядом лежит мешок.',actions:[['search','🔎 Обыскать','Редкий шанс на предмет.'],['rest','🛏️ Передохнуть','Восстановишь здоровье, но можешь привлечь врага.'],['leave','🚶 Идти дальше','Безопасно.']]}
];
function dangerReady(){
  p.dangerUsesDay = Number(p.dangerUsesDay||0);
  p.dangerUsesDate = Number(p.dangerUsesDate||0);
  const day=gameDays();
  if(p.dangerUsesDate!==day){p.dangerUsesDate=day;p.dangerUsesDay=0;}
  return p.dangerUsesDay < 5;
}
function dangerUsesLeft(){dangerReady();return Math.max(0,5-Number(p.dangerUsesDay||0))}
function dangerRarityRoll(){
  // Danger loot is intentionally stingy: mythic is a true jackpot.
  const r=Math.random();
  if(r<0.0005)return 'mythic';      // 0.05% of successful item drops
  if(r<0.0100)return 'epic';        // 0.95%
  if(r<0.0550)return 'rare';        // 4.50%
  return 'uncommon';                // remaining non-common drops
}
function dangerEventReward(chance=0.035){
  if(Math.random()>chance)return null;
  const tier=dangerRarityRoll();
  let keys=Object.keys(itemDb||{}).filter(n=>itemDb[n]?.rarity===tier);
  // Never fall back upward: an early game danger event must not accidentally grant a mythic.
  if(!keys.length && tier==='mythic') keys=Object.keys(itemDb||{}).filter(n=>itemDb[n]?.rarity==='epic');
  if(!keys.length && tier==='epic') keys=Object.keys(itemDb||{}).filter(n=>itemDb[n]?.rarity==='rare');
  if(!keys.length && tier==='rare') keys=Object.keys(itemDb||{}).filter(n=>itemDb[n]?.rarity==='uncommon');
  if(!keys.length)return null;
  const name=keys[Math.floor(Math.random()*keys.length)];
  addItem(name,1);return name;
}
function dangerRandomEnemy(){
  const names=Object.keys(enemyDb).filter(n=>DANGER_ENEMY_VARIANTS.some(x=>x[0]===n));
  const name=names[Math.floor(Math.random()*names.length)];
  const base=enemyDb[name];
  // Preserve the monster's intended level; only a tiny variance prevents repetition.
  const mult=.96+Math.random()*.08;
  return {name,hp:Math.max(22,Math.round(base.hp*mult)),lvl:Math.max(1,Math.round(base.lvl*mult)),icon:base.icon};
}
function dangerCombatStats(e){
  const playerLvl=Math.max(1,Number(p.level||1));
  const enemyLvl=Math.max(1,Number(e.lvl||1));
  const delta=Math.max(0,enemyLvl-playerLvl);
  const baseHp=Math.max(24,Number(e.hp||24));
  // Level difference is now a real combat wall.
  const hpScale=Math.min(25,1+delta*.32+delta*delta*.012);
  const atkScale=Math.min(6,1+delta*.10+delta*delta*.006);
  const baseAttack=7+enemyLvl*1.65;
  const hp=Math.round(baseHp*hpScale);
  const armor=Math.round(2+enemyLvl*.9+delta*.85+delta*delta*.035);
  const attack=Math.round(baseAttack*atkScale);
  return {hp,armor,attack,delta,enemyLvl,hpScale,atkScale};
}
function startDangerEncounter(reason='Опасность'){
  const d=dangerRandomEnemy();
  const base=enemyDb[d.name];
  const stats=dangerCombatStats({...base,lvl:d.lvl,hp:d.hp});
  const dangerStatus=stats.delta>=8?'☠️ КРИТИЧЕСКАЯ РАЗНИЦА УРОВНЕЙ: враг намного сильнее тебя.':stats.delta>=4?'⚠️ Враг значительно сильнее тебя.':stats.delta>=2?'⚠️ Враг сильнее тебя.':'Ты встретил противника своего диапазона.';
  p.battle={enemy:d.name,hp:stats.hp,maxHp:stats.hp,round:1,poison:0,playerBlock:0,status:`Ты столкнулся с опасностью. ${dangerStatus}`,mode:'danger',dangerReason:reason,enemyArmor:stats.armor,enemyAttack:stats.attack,enemyLevel:stats.enemyLvl,levelDelta:stats.delta};
  addLog(`⚠️ ${reason}: ${d.name} (уровень ${d.lvl}) выходит на дорогу!`,'bad');save();showScreen('combat');
}
function renderDanger(){
  const recent=(p.worldEvents||[]).filter(e=>e.city===p.loc&&String(e.text||'').includes('Опасность')).slice(0,6).map(e=>`<div class="danger-history">${esc(e.text)}<small>День ${e.day}</small></div>`).join('')||'<div class="muted">Опасные встречи здесь ещё не случались.</div>';
  dangerReady();
  const uses=Number(p.dangerUsesDay||0), left=Math.max(0,5-uses);
  main.innerHTML=`<section class="danger-hub"><div class="danger-hero"><div class="danger-kicker">NORD • ДИКИЕ ДОРОГИ</div><h1>⚠️ ОПАСНОСТЬ</h1><p>${esc(p.loc)} — никогда не знаешь, кого встретишь за следующим поворотом. Враги выбираются случайно: от слабого скивера до древнего центуриона.</p><div class="danger-count"><b>70+</b><span>разновидностей врагов</span></div></div><section class="card danger-panel"><h3>🌲 Исследовать окрестности</h3><div class="danger-rules"><span>🎲 Случайный враг</span><span>💀 Возможна смерть</span><span>🎒 Лут по редкости • мифическая почти не выпадает</span><span>📖 События с выбором</span><span>⚔️ Разница уровней резко усиливает врага</span><span>⏳ ${left}/5 заходов сегодня</span></div><button class="btn danger-main-btn" ${left<=0?'disabled':''} onclick="dangerExplore()">${left>0?'⚔️ ИДТИ НА ОПАСНОСТЬ':'⏳ СЕГОДНЯ ПОПЫТКИ ЗАКОНЧИЛИСЬ'}</button><button class="btn" style="margin-top:8px" onclick="showScreen('world')">↩️ Вернуться в город</button></section><section class="card danger-panel"><h3>📜 Последние происшествия</h3>${recent}</section></section>`;
}
window.dangerExplore=function(){
  if(!dangerReady()){showToast('На сегодня хватит опасности','Лимит: 5 заходов за игровые сутки.','warn','⏳',2200);renderDanger();return;}
  p.dangerUsesDay=Number(p.dangerUsesDay||0)+1;p.dangerUsesDate=gameDays();
  const ev=DANGER_EVENTS[Math.floor(Math.random()*DANGER_EVENTS.length)];
  p.dangerEvent=ev;save();renderDangerEvent(ev);
};
function renderDangerEvent(ev){main.innerHTML=`<section class="danger-hub"><section class="hero"><div class="danger-kicker">СЛУЧАЙНОЕ СОБЫТИЕ</div><h2>${ev.icon} ${esc(ev.title)}</h2><p class="danger-event-text">${esc(ev.text)}</p></section><section class="card danger-panel"><div class="raid-event-choices">${ev.actions.map(([id,label,meta])=>`<button class="raid-choice" onclick="dangerChoose('${id}')"><b>${label}</b><small>${meta}</small></button>`).join('')}</div></section><button class="btn" style="margin-top:10px" onclick="showScreen('danger')">↩️ Назад</button></section>`}
function dangerOutcome(title,text,icon='📜',tone='info'){
  p.worldEvents=p.worldEvents||[];
  p.worldEvents.unshift({city:p.loc,text:`⚠️ Опасность: ${text}`,day:p.day,cls:tone});
  save();
  renderDanger();
  const old=document.getElementById('dangerOutcomeModal'); if(old) old.remove();
  const modal=document.createElement('div'); modal.id='dangerOutcomeModal'; modal.className='danger-outcome-backdrop';
  modal.innerHTML=`<div class="danger-outcome ${tone}"><div class="icon">${icon}</div><h3>${esc(title)}</h3><p>${esc(text)}</p><button type="button" onclick="document.getElementById('dangerOutcomeModal')?.remove()">Продолжить</button></div>`;
  document.body.appendChild(modal);
}
window.dangerOutcome=dangerOutcome;
window.dangerChoose=function(action){
  const ev=p.dangerEvent;if(!ev)return; p.dangerEvent=null;
  if(ev.id==='ambush'&&action==='fight'){startDangerEncounter('Засада на дороге');return}
  if(ev.id==='ambush'&&action==='run'){if(Math.random()<.58){dangerOutcome('Ты ушёл от засады','Стрелы просвистели мимо. На этот раз тебе повезло.','🏃','good')}else startDangerEncounter('Стрелы из засады');return}

  if(ev.id==='traveler'&&action==='help'){advanceTime(18,'Помощь раненому путнику');gainXp(18);dangerOutcome('Путник спасён','Ты помог раненому и получил опыт.','🤝','good');return}
  if(ev.id==='traveler'&&action==='search'){if(Math.random()<.08){const item=dangerEventReward(1);dangerOutcome(item?'Найдена вещь':'Ничего не найдено',item?`Ты нашёл: ${item}.`:'В вещах почти ничего ценного нет.','🎒',item?'good':'info')}else dangerOutcome('Ничего не найдено','В вещах почти ничего ценного нет.','🔎','info');return}
  if(ev.id==='traveler'&&action==='ignore'){dangerOutcome('Ты прошёл мимо','Путник остаётся на дороге, а ты продолжаешь путь.','🚶','info');return}

  if(ev.id==='chest'&&action==='open'){
    if(Math.random()<.08){const item=dangerEventReward(1);dangerOutcome(item?'Сундук открылся':'Сундук пуст',item?`Внутри найдено: ${item}.`:'Внутри ничего ценного.','📦',item?'good':'info')}
    else if(Math.random()<.22){const dmg=18+Math.floor(Math.random()*30);p.hp=Math.max(1,p.hp-dmg);dangerOutcome('Ловушка сработала',`Ты получил ${dmg} урона. Сундук оказался заминирован.`,'🪤','bad')}
    else dangerOutcome('Ничего ценного','Сундук стар и почти пуст.','📦','info');
    return
  }
  if(ev.id==='chest'&&action==='check'){if(Math.random()<.8)dangerOutcome('Ловушка обезврежена','Ты заметил механизм и снял опасность.','🪤','good');else{p.hp=Math.max(1,p.hp-18);dangerOutcome('Механизм сработал','Ловушка успела ранить тебя.','🪤','bad')}return}
  if(ev.id==='chest'&&action==='leave'){dangerOutcome('Ты не рискнул','Сундук остаётся лежать в снегу.','🚶','info');return}

  if(ev.id==='shrine'&&action==='touch'){if(Math.random()<.06){const item=dangerEventReward(1);dangerOutcome(item?'Дар алтаря':'Алтарь промолчал',item?`Ты получил: ${item}.`:'Никакой награды не последовало.','✨',item?'good':'info')}else if(Math.random()<.4){p.hp=Math.max(1,p.hp-25);dangerOutcome('Проклятие','Древняя сила отняла здоровье.','☠️','bad')}else{p.hp=Math.min(heroMaxHp(),p.hp+20);dangerOutcome('Благословение','Твоё здоровье восстановилось.','✨','good')}return}
  if(ev.id==='shrine'&&action==='pray'){p.hp=Math.min(heroMaxHp(),p.hp+30);advanceTime(12,'Молитва у древнего камня');dangerOutcome('Молитва услышана','Ты восстановил здоровье и чувствуешь облегчение.','🙏','good');return}
  if(ev.id==='shrine'&&action==='leave'){dangerOutcome('Ты не тронул камень','Ничего не произошло.','🚶','info');return}

  if(ev.id==='fog'&&action==='enter'){startDangerEncounter('Туман скрывал врага');return}
  if(ev.id==='fog'&&action==='wait'){if(Math.random()<.65)dangerOutcome('Туман рассеялся','Ты переждал опасный момент и продолжил путь.','🌫️','good');else startDangerEncounter('Что-то вышло из тумана');return}

  if(ev.id==='caravan'&&action==='defend'){startDangerEncounter('Нападение на караван');return}
  if(ev.id==='caravan'&&action==='negotiate'){if((p.attributes?.Харизма||5)+(p.skills?.['Красноречие']||0)/8>10){p.gold+=24;gainXp(20);dangerOutcome('Переговоры удались','Нападающие отступили. Ты получил 24 золота и опыт.','💬','good')}else startDangerEncounter('Переговоры провалились');return}
  if(ev.id==='caravan'&&action==='leave'){dangerOutcome('Ты ушёл от каравана','Ты не вмешался в конфликт.','🚶','info');return}

  if(ev.id==='collapse'&&action==='jump'){const dmg=10+Math.floor(Math.random()*35);p.hp=Math.max(1,p.hp-dmg);dangerOutcome('Травма','Ты выбрался, но получил травму.','🪨','bad');return}
  if(ev.id==='collapse'&&action==='climb'){const dmg=Math.random()<.25?22:5;p.hp=Math.max(1,p.hp-dmg);dangerOutcome(dmg>5?'Уступ оказался опасным':'Ты выбрался',dmg>5?`Ты получил ${dmg} урона.`:'Ловкость помогла выбраться без серьёзных последствий.','🪢',dmg>5?'bad':'good');return}
  if(ev.id==='collapse'&&action==='leave'){dangerOutcome('Ты отошёл','Опасный участок остался позади.','↩️','info');return}

  if(ev.id==='hunter'&&action==='follow'){if(Math.random()<.58)startDangerEncounter('След привёл к зверю');else{const item=dangerEventReward(.7);dangerOutcome(item?'Найдена добыча':'След оборвался',item?`След вывел тебя к находке: ${item}.`:'Никаких следов ценного не осталось.','🏹',item?'good':'info')}return}
  if(ev.id==='hunter'&&action==='search'){const item=dangerEventReward(.9);dangerOutcome(item?'Найдена вещь':'Лагерь пуст',item?`В лагере найдено: ${item}.`:'Здесь ничего полезного не осталось.','🌲',item?'good':'info');return}
  if(ev.id==='hunter'&&action==='leave'){dangerOutcome('Ты пошёл своей дорогой','Лес остаётся позади.','🚶','info');return}

  if(ev.id==='roar'&&action==='hide'){dangerOutcome('Опасность прошла','Ты затаился, и существо тебя не заметило.','🫥','good');return}
  if(ev.id==='roar'&&action==='look'){if(Math.random()<.25){gainXp(30);dangerOutcome('Ты увидел дракона','Огромная тень пронеслась над горами. Ты получил опыт.','🐉','good')}else dangerOutcome('Ничего не видно','Небо скрыто облаками и туманом.','🌌','info');return}
  if(ev.id==='roar'&&action==='run'){p.hp=Math.max(1,p.hp-12);dangerOutcome('Ты получил травму','Бегство оказалось не таким безопасным.','🏃','bad');return}

  if(ev.id==='merchant'&&action==='buy'){if(p.gold<60){dangerOutcome('Не хватает золота','Для покупки тайника нужно 60 золота.','💰','bad');return}p.gold-=60;if(Math.random()<.12){const item=dangerEventReward(1);dangerOutcome(item?'Тайник открылся':'Тайник пуст',item?`Ты нашёл: ${item}.`:'Внутри только старый мусор.','📜',item?'good':'info')}else dangerOutcome('Ничего редкого','За 60 золота ты получил старый мусор. Шансы были очень малы.','📜','info');return}
  if(ev.id==='merchant'&&action==='threat'){if(Math.random()<.45){const item=dangerEventReward(.9);dangerOutcome(item?'Торговец оставил вещь':'Торговец вызвал охрану',item?`Торговец оставляет тебе ${item} и исчезает.`:'Он отступает, но охрана уже рядом.','⚔️',item?'good':'bad')}else startDangerEncounter('Торговец оказался бойцом');return}
  if(ev.id==='merchant'&&action==='leave'){dangerOutcome('Сделка сорвалась','Ты уходишь, не ввязываясь в странную сделку.','🚶','info');return}

  if(ev.id==='altar'&&action==='cleanse'){if(Math.random()<.65){p.hp=Math.min(heroMaxHp(),p.hp+15);gainXp(12);dangerOutcome('Алтарь очищен','Ты снял часть проклятия и восстановил здоровье.','✨','good')}else{p.hp=Math.max(1,p.hp-20);dangerOutcome('Проклятие усилилось','Ритуал обернулся против тебя.','☠️','bad')}return}
  if(ev.id==='altar'&&action==='touch'){if(Math.random()<.08){const item=dangerEventReward(1);dangerOutcome(item?'Скрытая награда':'Алтарь молчит',item?`Ты получил: ${item}.`:'Сила алтаря не ответила.','🩸',item?'good':'info')}else startDangerEncounter('Осквернённый алтарь пробудил стража');return}
  if(ev.id==='altar'&&action==='leave'){dangerOutcome('Ты ушёл от алтаря','Ты не стал рисковать.','🚶','info');return}

  if(ev.id==='campfire'&&action==='search'){const item=dangerEventReward(.9);dangerOutcome(item?'Найдена вещь':'Ничего не найдено',item?`В мешке: ${item}.`:'Только зола и старый мусор.','🎒',item?'good':'info');return}
  if(ev.id==='campfire'&&action==='rest'){if(Math.random()<.35)startDangerEncounter('Шорох у костра');else{p.hp=Math.min(heroMaxHp(),p.hp+35);dangerOutcome('Ты передохнул','Здоровье частично восстановлено.','🔥','good')}return}
  if(ev.id==='campfire'&&action==='leave'){dangerOutcome('Ты идёшь дальше','Ты не стал задерживаться у костра.','🚶','info');return}
  dangerOutcome('Решение принято','Ты сделал выбор и продолжаешь путь.','📜','info');
};

const guilds=[
{id:'companions',name:'Соратники',icon:'⚔️',desc:'Воинская гильдия. Испытания, тренировки и охота на чудовищ.',trial:'Победи в испытательном поединке и докажи, что умеешь сражаться.',mission:'Охота на опасного зверя'},
{id:'mages',name:'Коллегия магов',icon:'🔮',desc:'Изучение школ магии и древних заклинаний.',trial:'Покажи контроль над магией и выбери верные заклинания.',mission:'Исследовать магический источник'},
{id:'thieves',name:'Гильдия воров',icon:'🗝️',desc:'Кражи, взломы, тайные сделки и черный рынок.',trial:'Пройди испытание на скрытность, ловкость и взлом.',mission:'Добыть редкий товар без тревоги'},
{id:'dark',name:'Тёмное братство',icon:'☠️',desc:'Опасная сеть наемных убийц.',trial:'Докажи хладнокровие и умение работать в тени.',mission:'Тайный ночной заказ'},
{id:'guards',name:'Стража',icon:'🛡️',desc:'Порядок, патрули и охота на преступников.',trial:'Докажи знание закона и умение защищать граждан.',mission:'Патруль и задержание преступника'}
];
// Городские гильдии и ордена — у каждого города свои специализации и испытания.
guilds.push(
{id:'hunters',name:'Братство охотников',icon:'🏹',city:'Фолкрит',desc:'Охотники, следопыты и защитники дорог. Добыча, награды за зверей и разведка.',trial:'Найди след зверя, выбери правильную тропу и вернись с добычей.',mission:'Охота на опасного зверя'},
{id:'miners',name:'Союз шахтёров',icon:'⛏️',city:'Картвастен',desc:'Шахты, руда, кузнечное дело и защита горных поселений.',trial:'Определи руду, выдержи опасный участок шахты и помоги шахтёру.',mission:'Очистить шахту и вернуть руду'},
{id:'alchemists',name:'Круг алхимиков',icon:'⚗️',city:'Морфал',desc:'Алхимия, редкие ингредиенты, яды и лечебные составы.',trial:'Определи три ингредиента и приготовь безопасное зелье.',mission:'Собрать редкие болотные ингредиенты'},
{id:'sailors',name:'Северная гильдия мореходов',icon:'⚓',city:'Данстар',desc:'Морские пути, рыбалка, караваны, контрабанда и спасательные рейсы.',trial:'Проведи судно через шторм и выбери безопасный маршрут.',mission:'Сопроводить груз через ледяной берег'},
{id:'merchants',name:'Торговая палата',icon:'💰',city:'Солитьюд',desc:'Караваны, контракты, крупные сделки и влияние на цены городов.',trial:'Сделай выгодную сделку и не дай себя обмануть в переговорах.',mission:'Заключить выгодный торговый контракт'},
{id:'warriors_east',name:'Щит Востока',icon:'🪓',city:'Виндхельм',desc:'Суровые бойцы, охрана караванов и защита восточных дорог.',trial:'Выдержи поединок и защити раненого товарища.',mission:'Защитить восточный караван'},
{id:'voice',name:'Орден Голоса',icon:'🗻',city:'Высокий Хротгар',desc:'Древняя школа голоса, дисциплины и духовных испытаний.',trial:'Испытай терпение, знание и силу воли перед голосом.',mission:'Пройти испытание горного пути'}
);

const cityGuilds={
'Вайтран':['companions','guards'],
'Рифтен':['thieves'],
'Виндхельм':['warriors_east','guards'],
'Солитьюд':['mages','merchants'],
'Фолкрит':['dark','hunters'],
'Морфал':['alchemists'],
'Данстар':['sailors'],
'Картвастен':['miners'],
'Высокий Хротгар':['voice'],
};

const guildTrials={
companions:{questions:[['Что важнее перед поединком?',['Подготовка и выдержка','Бежать от противника','Выбросить оружие'],0],['Противник поднял щит. Что делать?',['Бездумно бить в щит','Сменить тактику и выждать момент','Сдаться'],1],['Твой союзник ранен.',['Бросить его','Помочь и прикрыть','Забрать его оружие'],1]]},
mages:{questions:[['Как экономить магию в долгом походе?',['Заклинать без остановки','Использовать подходящее заклинание по ситуации','Никогда не использовать магию'],1],['Что относится к разрушению?',['Лечащее заклинание','Огненный разряд','Открытие замка'],1],['У тебя мало магии в бою.',['Игнорировать запас','Использовать экономные заклинания и восстановление','Тратить всё сразу'],1]]},
thieves:{questions:[['Стража близко.',['Бежать по главной улице','Спрятаться и переждать','Кричать о краже'],1],['Дверь заперта.',['Взломать тихо','Выбить дверь','Позвать стражу'],0],['Товар лучше взять без шума.',['Создать переполох','Осторожно украсть и скрыться','Спросить у всех вокруг'],1]]},
dark:{questions:[['Цель одна и охрана рядом.',['Поднять шум','Наблюдать и выбрать безопасный момент','Идти напролом'],1],['Лучшее оружие убийцы?',['Терпение и тень','Громкий колокол','Факел в обеих руках'],0],['После заказа важно…',['Оставить следы','Исчезнуть и не привлекать внимание','Рассказать всем'],1]]},
guards:{questions:[['Что делать с нарушителем, который сдался?',['Наказать без суда','Задержать по закону','Отпустить за взятку'],1],['Гражданин просит помощи.',['Проигнорировать','Уточнить угрозу и защитить его','Взять золото'],1],['Стража должна прежде всего…',['Поддерживать порядок','Собирать налоги для себя','Избегать проблем'],0]]},
hunters:{questions:[['След внезапно раздваивается.',['Идти по более свежему следу','Сразу уйти','Сломать все ветви вокруг'],0],['Хищник ранен.',['Идти вслепую','Оценить ветер и укрытие','Кричать в лесу'],1],['Товарищ попал в капкан.',['Оставить его','Сначала обезопасить ловушку','Бежать за помощью и забыть его'],1]]},
miners:{questions:[['Какая руда выглядит наиболее ценной?',['Старая пустая порода','Чистая жила металла','Мокрый песок'],1],['Обвал начинается.',['Бежать в глубину шахты','Сохранять спокойствие и идти к креплению','Стоять на месте'],1],['Товарищ ранен.',['Забрать руду','Помочь и вывести его','Оставить'],1]]},
alchemists:{questions:[['Что важнее перед смешением ингредиентов?',['Смешать всё сразу','Знать свойства и дозировку','Добавить огонь в любую смесь'],1],['Редкий реагент найден.',['Потратить его бездумно','Сохранить и проверить рецепт','Выбросить'],1],['Зелье начинает кипеть.',['Добавить случайный порошок','Снять с огня и стабилизировать','Оставить как есть'],1]]},
sailors:{questions:[['На пути шторм.',['Идти прямо в шторм','Укрыться и переждать пик','Потерять груз намеренно'],1],['Лёд перекрыл путь.',['Ускориться','Искать безопасный пролив','Развернуть корабль без осмотра'],1],['Караванный груз повреждён.',['Скрыть ущерб','Сообщить капитану и оценить потери','Выбросить всё за борт'],1]]},
merchants:{questions:[['Партнёр предлагает сделку слишком выгодную.',['Согласиться сразу','Проверить товар и условия','Уйти без слов'],1],['Цена на железо выросла.',['Паниковать','Сравнить рынки и запасы','Скупить всё подряд'],1],['Караван задержан.',['Игнорировать контракт','Переговорить срок и охрану','Отказаться от торговли'],1]]},
warriors_east:{questions:[['Товарищ прикрывает фланг.',['Оставить его','Поддержать и держать строй','Броситься вперёд одному'],1],['Враг сильнее.',['Паниковать','Сменить тактику и держать оборону','Выбросить оружие'],1],['Караван атакован.',['Гнаться за добычей','Защитить людей и груз','Скрыться'],1]]},
voice:{questions:[['Перед испытанием Голоса важно…',['Шуметь','Сохранять спокойствие','Спорить с наставником'],1],['Слышишь зов ветра.',['Игнорировать всё','Сосредоточиться и слушать','Бежать вниз'],1],['Сила без контроля…',['Всегда полезна','Опасна для себя и других','Не имеет значения'],1]]}
};
const guildRanks={
companions:['Новобранец','Рекрут','Воин','Щитоносец','Опытный воин','Ветеран','Капитан','Мастер оружия','Хранитель Соратников','Глава Соратников'],
mages:['Ученик','Адепт','Заклинатель','Эксперт','Мастер','Архимаг-исследователь','Магистр школы','Хранитель арканов','Верховный маг','Глава Коллегии'],
thieves:['Новичок','Подмастерье','Опытный вор','Ловкач','Теневой агент','Мастер взлома','Теневой мастер','Серый лис','Глава подполья','Мастер гильдии'],
dark:['Посвящённый','Нож','Клинок','Тень','Ночной убийца','Мастер контракта','Серая роза','Хранитель тайны','Слушатель','Тёмный советник'],
guards:['Новобранец','Стражник','Старший стражник','Сержант','Капрал','Лейтенант','Капитан','Командир','Маршал города','Командующий стражей'],
hunters:['Следопыт','Охотник','Мастер следа','Старший охотник','Егерь','Мастер угодий','Ведущий следопыт','Хозяин лесов','Хранитель охоты','Верховный егерь'],
miners:['Ученик рудокопа','Горняк','Мастер жилы','Старший мастер','Начальник смены','Хозяин шахты','Мастер руд','Хранитель глубин','Горный лорд','Глава союза'],
alchemists:['Сборщик','Зельевар','Мастер смесей','Алхимик-исследователь','Лаборант','Мастер ядов','Хранитель рецептов','Великий алхимик','Архивариус формул','Глава круга'],
sailors:['Юнга','Матрос','Штурман','Старший штурман','Капитан','Мастер рейса','Хранитель маяков','Адмирал побережья','Владыка северных путей','Глава мореходов'],
merchants:['Приказчик','Торговец','Старший купец','Мастер сделки','Караванщик','Мастер караванов','Торговый магнат','Хозяин рынков','Владыка торговли','Глава палаты'],
warriors_east:['Рекрут','Воин','Щитоносец','Старший защитник','Командир звена','Командир каравана','Хранитель востока','Генерал щита','Владыка рубежа','Глава Щита Востока'],
voice:['Послушник','Ученик Голоса','Искатель','Ходок пути','Наставник','Мастер Голоса','Хранитель дыхания','Мастер горы','Хранитель пути','Голос Хротгара']
};
const guildUnlocks={
companions:['Казарма и тренировки','Тренер боевых навыков','Найм первого спутника','Гильдейская экипировка','Доступ к учениям отряда','Право вести патруль','Улучшение тренировочного зала','Руководство боевым отрядом','Уникальный арсенал','Право главы и военная кампания'],
mages:['Залы Коллегии','Скидка на обучение магии','Редкие заклинания','Зачарование','Магические исследования','Доступ к лаборатории','Создание артефактов','Магический архив','Уникальные ритуалы','Право главы Коллегии'],
thieves:['Тайные контакты','Скидки у воров','Скупщики и чёрный рынок','Снижение розыска','Тайное убежище','Контракты гильдии','Сеть информаторов','Управление тайными ячейками','Секретный арсенал','Право мастера подполья'],
dark:['Скрытые задания','Яды и зелья','Уникальные контракты','Тайное убежище','Ночные контракты','Сеть наблюдателей','Особые убийства','Священные контракты','Секретный совет','Право тёмного советника'],
guards:['Казармы','Скидки на снаряжение','Патрули','Право задержания','Командование звеном','Служебный транспорт','Расширенный доступ к архивам','Снижение розыска','Командование гарнизоном','Право главы стражи'],
hunters:['Охотничьи угодья','Бонус к добыче','Редкие следы','Охотничьи контракты','Собственная стоянка','Редкие звери','Разведка лесов','Охотничья дружина','Легендарные трофеи','Право главы охоты'],
miners:['Гильдейский рудник','Скидка на инструменты','Богатые жилы','Собственная ячейка','Глубокие шахты','Редкая руда','Улучшение шахты','Охрана рудника','Секретная жила','Право главы союза'],
alchemists:['Лаборатория','Скидка на ингредиенты','Редкие рецепты','Яды','Собственная лаборатория','Исследование реагентов','Сильные эликсиры','Запретные рецепты','Алхимический архив','Право главы круга'],
sailors:['Пристань','Скидка на провизию','Контракты сопровождения','Быстрые рейсы','Собственная каюта','Морские маршруты','Экспедиции','Охрана флота','Военный флот','Право главы мореходов'],
merchants:['Торговый зал','Лучшая цена покупки','Оптовые контракты','Свой караван','Склад гильдии','Выгодные маршруты','Сеть торговцев','Редкие поставки','Влияние на рынок','Право главы палаты'],
warriors_east:['Восточная казарма','Тренировки строя','Контракты караванов','Командование отрядом','Собственная броня','Защита дорог','Военный штаб','Гвардейская дружина','Военная кампания','Право главы Щита'],
voice:['Испытания Голоса','Тренировка Воли','Духовные задания','Путь наставника','Горные испытания','Изучение Голоса','Доступ к вершинам','Обучение учеников','Уникальное благословение','Право хранителя Хротгара']
};
const guildRepReq=[3,8,15,24,36,50,68,90,116];
const guildRival={companions:'guards',guards:'companions',mages:'thieves',thieves:'mages',dark:'guards',hunters:'warriors_east',warriors_east:'hunters',miners:'merchants',merchants:'miners',alchemists:'mages',sailors:'merchants',voice:'dark'};

const npcDb={
'Ярл Балгруф':{role:'Ярл',about:'Правитель Вайтрана.',quests:['Защита торгового каравана','Странные огни у башни'],rumors:['Вокруг Вайтрана замечены драконы.','Стража ищет пропавший караван.']},
'Бриньольф':{role:'Вор',about:'Связной подполья Рифтена.',quests:['Тайный заказ','Долг торговца'],rumors:['Внизу под рынком идет тайная торговля.','В Рифтене кто-то скупает редкие зелья.']},
'Фаэндаль':{role:'Лучник',about:'Может стать спутником.',companion:true,quests:['Пропавший следопыт'],rumors:['В лесу появился крупный медведь.']},
'Кузнец Адрианна':{role:'Кузнец',about:'Продает оружие, броню и ремонтирует снаряжение.',vendor:true,stock:['Железный меч','Железный щит','Железный кинжал','Железный шлем'],rumors:['Вчера привезли партию железной руды.']},
'Алхимик Лами':{role:'Алхимик',about:'Составляет зелья из редких трав.',vendor:true,stock:['Зелье лечения','Свиток магии'],rumors:['На болотах цветет редкий черный лотос.'],quests:['Травы болот']},
'Торговец Мадези':{role:'Торговец',about:'Покупает добычу и продает полезные вещи.',vendor:true,stock:['Зелье лечения','Свиток магии','Железный кинжал','Янтарь'],rumors:['К югу идет большой караван.']},
'Караванщик Лод':{role:'Караванщик',about:'Возит товары между городами.',vendor:true,stock:['Зелье лечения','Железный меч','Янтарь'],rumors:['На дороге орудуют бандиты.'],quests:['Защита торгового каравана']},
'Гердур':{role:'Житель',about:'Знает новости Ривервуда.',rumors:['В старых руинах слышали стук костей.'],quests:['Пропавшая охотница']},
'Ортор':{role:'Лесоруб',about:'Работает у реки.',rumors:['Следы волков ведут к северному лесу.']},
'Вунферт':{role:'Придворный маг',about:'Исследует древнюю магию.',rumors:['В курганах пробуждаются мертвые.'],quests:['Свиток из кургана']},
'Кузнец Орит':{role:'Кузнец',about:'Кует северное оружие.',vendor:true,stock:['Железный меч','Железный щит','Железный шлем'],rumors:['Нужна новая руда из шахты.']},
'Капитан стражи':{role:'Стражник',about:'Следит за порядком в городе.',rumors:['За некоторыми путниками давно следят.'],quests:['Ночной патруль']},
'Алхимик':{role:'Алхимик',about:'Скупает травы и ингредиенты.',vendor:true,stock:['Зелье лечения','Свиток магии'],rumors:['В болоте есть редкие растения.']},
'Рыбак':{role:'Рыбак',about:'Живет у воды.',rumors:['На берегу видели свет ночью.']},
'Учитель Голоса':{role:'Учитель',about:'Знает древние техники дыхания.',rumors:['Голос может изменить исход боя.'],quests:['Испытание голоса']}};
const itemDb={
'Железный меч':{price:60,damage:12,type:'weapon',slot:'Меч',rarity:'common',rarityName:'Обычная'},'Железный щит':{price:45,armor:10,type:'armor',slot:'Щит',rarity:'common',rarityName:'Обычная'},'Железный кинжал':{price:35,damage:8,type:'weapon',slot:'Кинжал',rarity:'common',rarityName:'Обычная'},'Железный шлем':{price:55,armor:8,type:'armor',slot:'Шлем',rarity:'common',rarityName:'Обычная'},'Зелье лечения':{price:30,heal:45,type:'potion'},'Янтарь':{price:80,type:'loot'},'Эктоплазма':{price:65,type:'loot'},'Шкура волка':{price:25,type:'loot'},'Шкура медведя':{price:45,type:'loot'},'Ядовитый мешок':{price:40,type:'loot'},'Свиток магии':{price:90,type:'magic'},'Древнее оружие':{price:140,damage:18,type:'weapon',slot:'Меч',rarity:'rare',rarityName:'Редкая'},'Старый кость-клинок':{price:70,damage:14,type:'weapon',slot:'Меч',rarity:'uncommon',rarityName:'Необычная'}};
const ITEM_RARITIES={common:{id:'common',name:'Обычная',icon:'⚪',mul:1.00},uncommon:{id:'uncommon',name:'Необычная',icon:'🟢',mul:1.16},rare:{id:'rare',name:'Редкая',icon:'🔵',mul:1.34},legendary:{id:'epic',name:'Легендарная',icon:'🟣',mul:1.72},mythic:{id:'mythic',name:'Мифическая',icon:'🟠',mul:2.25}};
Object.assign(itemDb,{
 'Железная булава':{price:48,damage:10,type:'weapon',slot:'Булава',rarity:'common',rarityName:'Обычная'},
 'Охотничий лук':{price:70,damage:13,type:'weapon',slot:'Лук',rarity:'common',rarityName:'Обычная'},
 'Стальной меч':{price:95,damage:17,type:'weapon',slot:'Меч',rarity:'uncommon',rarityName:'Необычная'},
 'Стальной боевой топор':{price:115,damage:20,type:'weapon',slot:'Топор',rarity:'uncommon',rarityName:'Необычная'},
 'Стальной кинжал':{price:78,damage:12,type:'weapon',slot:'Кинжал',rarity:'uncommon',rarityName:'Необычная'},
 'Стальной лук':{price:125,damage:18,type:'weapon',slot:'Лук',rarity:'uncommon',rarityName:'Необычная'},
 'Двемерский меч':{price:165,damage:23,type:'weapon',slot:'Меч',rarity:'rare',rarityName:'Редкая'},
 'Двемерский боевой топор':{price:185,damage:26,type:'weapon',slot:'Топор',rarity:'rare',rarityName:'Редкая'},
 'Эбонитовый клинок':{price:420,damage:32,type:'weapon',slot:'Меч',rarity:'epic',rarityName:'Легендарная'},
 'Даэдрический меч':{price:780,damage:42,type:'weapon',slot:'Меч',rarity:'mythic',rarityName:'Мифическая'},
 'Эльфийский лук':{price:520,damage:36,type:'weapon',slot:'Лук',rarity:'epic',rarityName:'Легендарная'},
 'Стальной щит':{price:85,armor:15,type:'armor',slot:'Щит',rarity:'uncommon',rarityName:'Необычная'},
 'Двемерский щит':{price:160,armor:20,type:'armor',slot:'Щит',rarity:'rare',rarityName:'Редкая'},
 'Стальной шлем':{price:95,armor:12,type:'armor',slot:'Шлем',rarity:'uncommon',rarityName:'Необычная'},
 'Двемерский шлем':{price:175,armor:18,type:'armor',slot:'Шлем',rarity:'rare',rarityName:'Редкая'},
 'Кожаная броня':{price:75,armor:8,type:'armor',slot:'Броня',rarity:'common',rarityName:'Обычная',hpBonus:4,stBonus:4},
 'Стальная броня':{price:160,armor:22,type:'armor',slot:'Броня',rarity:'uncommon',rarityName:'Необычная',hpBonus:8,stBonus:-2},
 'Двемерская броня':{price:310,armor:30,type:'armor',slot:'Броня',rarity:'rare',rarityName:'Редкая',hpBonus:12,stBonus:-4},
 'Эбонитовая броня':{price:720,armor:40,type:'armor',slot:'Броня',rarity:'epic',rarityName:'Легендарная',hpBonus:22,stBonus:-6},
 'Кожаные сапоги':{price:55,armor:3,type:'armor',slot:'Сапоги',rarity:'common',rarityName:'Обычная',stBonus:10},
 'Стальные сапоги':{price:650,armor:7,type:'armor',slot:'Сапоги',rarity:'uncommon',rarityName:'Необычная',stBonus:8},
 'Сапоги следопыта':{price:1350,armor:9,type:'armor',slot:'Сапоги',rarity:'rare',rarityName:'Редкая',stBonus:16},
 'Сапоги теней':{price:590,armor:11,type:'armor',slot:'Сапоги',rarity:'epic',rarityName:'Легендарная',stBonus:20,mpBonus:8},
 'Шлем хранителя':{price:430,armor:24,type:'armor',slot:'Шлем',rarity:'epic',rarityName:'Легендарная',hpBonus:14},
 'Корона древнего драуга':{price:1100,armor:32,type:'armor',slot:'Шлем',rarity:'mythic',rarityName:'Мифическая',hpBonus:25,mpBonus:15},
 'Кинжал ночного ветра':{price:980,damage:44,type:'weapon',slot:'Кинжал',rarity:'mythic',rarityName:'Мифическая',stBonus:12},
 'Лук древнего охотника':{price:850,damage:41,type:'weapon',slot:'Лук',rarity:'mythic',rarityName:'Мифическая',stBonus:10},
 'Кираса пепельного стража':{price:900,armor:46,type:'armor',slot:'Броня',rarity:'mythic',rarityName:'Мифическая',hpBonus:30,stBonus:-3},
 'Сапоги морозного следопыта':{price:820,armor:13,type:'armor',slot:'Сапоги',rarity:'mythic',rarityName:'Мифическая',stBonus:28},
 'Ожерелье маны':{price:260,armor:0,type:'accessory',rarity:'rare',rarityName:'Редкая',mpBonus:24},
 'Амулет жизненной силы':{price:300,armor:0,type:'accessory',rarity:'rare',rarityName:'Редкая',hpBonus:20},
 'Талисман воина':{price:640,armor:0,type:'accessory',rarity:'epic',rarityName:'Легендарная',damageBonus:6,stBonus:12},
});
const skillTrees={
'⚔️ Воин':[
{id:'onehand',name:'Мастер клинка',desc:'+8% урона одноручным оружием',req:0,cost:1,skill:'Одноручное оружие'},
{id:'blockmaster',name:'Железный щит',desc:'+10% эффективности блока',req:1,cost:1,skill:'Блокирование'},
{id:'heavy',name:'Тяжёлая поступь',desc:'+10 максимальной выносливости',req:2,cost:1,skill:'Тяжёлая броня'},
{id:'berserk',name:'Ярость воина',desc:'Сильная атака наносит ещё +15% урона',req:3,cost:2,skill:'Одноручное оружие'}],
'🔮 Маг':[
{id:'spark',name:'Искра',desc:'Заклинания наносят +8% урона',req:0,cost:1,skill:'Магия разрушения'},
{id:'mana',name:'Поток маны',desc:'+10 максимальной магии',req:1,cost:1,skill:'Магия разрушения'},
{id:'focus',name:'Магический фокус',desc:'Заклинания стоят на 2 маны меньше',req:2,cost:1,skill:'Магия разрушения'},
{id:'archmage',name:'Архимаг',desc:'Открывает сильное заклинание',req:3,cost:2,skill:'Магия разрушения'}],
'🗝️ Вор':[
{id:'shadow',name:'Тихий шаг',desc:'+10% к скрытности',req:0,cost:1,skill:'Скрытность'},
{id:'lock',name:'Умелые пальцы',desc:'+10% к взлому',req:1,cost:1,skill:'Взлом'},
{id:'speech',name:'Серебряный язык',desc:'Торговля выгоднее на 8%',req:2,cost:1,skill:'Красноречие'},
{id:'assassin',name:'Удар из тени',desc:'Первая атака из засады наносит двойной урон',req:3,cost:2,skill:'Скрытность'}],
'🏹 Охотник':[
{id:'aim',name:'Меткий глаз',desc:'+10% урона луком',req:0,cost:1,skill:'Стрельба'},
{id:'tracker',name:'Следопыт',desc:'Чаще находишь добычу и случайные события',req:1,cost:1,skill:'Стрельба'},
{id:'hunter',name:'Охотник',desc:'+15% награды за животных',req:2,cost:1,skill:'Стрельба'},
{id:'deadeye',name:'Смертельный выстрел',desc:'Шанс критического выстрела 20%',req:3,cost:2,skill:'Стрельба'}],
'🔨 Ремесло':[
{id:'smith',name:'Кузнец',desc:'Открывает улучшение оружия',req:0,cost:1,skill:'Алхимия'},
{id:'alch',name:'Зельевар',desc:'Зелья восстанавливают на 25% больше',req:1,cost:1,skill:'Алхимия'},
{id:'enchant',name:'Зачарователь',desc:'Открывает магические улучшения предметов',req:2,cost:1,skill:'Алхимия'},
{id:'mastercraft',name:'Мастер ремесла',desc:'Продажа созданных предметов приносит больше золота',req:3,cost:2,skill:'Алхимия'}],
'🌲 Выживание':[
{id:'survive',name:'Живучесть',desc:'+15 максимального здоровья',req:0,cost:1,skill:'Тяжёлая броня'},
{id:'camp',name:'Лагерь',desc:'Отдых вне города восстанавливает силы',req:1,cost:1,skill:'Скрытность'},
{id:'herbs',name:'Травник',desc:'Чаще находишь зелья',req:2,cost:1,skill:'Алхимия'},
{id:'wanderer',name:'Странник',desc:'Путешествия тратят меньше выносливости',req:3,cost:2,skill:'Стрельба'}]
};
skillTrees['🛡️ Защитник']=[
{id:'bulwark',name:'Несокрушимость',desc:'+12 максимального здоровья и +5% к блоку',req:0,cost:2,skill:'Блокирование'},
{id:'guardline',name:'Стойкая линия',desc:'Блокирование расходует на 2 выносливости меньше',req:1,cost:2,skill:'Блокирование'},
{id:'ironwill',name:'Железная воля',desc:'Сильные удары реже сбивают тебя',req:2,cost:3,skill:'Тяжёлая броня'},
{id:'laststand',name:'Последний рубеж',desc:'При низком здоровье получаешь усиление защиты',req:3,cost:5,skill:'Тяжёлая броня'}];
skillTrees['🗣️ Дипломат']=[
{id:'courtesy',name:'Учтивость',desc:'+10% к шансам мирных решений',req:0,cost:2,skill:'Красноречие'},
{id:'negotiator',name:'Переговорщик',desc:'Торговля становится выгоднее',req:1,cost:2,skill:'Красноречие'},
{id:'influence',name:'Влияние',desc:'Отношения растут быстрее',req:2,cost:3,skill:'Красноречие'},
{id:'silvervoice',name:'Серебряный голос',desc:'Открывает редкие дипломатические варианты',req:3,cost:5,skill:'Красноречие'}];
function renderProfile(){
 const stats=Object.entries(p.skills||{}).map(([k,v])=>`<div class="item"><span>${esc(k)}</span><span class="pill">${v}/100</span></div>`).join('');
 const g=activeGuild();
 const guildBox=g?`<section class="card" style="margin-top:12px"><h3>🏰 Гильдия</h3><div class="item"><span>Организация</span><span class="pill">${esc(g.name)}</span></div><div class="item"><span>Ранг</span><span class="pill">${guildRank(g.id)}/10 • ${esc(guildRanks[g.id][guildRank(g.id)-1]||'')}</span></div><div class="item"><span>Репутация</span><span class="pill">${p.guildRep[g.id]||0}</span></div><button class="btn cyan" style="margin-top:8px" onclick="showScreen('guilds')">🏰 Открыть гильдию</button></section>`:`<section class="card" style="margin-top:12px"><h3>🏰 Гильдия</h3><div class="muted">Ты пока не состоишь ни в одной гильдии.</div><button class="btn" style="margin-top:8px" onclick="showScreen('guilds')">Посмотреть гильдии</button></section>`;
 const need=xpNeed(); const xp=Math.max(0,p.xp||0); const xpPct=Math.max(0,Math.min(100,xp/need*100));
 const statRows=['Сила','Ловкость','Выносливость','Интеллект','Воля','Харизма'].map((a,i)=>`<div class="level-stat"><span style="font-size:20px">${['💪','🏹','❤️','📖','🔷','💛'][i]}</span><div><b>${a}</b><div class="smallnote">${p.attributes?.[a]||5}</div></div><button class="plusBtn" ${p.levelStatPoints>0?'':'disabled'} onclick="spendLevelStat('${a}')">+</button></div>`).join('');
 const skillBranches=Object.entries(skillTrees).map(([name,nodes])=>`<details style="margin-top:10px"><summary style="cursor:pointer;font-weight:700">${esc(name)}</summary><div style="margin-top:8px">${nodes.map((n,i)=>{const ok=treeUnlocked(n.id),cost=treeNodeCost(nodes,i),lr=treeNodeLevelReq(i),sr=treeNodeSkillReq(i),can=i===0||treeUnlocked(nodes[i-1].id);const ready=can&&p.level>=lr&&(p.skills?.[n.skill]||0)>=sr&&(p.skillPoints||0)>=cost;return `<div class="skillnode ${ok?'learned':''} ${!ok&&!ready?'hard-lock':''}"><div class="skillnodeTop"><strong>${ok?'✓ ':''}${esc(n.name)}</strong><span class="pill">${cost} оч.</span></div><div class="muted">${esc(n.desc)}</div><div class="skill-requirement">Требуется: ур. ${lr} • ${esc(n.skill)} ${sr}+${i>0?' • предыдущий узел':''}</div>${ok?'<div class="skillLearned">ИЗУЧЕНО</div>':`<button class="btn small ${ready?'cyan':''}" ${ready?'':'disabled'} onclick="spendSkillPoint('${esc(name)}','${n.id}')">${ready?'Изучить':'🔒 Закрыто'}</button>`}</div>`}).join('')}</div></details>`).join('');
 main.innerHTML=`<section class="hero"><div class="title">ПРОФИЛЬ ГЕРОЯ</div><div class="subtitle">УРОВЕНЬ ${p.level} • ${esc(p.race)} • ${esc(p.trait)}</div><div class="profileHead"><div class="profileAvatar" style="overflow:hidden"><img src="${portraitPath(p.heroPortrait||(portraitList()[0]||'nord_m1'))}" alt="Герой" style="width:100%;height:100%;object-fit:cover"></div><div style="flex:1"><h3 style="margin:0">${esc(p.name||'Безымянный')}</h3><div class="muted">${esc(p.sign)} • ${p.age} лет</div><div class="notice" style="margin-top:8px">✨ Очки развития: <b>${p.skillPoints||0}</b> • 🎯 Очки характеристик: <b>${p.levelStatPoints||0}</b></div></div></div><div style="margin-top:12px"><div class="smallnote">⭐ Опыт: ${xp} / ${need}</div><div class="bar" style="margin-top:5px"><span style="display:block;width:${xpPct}%;height:100%;background:linear-gradient(90deg,#d6aa5c,#60d8d0);border-radius:20px"></span></div></div></section><section class="card combat-highlight" style="margin-top:12px"><h3 style="margin-bottom:8px">⚔️ БОЕВЫЕ ПОКАЗАТЕЛИ</h3><div class="combat-primary"><div class="pillbox"><b>⚔️ ${heroAttack()}</b><span>Атака</span></div><div class="pillbox"><b>🛡️ ${heroDefense()}</b><span>Защита</span></div></div><div class="combat-secondary"><div class="pillbox"><b>❤️ ${heroMaxHp()}</b><small>Здоровье</small></div><div class="pillbox"><b>🟢 ${heroMaxSt()}</b><small>Выносливость</small></div><div class="pillbox"><b>🔷 ${heroMaxMp()}</b><small>Мана</small></div><div class="pillbox"><b>💥 ${heroCrit()}%</b><small>Крит. шанс</small></div><div class="pillbox"><b>🩸 ${heroPenetration()}</b><small>Пробивание</small></div><div class="pillbox"><b>🛡️ ${heroBlockChance()}%</b><small>Шанс блока</small></div><div class="pillbox"><b>💨 ${heroDodge()}%</b><small>Уклонение</small></div><div class="pillbox"><b>💪 ${p.attributes?.Сила||0}</b><small>Сила</small></div></div><div class="smallnote" style="margin-top:8px">Атака и защита рассчитываются из уровня, навыков, характеристик и экипировки. Крит, пробивание, блок и уклонение прямо участвуют в бою.</div></section><section class="card" style="margin-top:12px"><h3>🤝 МАГИЯ И СПУТНИКИ</h3><div class="grid2" style="margin-top:8px"><button class="btn purple" onclick="showScreen('magic')">🔮 Магия</button><button class="btn cyan" onclick="showScreen('companions')">🤝 Спутники</button></div></section>${guildBox}<section class="card" style="margin-top:12px"><h3>🎯 РАЗВИТИЕ ПОСЛЕ УРОВНЯ</h3><div class="notice">Новый уровень становится заметно дороже предыдущего. За каждый новый уровень ты получаешь 2 очка характеристик; развитие рассчитано на долгую игру, а не на быстрый фарм.</div><div class="level-stat-grid" style="margin-top:10px">${statRows}</div></section><section class="card" style="margin-top:12px"><h3>❤️ Отношения</h3><div class="muted">Друзья, любовные отношения и знакомые.</div><button class="btn cyan" style="margin-top:8px" onclick="showScreen('relations')">❤️ Открыть отношения (${(p.knownPeople||[]).length})</button></section><details class="card" style="margin-top:12px"><summary style="cursor:pointer;font-size:20px;font-weight:700;color:#dfc58b">📊 Навыки</summary><div style="margin-top:10px">${stats}</div></details><details class="card" style="margin-top:12px"><summary style="cursor:pointer;font-size:20px;font-weight:700;color:#dfc58b">🌿 Ветки развития • ${Object.keys(skillTrees).length}</summary><div class="notice" style="margin-top:10px">Ветки стали значительно длиннее по времени: нужны уровень, высокий профильный навык, предыдущий узел и несколько очков развития. Быстро открыть всё больше нельзя.</div>${skillBranches}</details>`;
}
function fresh(){return {name:'',race:'Норд',gender:'Мужской',age:25,trait:'Воин',sign:'Воин',origin:'Северные земли',past:'Воин',talent:'Крепкое тело',weakness:'Боязнь нежити',combatStyle:'Меч и щит',alignment:'Нейтральный',heroPortrait:'nord_1',attrPoints:{},attributes:{},characterCreated:false,baseSkillsApplied:false,level:1,xp:0,skillPoints:0,levelStatPoints:0,abilities:[],gold:100,hp:100,mp:50,st:100,loc:'Вайтран',skills:{'Одноручное оружие':20,'Блокирование':15,'Тяжёлая броня':15,'Скрытность':10,'Красноречие':10,'Стрельба':0,'Магия разрушения':0,'Взлом':0,'Алхимия':0,'Двуручное оружие':0},inv:[['Железный меч',1],['Железный щит',1],['Зелье лечения',2]],quests:{done:[],active:[]},crime:0,heat:0,guild:{companions:0,mages:0,thieves:0,dark:0,guards:0},guildRep:{companions:0,mages:0,thieves:0,dark:0,guards:0},guildTrial:null,ownedHouses:[],companions:[],log:['Ты прибываешь в Вайтран. Твоя история начинается.'],history:[],battle:null,dialogNpc:null,tradeNpc:null,dialogMsg:'',inspection:null,day:1,hour:8,minute:0,hunger:100,energy:100,worldEvents:[],cityRelations:{},knownPeople:[],cityMood:50,cityPrices:100,lastCityEventDay:0,marketStock:{},activeGuild:null,guildCooldown:0,guildJoinedAt:{},guildWorld:{},questProgress:{},worldEngine:{version:1,lastSimMinute:8*60,lastDailyDay:1,lastMajorEventDay:0,npcs:{},cities:{},caravans:[],news:[],stats:{hours:0,events:0,npcMoves:0,caravanMoves:0}}};} 

let p=null; try{p=JSON.parse(localStorage.getItem(KEY)||localStorage.getItem(OLD_KEY)||localStorage.getItem(LEGACY_KEY)||localStorage.getItem(LEGACY2_KEY)||'null')}catch(e){p=null} if(!p||typeof p!=='object')p=fresh();
if(p.skillPoints===undefined) p.skillPoints=0;
if(p.levelStatPoints===undefined) p.levelStatPoints=0;
if(!Array.isArray(p.abilities)) p.abilities=[];
if(p.levelStatPoints===undefined)p.levelStatPoints=0;
if(!p.equipment)p.equipment={weapon:null,shield:null,helmet:null,armor:null,boots:null,amulet:null};
if(!p.guild) p.guild=fresh().guild;
if(!p.guildRep) p.guildRep={};
if(p.activeGuild===undefined) p.activeGuild=null;
if(p.guildCooldown===undefined) p.guildCooldown=0;
if(!p.guildJoinedAt) p.guildJoinedAt={};
if(!p.guildWorld) p.guildWorld={};
if(p.guildTrial===undefined) p.guildTrial=null;
if(p.dialogMsg===undefined) p.dialogMsg='';
if(p.inspection===undefined) p.inspection=null;
if(p.attrPoints===undefined) p.attrPoints={};
if(!p.origin) p.origin='Северные земли';
if(!p.past) p.past='Воин';
if(!p.talent) p.talent='Крепкое тело';
if(!p.weakness) p.weakness='Боязнь нежити';
if(!p.combatStyle) p.combatStyle='Меч и щит';
if(!p.alignment) p.alignment='Нейтральный';
if(!portraitList().includes(p.heroPortrait)) p.heroPortrait=portraitList()[0]||'nord_1';
if(!p.heroPortrait) p.heroPortrait=portraitList()[0]||'nord_1';
if(!p.attributes) p.attributes={};
if(!p.inv) p.inv=[];
if(!p.equipment) p.equipment={weapon:null,shield:null,helmet:null,armor:null,boots:null,amulet:null};
if(p.equipment.amulet===undefined) p.equipment.amulet=null;
if(!p.raidCooldowns) p.raidCooldowns={};
if(!p.raidInventory) p.raidInventory={};
if(!p.generatedItems) p.generatedItems={};
Object.assign(itemDb,p.generatedItems);
if(p.characterCreated===undefined) p.characterCreated=Boolean(p.name);
if(p.baseSkillsApplied===undefined) p.baseSkillsApplied=Boolean(p.name);
ensureGuildState();
function save(){localStorage.setItem(KEY,JSON.stringify(p))}
function esc(s){return String(s).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]))}
function addLog(t,cls=''){p.log.unshift(t);p.log=p.log.slice(0,120);p.history.unshift({t,cls});p.history=p.history.slice(0,120);save()}
function xpNeed(){const L=Math.max(1,Number(p.level||1));return Math.floor(320+Math.pow(L,1.95)*120+(L-1)*110)}
function rarityClass(r){return r==='mythic'?'rarity-mythic':r==='epic'?'rarity-legendary':r==='rare'?'rarity-rare':r==='uncommon'?'rarity-uncommon':'rarity-common'}
function rarityLabel(d){const r=d?.rarity||'common';return `<span class="rarity-label ${rarityClass(r)}">${esc(d?.rarityName||'Обычная')}</span>`}
function ensureAdvancedCombatBonuses(){for(const [name,d] of Object.entries(itemDb||{})){if(!d||!d.rarity)continue;const tier={common:0,uncommon:1,rare:2,epic:3,mythic:4}[d.rarity]||0;if(tier<=0)continue;d.critBonus=Number(d.critBonus||0)+tier;d.penetration=Number(d.penetration||0)+(d.type==='weapon'?tier*2:0);d.dodge=Number(d.dodge||0)+((d.slot==='Сапоги')?tier*1.5:0);d.blockChance=Number(d.blockChance||0)+((d.type==='armor'&&d.slot==='Щит')?tier*2:0);if(d.rarity==='mythic'){d.critBonus+=2;d.penetration+=4}}}
ensureAdvancedCombatBonuses();
function equippedItems(){const out=[];for(const s of ['weapon','shield','helmet','armor','boots','amulet']){const n=p.equipment?.[s];if(n)out.push(itemDb[n]||p.generatedItems?.[n]||{})}return out}
function equipmentBonus(field){return equippedItems().reduce((sum,d)=>sum+Number(d[field]||0),0)}
function heroAttack(){let v=8+(p.level||1)*2+Math.floor((p.attributes?.Сила||5)*1.5)+Math.floor((p.skills?.['Одноручное оружие']||0)*.34)+Math.floor((p.skills?.['Двуручное оружие']||0)*.20)+Math.floor((p.skills?.['Стрельба']||0)*.18)+equipmentBonus('damage')+equipmentBonus('damageBonus');if(p.weakness==='Вспыльчивость')v=Math.ceil(v*1.05);return Math.max(6,Math.round(v))}
function heroDefense(){let v=Math.floor((p.attributes?.Выносливость||5)*.65)+Math.floor((p.attributes?.Ловкость||5)*.15)+Math.floor((p.skills?.['Блокирование']||0)*.42)+Math.floor((p.skills?.['Тяжёлая броня']||0)*.28)+equipmentBonus('armor');if(p.abilities.includes('bulwark'))v=Math.round(v*1.05);return Math.max(0,Math.round(v))}
function heroCrit(){let v=4+Math.floor((p.attributes?.Ловкость||5)*.55)+Math.floor((p.skills?.['Одноручное оружие']||0)*.07)+Math.floor(equipmentBonus('critBonus'));return Math.max(4,Math.min(35,Math.round(v)))}
function heroPenetration(){return Math.max(0,Math.round((p.skills?.['Одноручное оружие']||0)*.08+(p.skills?.['Двуручное оружие']||0)*.05+equipmentBonus('penetration')))}
function heroBlockChance(){return Math.max(5,Math.min(45,Math.round(5+(p.skills?.['Блокирование']||0)*.18+equipmentBonus('blockChance'))))}
function heroDodge(){return Math.max(2,Math.min(35,Math.round(2+(p.attributes?.Ловкость||5)*.55+equipmentBonus('dodge'))))}
function heroMaxHp(){let base=100+p.level*10+(p.attributes?.Выносливость||5)*2+(p.abilities.includes('survive')?15:0)+equipmentBonus('hpBonus');if(p.talent==='Крепкое тело')base=Math.round(base*1.1);return Math.max(1,base)}
function heroMaxMp(){let base=50+(p.attributes?.Интеллект||5)*2+(p.attributes?.Воля||5);if(p.weakness==='Слабая магия')base-=10;if(p.abilities.includes('mana'))base+=10;base+=equipmentBonus('mpBonus');return Math.max(20,base)}
function heroMaxSt(){let base=100+(p.attributes?.Выносливость||5)*2;if(p.weakness==='Плохая выносливость')base-=10;base+=equipmentBonus('stBonus');return Math.max(60,base)}
function gainXp(n){if(p.talent==='Быстрый ум')n=Math.ceil(n*1.1);p.xp+=n;while(p.xp>=xpNeed()){p.xp-=xpNeed();p.level++;p.skillPoints=(p.skillPoints||0)+2;p.levelStatPoints=(p.levelStatPoints||0)+2;p.hp=Math.min(heroMaxHp(),p.hp+10);p.mp=Math.min(heroMaxMp(),p.mp+5);p.st=Math.min(heroMaxSt(),p.st+5);addLog(`✨ Новый уровень! Теперь ты ${p.level}-го уровня. Получено 2 очка развития и 2 очка характеристик.`,'good')}}
function spendLevelStat(attr){p.levelStatPoints=p.levelStatPoints||0;if(p.levelStatPoints<=0)return addLog('Нет свободных очков характеристик.','bad');const allowed=['Сила','Ловкость','Выносливость','Интеллект','Воля','Харизма'];if(!allowed.includes(attr))return;p.attributes=p.attributes||{};p.attributes[attr]=Number(p.attributes[attr]||5)+1;p.levelStatPoints--;p.hp=Math.min(heroMaxHp(),p.hp);p.mp=Math.min(heroMaxMp(),p.mp);p.st=Math.min(heroMaxSt(),p.st);save();renderProfile()}
function skill(name,delta){p.skills[name]=Math.min(100,(p.skills[name]||0)+delta);gainXp(Math.max(1,delta)*3)}
function addItem(name,n=1){let x=p.inv.find(v=>v[0]===name);if(x)x[1]+=n;else p.inv.push([name,n])}
function removeItem(name,n=1){let i=p.inv.findIndex(v=>v[0]===name);if(i<0)return false;if(p.inv[i][1]<n)return false;p.inv[i][1]-=n;if(p.inv[i][1]<=0)p.inv.splice(i,1);return true}
function travel(dest){if(!world[dest])return;const hours=1+(world[p.loc]?.exits?.indexOf(dest)>=0?0:1);const from=p.loc;p.loc=dest;p.st=Math.max(0,p.st-6);advanceTime(hours*60,`Ты отправляешься из ${from} в ${dest}`);randomEvent();renderWorld()}
function randomEvent(){let d=world[p.loc];if(!d)return;randomCityEvent();if(Math.random()<.25){let gold=10+Math.floor(Math.random()*35);p.gold+=gold;gainXp(8);addLog(`💰 Ты находишь ${gold} золотых.`,'good')}}
function gameDays(){return Math.max(1,p.day)}
function dateLabel(){return `${p.day} ${cityMonths[(Math.floor((p.day-1)/30))%cityMonths.length]} 4E 201`}
function timeLabel(){const h=p.hour;return h<5?'Ночь':h<9?'Рассвет':h<13?'Утро':h<18?'День':h<22?'Вечер':'Ночь'}
function advanceTime(minutes,reason=''){ensureLivingState();const oldTotal=(p.day*1440)+(p.hour*60)+p.minute;let total=p.hour*60+p.minute+minutes;let oldDay=p.day;p.hour=Math.floor((total%1440)/60);p.minute=total%60;p.day+=Math.floor(total/1440);const newTotal=(p.day*1440)+(p.hour*60)+p.minute;
  p.hunger=Math.max(0,p.hunger-Math.ceil(minutes/90));p.energy=Math.max(0,p.energy-Math.ceil(minutes/120));
  if(p.hunger<20) p.st=Math.max(0,p.st-2); if(p.energy<20) p.st=Math.max(0,p.st-2);
  worldEngineAdvance(oldTotal,newTotal);
  if(p.day!==oldDay){simulateCityDay(p.day-oldDay);if(p.guildCooldown>0)p.guildCooldown=Math.max(0,p.guildCooldown-(p.day-oldDay));if(p.guildWorld)Object.values(p.guildWorld).forEach(w=>{if(w?.warCooldown)w.warCooldown=Math.max(0,w.warCooldown-(p.day-oldDay))});}
  if(reason)addLog(`🕒 ${reason} • ${timeLabel()}, ${dateLabel()}`,'info'); save();
}

/* =========================
   NORD WORLD ENGINE V1
   Deterministic, save-backed simulation layer.
   ========================= */
const WORLD_ENGINE_VERSION=1;
const WORLD_ENGINE_MAX_NEWS=80;
const WORLD_ENGINE_EVENT_TYPES={
  'Город':['🛒 Караван прибыл на рынок. Торговцы пополняют запасы.','warn','🔥 На окраине заметили дым. Жители поднимают тревогу.','info','🎭 Горожане готовят небольшое представление на площади.','good','🛡️ Стража усилила патрули на улицах.','warn','🍺 В таверне появились новые путники и наёмники.','info'],
  'Деревня':['🌾 Фермеры начали ярмарку урожая.','good','🐎 Через поселение прошёл небольшой караван.','info','🐺 На окраине нашли следы хищника. Охотники вышли на поиски.','warn'],
  'Дикая местность':['🏕️ Следы недавнего лагеря замечены у дороги.','info','🐺 Хищники приблизились к старой тропе.','warn','🗝️ Исследователь обнаружил следы старого тайника.','good'],
  'default':['👥 В городе меняется распорядок: жители спешат по своим делам.','info','🛒 Торговцы спорят о ценах на редкие товары.','warn','🛡️ Патруль проверяет улицы после ночного происшествия.','warn']
};
function worldEngineCityType(city){return world[city]?.type||'default'}
function worldEnginePick(list){return list[Math.floor(Math.random()*list.length)]}
function worldEngineSchedule(role,hour){
  const r=(role||'Житель').toLowerCase();
  if(hour<6||hour>=23)return 'Дом';
  if(hour>=6&&hour<9)return r.includes('страж')?'Пост': 'Дорога';
  if(hour>=9&&hour<18){
    if(r.includes('кузнец'))return 'Кузница';
    if(r.includes('торгов'))return 'Рынок';
    if(r.includes('охот'))return 'Охота';
    if(r.includes('алхим'))return 'Лаборатория';
    if(r.includes('ярл')||r.includes('капитан'))return 'Резиденция';
    return r.includes('страж')?'Патруль':'Работа';
  }
  if(hour>=18&&hour<22)return 'Таверна';
  return 'Дом';
}
function worldEngineEnsureState(){
  const e=p.worldEngine;
  if(!e.stats)e.stats={hours:0,events:0,npcMoves:0,caravanMoves:0};
  if(!e.npcs)e.npcs={}; if(!e.cities)e.cities={}; if(!e.caravans)e.caravans=[]; if(!e.news)e.news=[]; if(!e.incidents)e.incidents=[];
  Object.keys(world).forEach(city=>{
    if(!e.cities[city])e.cities[city]={security:60,economy:100,morale:55,population:Math.max(80,(world[city].npcs||[]).length*120),activity:50,weather:'Ясно',weatherUpdatedDay:p.day||1,lastEventDay:0};
    const c=e.cities[city];
    if(!c.weather)c.weather='Ясно';
    if(c.weatherUpdatedDay===undefined)c.weatherUpdatedDay=p.day||1;
  });
  Object.entries(world).forEach(([city,d])=>{
    (d.npcs||[]).forEach(name=>{
      if(!e.npcs[name])e.npcs[name]={name,homeCity:city,currentCity:city,place:worldEngineSchedule(npcDb[name]?.role||'Житель',p.hour),mood:50,trust:0,alive:true,lastMoveDay:p.day||1};
    });
  });
  if(!e.caravans.length){
    e.caravans=[
      {id:'north-1',from:'Ривервуд',to:'Вайтран',progress:0,status:'В пути',goods:['Еда','Кожа']},
      {id:'east-1',from:'Рифтен',to:'Шорс-Стон',progress:35,status:'В пути',goods:['Руда','Одежда']}
    ];
  }
  if(e.lastSimMinute===undefined)e.lastSimMinute=(p.day||1)*1440+(p.hour||0)*60+(p.minute||0);
}
function worldEngineAddNews(text,city,cls='info',day=p.day){
  p.worldEngine.news.unshift({day,city,text,cls});
  p.worldEngine.news=p.worldEngine.news.slice(0,WORLD_ENGINE_MAX_NEWS);
}
function worldEngineRecordEvent(city,text,cls='info'){
  worldEngineAddNews(text,city,cls,p.day);
  p.worldEvents.unshift({day:p.day,text,cls,city});
  p.worldEvents=p.worldEvents.slice(0,60);
  p.worldEngine.stats.events=(p.worldEngine.stats.events||0)+1;
  if(city===p.loc){addLog(text,cls)}
}
function worldEngineCreateIncident(city,type,text,cls='warn',duration=1){
  if(!p.worldEngine.incidents)p.worldEngine.incidents=[];
  p.worldEngine.incidents=p.worldEngine.incidents.filter(x=>(x.expiresDay||0)>=p.day);
  const exists=p.worldEngine.incidents.some(x=>x.city===city&&x.type===type&&x.expiresDay>=p.day);
  if(!exists)p.worldEngine.incidents.push({id:`${city}:${type}:${p.day}`,city,type,text,cls,createdDay:p.day,expiresDay:p.day+duration});
}
function worldEngineClearIncident(city,type){
  if(!p.worldEngine.incidents)return;
  p.worldEngine.incidents=p.worldEngine.incidents.filter(x=>!(x.city===city&&x.type===type));
}
function worldEngineIncidentForText(city,text){
  if(text.includes('наёмников'))return ['mercenaries','⚔️ Группа наёмников у окраины','warn'];
  if(text.includes('караван')&&text.includes('дороге'))return ['road_attack','⚔️ На дороге атакован караван','warn'];
  if(text.includes('пожар'))return ['fire','🔥 Пожар в городском квартале','bad'];
  if(text.includes('лошад'))return ['horses','🐎 Сорвавшиеся лошади на рынке','warn'];
  if(text.includes('преступ'))return ['crime','🛡️ Рост преступности в городе','bad'];
  if(text.includes('нехватк')||text.includes('продоволь'))return ['shortage','🍞 Нехватка продовольствия','warn'];
  return null;
}
function worldEngineWeatherIcon(w){return ({'Ясно':'☀️','Облачно':'☁️','Туман':'🌫️','Дождь':'🌧️','Снег':'❄️','Сильный ветер':'🌬️'})[w]||'🌦️'}
function worldEngineWeatherClass(w){return ({'Ясно':'clear','Облачно':'cloudy','Туман':'fog','Дождь':'rain','Снег':'snow','Сильный ветер':'wind'})[w]||'clear'}
function applyWeatherVisual(weather){
  let fx=document.getElementById('weatherFX');
  if(!fx){fx=document.createElement('div');fx.id='weatherFX';document.body.appendChild(fx)}
  const w=weather||'Ясно', cls=worldEngineWeatherClass(w);
  if(fx.dataset.weather===w && fx.childElementCount) return;
  fx.className='weather-fx active '+cls; fx.dataset.weather=w;
  const frag=document.createDocumentFragment();
  const rand=(a,b)=>a+Math.random()*(b-a);
  if(cls==='rain'){
    for(let i=0;i<74;i++){const el=document.createElement('i');el.className='weather-rain-drop';el.style.cssText=`--x:${rand(-5,105)}%;--h:${rand(18,46)}px;--d:${rand(.62,1.12)}s;--delay:${rand(-1.2,0)}s;--o:${rand(.28,.72)};--dx:${rand(-30,44)}px`;frag.appendChild(el)}
    for(let i=0;i<12;i++){const el=document.createElement('i');el.className='weather-rain-splash';el.style.cssText=`--x:${rand(4,96)}%;--y:${rand(58,94)}%;--s:${rand(8,18)}px;--d:${rand(1.2,2.2)}s;--delay:${rand(-2,0)}s`;frag.appendChild(el)}
  } else if(cls==='snow'){
    const glyph=['❄','✦','•','❅','✧'];
    for(let i=0;i<38;i++){const el=document.createElement('i');el.className='weather-snowflake';el.textContent=glyph[i%glyph.length];el.style.cssText=`--x:${rand(-4,104)}%;--s:${rand(9,22)}px;--d:${rand(8,15)}s;--delay:${rand(-15,0)}s;--o:${rand(.42,.9)};--sx:${rand(-45,45)}px;--sx2:${rand(-55,55)}px;--sx3:${rand(-70,70)}px;--glow:${rand(8,22)}px`;frag.appendChild(el)}
  } else if(cls==='wind'){
    for(let i=0;i<18;i++){const el=document.createElement('i');el.className='weather-gust';el.style.cssText=`--y:${rand(10,92)}%;--w:${rand(110,230)}px;--d:${rand(2.8,4.8)}s;--delay:${rand(-5,0)}s;--r:${rand(-10,10)}deg;--dy:${rand(-28,28)}px;--o:${rand(.18,.5)}`;frag.appendChild(el)}
    const leaves=['🍂','🍃','🌿','🍁'];
    for(let i=0;i<7;i++){const el=document.createElement('i');el.className='weather-leaf';el.textContent=leaves[i%leaves.length];el.style.cssText=`--y:${rand(12,90)}%;--s:${rand(11,18)}px;--d:${rand(4,7)}s;--delay:${rand(-7,0)}s;--dy:${rand(-35,35)}px;--dy2:${rand(-25,30)}px;--o:${rand(.28,.58)}`;frag.appendChild(el)}
  } else if(cls==='fog'){
    for(let i=0;i<5;i++){const el=document.createElement('i');el.className='weather-fog-band';el.style.cssText=`--y:${18+i*17}%;--d:${10+i*2}s;--delay:${-i*2}s;--o:${.42+i*.05}`;frag.appendChild(el)}
  } else if(cls==='cloudy'){
    for(let i=0;i<5;i++){const el=document.createElement('i');el.className='weather-cloud';el.style.cssText=`--y:${2+i*7}%;--w:${180+i*38}px;--h:${48+i*5}px;--d:${22+i*5}s;--delay:${-i*6}s;--o:${.48+i*.07}`;frag.appendChild(el)}
  }
  fx.replaceChildren(frag);
}
function worldEngineMaybeWeatherChange(city,hour){
  const c=p.worldEngine.cities[city]; if(!c)return;
  const slots=[0,6,12,18];
  if(!slots.includes(hour))return;
  if(c.weatherUpdatedStamp===hour && c.weatherUpdatedDay===p.day)return;
  c.weatherUpdatedStamp=hour;c.weatherUpdatedDay=p.day;
  const all=['Ясно','Облачно','Туман','Дождь','Снег','Сильный ветер'];
  const roll=Math.random();
  if(roll>0.42)return;
  const current=c.weather||'Ясно';
  const next=worldEnginePick(all.filter(x=>x!==current));
  c.weather=next;c.weatherChangedAt=`${p.day}:${hour}`;
  worldEngineRecordEvent(city,`${worldEngineWeatherIcon(next)} Погода меняется: ${next.toLowerCase()}.`,'info');
  if(city===p.loc){applyWeatherVisual(next);showToast('Погода изменилась',`${worldEngineWeatherIcon(next)} Сейчас в городе: ${next}.`,'info','🌦️',2200)}
}
function worldEngineDaily(city){
  const c=p.worldEngine.cities[city]; if(!c)return;
  c.economy=Math.max(75,Math.min(135,c.economy+(Math.floor(Math.random()*9)-4)));
  c.security=Math.max(20,Math.min(95,c.security+(Math.floor(Math.random()*7)-3)));
  c.morale=Math.max(15,Math.min(95,c.morale+(Math.floor(Math.random()*7)-3)));
  c.activity=Math.max(10,Math.min(100,Math.round((c.morale+c.security+(c.economy/1.35))/3)));
  const bucket=WORLD_ENGINE_EVENT_TYPES[worldEngineCityType(city)]||WORLD_ENGINE_EVENT_TYPES.default;
  if(Math.random()<0.68){
    const pairIndex=Math.floor(Math.random()*(bucket.length/2))*2;
    const text=bucket[pairIndex], cls=bucket[pairIndex+1];
    worldEngineRecordEvent(city,text,cls); c.lastEventDay=p.day;
    const incident=worldEngineIncidentForText(city,text);
    if(incident)worldEngineCreateIncident(city,incident[0],incident[1],incident[2],2);
  }
}

function worldEngineHour(city,hour){
  const c=p.worldEngine.cities[city];
  if(c){c.activity=Math.max(10,Math.min(100,c.activity+(hour>=18?1:-1)));}
  worldEngineMaybeWeatherChange(city,hour);
  Object.values(p.worldEngine.npcs).forEach(n=>{
    if(!n.alive)return;
    const next=worldEngineSchedule(npcDb[n.name]?.role||'Житель',hour);
    if(next!==n.place){n.place=next;n.currentCity=n.homeCity;n.lastMoveDay=p.day;p.worldEngine.stats.npcMoves=(p.worldEngine.stats.npcMoves||0)+1;}
  });
  p.worldEngine.caravans.forEach(car=>{
    car.progress+=8+Math.floor(Math.random()*8);
    p.worldEngine.stats.caravanMoves=(p.worldEngine.stats.caravanMoves||0)+1;
    if(car.progress>=100){
      const temp=car.from;car.from=car.to;car.to=temp;car.progress=0;car.status='Прибыл и возвращается';
      const text=`🐎 Караван прибыл в ${car.from}. Торговцы привезли ${car.goods.join(', ')}.`;
      worldEngineRecordEvent(car.from,text,'good');
      worldEngineClearIncident(car.from,'road_attack');
    }
  });
  if((hour===12||hour===18)&&p.day!==p.worldEngine.lastMajorEventDay&&Math.random()<0.32){
    const cities=Object.keys(world);const city=worldEnginePick(cities);const bucket=WORLD_ENGINE_EVENT_TYPES[worldEngineCityType(city)]||WORLD_ENGINE_EVENT_TYPES.default;
    const pairIndex=Math.floor(Math.random()*(bucket.length/2))*2;const text=bucket[pairIndex],cls=bucket[pairIndex+1];
    worldEngineRecordEvent(city,text,cls);const incident=worldEngineIncidentForText(city,text);if(incident)worldEngineCreateIncident(city,incident[0],incident[1],incident[2],1);p.worldEngine.lastMajorEventDay=p.day;
  }
  if(p.worldEngine.incidents)p.worldEngine.incidents=p.worldEngine.incidents.filter(x=>(x.expiresDay||0)>=p.day);
}

function worldEngineAdvance(oldTotal,newTotal){
  worldEngineEnsureState();
  if(newTotal<oldTotal){p.worldEngine.lastSimMinute=newTotal;return}
  const startHour=Math.floor(oldTotal/60),endHour=Math.floor(newTotal/60);
  for(let stamp=startHour+1;stamp<=endHour;stamp++){
    const day=Math.floor(stamp/24/1)+0;
    const hour=((stamp%24)+24)%24;
    // Convert engine hour to current simulated day safely: game day is 1-based.
    const simDay=Math.floor(stamp/24);
    p.worldEngine.stats.hours=(p.worldEngine.stats.hours||0)+1;
    Object.keys(world).forEach(city=>worldEngineHour(city,hour));
    if(simDay>(p.worldEngine.lastDailyDay||p.day)){
      p.worldEngine.lastDailyDay=simDay;
      Object.keys(world).forEach(city=>worldEngineDaily(city));
    }
  }
  p.worldEngine.lastSimMinute=newTotal;
}
function worldEngineSnapshot(city=p.loc){
  worldEngineEnsureState();
  const c=p.worldEngine.cities[city]||{security:60,economy:100,morale:55,population:100,activity:50,weather:'Ясно'};
  const npcs=Object.values(p.worldEngine.npcs).filter(n=>n.alive&&n.currentCity===city);
  const caravans=p.worldEngine.caravans.filter(v=>v.from===city||v.to===city);
  const incidents=(p.worldEngine.incidents||[]).filter(v=>v.city===city&&v.expiresDay>=p.day);
  return {city,security:c.security,economy:c.economy,morale:c.morale,population:c.population,activity:c.activity,weather:c.weather||'Ясно',npcs,caravans,incidents};
}

function ensureLivingState(){
  if(p.day===undefined)p.day=1; if(p.hour===undefined)p.hour=8; if(p.minute===undefined)p.minute=0;
  if(p.hunger===undefined)p.hunger=100; if(p.energy===undefined)p.energy=100;
  if(p.worldEvents===undefined)p.worldEvents=[]; if(p.cityRelations===undefined)p.cityRelations={};
  if(p.knownPeople===undefined)p.knownPeople=[]; if(p.cityMood===undefined)p.cityMood=50;
  if(p.cityPrices===undefined)p.cityPrices=100; if(p.lastCityEventDay===undefined)p.lastCityEventDay=0;
  if(p.marketStock===undefined)p.marketStock={};
  if(p.questProgress===undefined)p.questProgress={};
  if(p.worldInfluence===undefined)p.worldInfluence={decisions:0,helped:0,harmed:0,reputation:0};
  if(!p.worldEngine||p.worldEngine.version!==1)p.worldEngine={version:1,lastSimMinute:(p.day||1)*1440+(p.hour||0)*60+(p.minute||0),lastDailyDay:p.day||1,lastMajorEventDay:0,npcs:{},cities:{},caravans:[],news:[],stats:{hours:0,events:0,npcMoves:0,caravanMoves:0}};
  if(!p.worldEngine.heroInfluence)p.worldEngine.heroInfluence={decisions:0,helped:0,harmed:0,reputation:0};
  worldEngineEnsureState();
}
ensureLivingState();
const cityMonths=['Утренней звезды','Солнечного рассвета','Первого семени','Руки дождя','Второго семени','Середины года','Высокого солнца','Последнего семени','Огня очага','Морозного заката','Заката солнца','Вечерней звезды'];
function simulateCityDay(days=1){for(let i=0;i<days;i++){p.cityMood=Math.max(0,Math.min(100,p.cityMood+(Math.random()<.5?-1:1)*Math.floor(Math.random()*8)));p.cityPrices=Math.max(82,Math.min(125,p.cityPrices+(Math.floor(Math.random()*11)-5)));
  const events=[['🛒 На рынок прибыл новый караван. Цены немного изменились.','good'],['🍺 В таверне сегодня шумно: приехали путники.','info'],['🛡️ Стража усилила патрули после ночного инцидента.','warn'],['🎭 В городе готовят небольшое представление.','good'],['⚔️ На окраине замечена группа наёмников.','warn'],['🔥 Ночью произошёл небольшой пожар. Горожане уже тушат его.','bad'],['🐎 Несколько лошадей сорвались с привязи на рынке.','warn'],['💰 Торговцы спорят о новых ценах на железо.','info']];
  const ev=events[Math.floor(Math.random()*events.length)];p.worldEvents.unshift({day:p.day,text:ev[0],cls:ev[1],city:p.loc});p.worldEvents=p.worldEvents.slice(0,40);addLog(ev[0],ev[1]);
}}
function randomCityEvent(){ensureLivingState();if(Math.random()>0.42)return;const events=[
  ['🍺 В таверне незнакомец громко спорит с наёмником. Можно вмешаться.','warn'],
  ['💬 На улице тебя окликает незнакомый путешественник.','info'],
  ['🛡️ Стражник просит помочь задержать подозрительного человека.','warn'],
  ['🐴 У рынка торговец ищет человека, который умеет успокаивать лошадей.','good'],
  ['🎲 За столом в таверне собираются игроки. Можно рискнуть золотом.','info'],
  ['❤️ Ты замечаешь человека, который явно ищет знакомства.','good'],
  ['⚔️ На площади начинается словесная перепалка, которая может закончиться дракой.','bad']
];const ev=events[Math.floor(Math.random()*events.length)];p.worldEvents.unshift({day:p.day,text:ev[0],cls:ev[1],city:p.loc});p.worldEvents=p.worldEvents.slice(0,40);addLog(ev[0],ev[1]);save()}
function sleepAtInn(){
  const roomCost=15;
  if(p.gold<roomCost){showToast('Недостаточно золота',`Комната на 8 часов стоит ${roomCost} золота.`,'bad','💰',2400);return false}
  p.gold-=roomCost;p.energy=100;p.hunger=Math.max(0,p.hunger-8);p.hp=Math.min(heroMaxHp(),p.hp+25);p.mp=Math.min(heroMaxMp(),p.mp+20);p.st=heroMaxSt();advanceTime(480,'Ты снимаешь комнату в таверне и спишь 8 часов');return true;
}
function eatFood(item='Хлеб'){const foods={'Хлеб':20,'Яблоко':12,'Сыр':15,'Мясо':30,'Суп':35,'Рыба':25};const gain=foods[item]||20;if(!removeItem(item))return addLog(`У тебя нет: ${item}.`,'bad');p.hunger=Math.min(100,p.hunger+gain);advanceTime(10,`Ты ешь: ${item}`);if(p.hunger>60)p.st=Math.min(heroMaxSt(),p.st+3);renderWorld()}
function inspectLocation(){const d=world[p.loc];if(!d)return;const people=d.npcs?.length||0;const vendors=d.npcs?.filter(n=>npcDb[n]?.vendor).length||0;const guards=d.npcs?.filter(n=>(npcDb[n]?.role||'').toLowerCase().includes('страж')).length||0;const placeTypes=['старую дорогу','скрытую тропу','следы костра','заброшенную постройку','следы недавнего боя','тайник торговцев'];const found=placeTypes[Math.floor(Math.random()*placeTypes.length)];p.inspection={text:`В ${p.loc} ты осматриваешься внимательнее. ${d.desc} Ты замечаешь ${found}.`,people,vendors,guards,places:2+Math.floor(Math.random()*3),time:['утро','день','вечер','ночь'][Math.floor(Math.random()*4)]};p.st=Math.max(0,p.st-2);addLog(`🔎 Ты осматриваешься в ${p.loc}.`,'info');save();renderWorld()}
function startIncidentBattle(city,type,enemyName){
  const e=enemyDb[enemyName]||enemyDb['Бандит'];
  p.battle={enemy:enemyName,hp:e.hp,maxHp:e.hp,round:1,poison:0,playerBlock:0,status:'В бою',incidentCity:city,incidentType:type};
  addLog(`⚔️ Ты решаешь проблему: ${enemyName}.`,'bad');showScreen('combat');
}
function resolveWorldIncident(city,type){
  const inc=(p.worldEngine.incidents||[]).find(x=>x.city===city&&x.type===type&&x.expiresDay>=p.day); if(!inc){showToast('Событие уже прошло','Опасность больше не активна.','info','ℹ️');renderWorld();return}
  if(type==='mercenaries'){startIncidentBattle(city,type,'Наемник');return}
  if(type==='road_attack'){startIncidentBattle(city,type,'Бандит');return}
  if(type==='crime'){
    advanceTime(30,'Ты помогаешь страже навести порядок');const c=p.worldEngine.cities[city];c.security=Math.min(95,c.security+7);c.morale=Math.min(95,c.morale+2);c.tension=Math.max(0,(c.tension||20)-7);worldEngineClearIncident(city,type);worldEngineRecordEvent(city,`🛡️ Опасность устранена: стража навела порядок при твоей помощи.`,'good');showToast('Угроза устранена','Город снова становится безопаснее.','good','🛡️',2400);renderWorld();save();return;
  }
  if(type==='fire'){
    advanceTime(45,'Ты помогаешь тушить пожар');const c=p.worldEngine.cities[city];c.wealth=Math.max(25,(c.wealth||100)-2);c.tension=Math.max(0,(c.tension||20)-5);c.security=Math.min(95,c.security+2);worldEngineClearIncident(city,type);worldEngineRecordEvent(city,`🔥 Пожар удалось потушить. Горожане благодарят тебя.`,'good');showToast('Пожар потушен','Ты помог спасти часть квартала.','good','🔥',2400);renderWorld();save();return;
  }
  if(type==='horses'){
    p.st=Math.max(0,p.st-8);advanceTime(20,'Ты ловишь сорвавшихся лошадей');const c=p.worldEngine.cities[city];c.morale=Math.min(95,c.morale+2);worldEngineClearIncident(city,type);const reward=5+Math.floor(Math.random()*8);p.gold+=reward;worldEngineRecordEvent(city,`🐎 Сорвавшихся лошадей поймали. Ты помог и получил ${reward} золота.`,'good');showToast('Лошади пойманы',`Награда: ${reward} золота.`,'good','🐎',2400);renderWorld();save();return;
  }
  if(type==='shortage'){
    const foodItem=['Хлеб','Мясо','Рыба','Суп'].find(x=>(p.inv||[]).some(v=>v[0]===x&&v[1]>0));
    if(foodItem){removeItem(foodItem);advanceTime(20,'Ты передаёшь еду горожанам');const c=p.worldEngine.cities[city];c.food=Math.min(160,c.food+10);c.morale=Math.min(95,c.morale+3);c.tension=Math.max(0,(c.tension||20)-4);worldEngineClearIncident(city,type);worldEngineRecordEvent(city,`🍞 Ты помог городу продовольствием. Запасы еды выросли.`,'good');showToast('Городу помогли',`Ты передал ${foodItem}.`,'good','🍞',2400);renderWorld();save();return;}
    if(p.gold>=18){p.gold-=18;advanceTime(20,'Ты покупаешь и передаёшь продовольствие');const c=p.worldEngine.cities[city];c.food=Math.min(160,c.food+12);c.morale=Math.min(95,c.morale+2);c.economy=Math.min(135,c.economy+1);worldEngineClearIncident(city,type);worldEngineRecordEvent(city,`🍞 Ты закупил продовольствие для города.`,'good');showToast('Продовольствие доставлено','Потрачено 18 золота.','good','🍞',2400);renderWorld();save();return;}
    showToast('Нужны ресурсы','Для помощи нужны продукты или хотя бы 18 золота.','warn','🍞');return;
  }
  showToast('Событие',inc.text,'info','🌍');
}
function worldIncidentActions(inc){
  const c=encodeURIComponent(inc.city),t=encodeURIComponent(inc.type);
  const map={mercenaries:'⚔️ Разобраться',road_attack:'⚔️ Защитить караван',crime:'🛡️ Помочь страже',fire:'🔥 Помочь тушить',horses:'🐎 Поймать лошадей',shortage:'🍞 Помочь продовольствием'};
  const label=map[inc.type]; if(!label)return '';
  return `<div class="incident-actions"><button class="choice" onclick="resolveWorldIncident(decodeURIComponent('${c}'),decodeURIComponent('${t}'))">${label}</button></div>`;
}
function finishIncidentBattle(){
  if(!p.battle||!p.battle.incidentType)return;
  const city=p.battle.incidentCity,type=p.battle.incidentType;worldEngineClearIncident(city,type);const c=p.worldEngine.cities[city];if(type==='mercenaries'){c.security=Math.min(95,c.security+5);c.tension=Math.max(0,(c.tension||20)-6);worldEngineRecordEvent(city,`⚔️ Группа наёмников устранена. В городе стало безопаснее.`,'good')}else if(type==='road_attack'){c.security=Math.min(95,c.security+4);c.tension=Math.max(0,(c.tension||20)-4);worldEngineRecordEvent(city,`🛡️ Нападение на караван отражено.`,'good')}
}
function enemyIcon(enemy){const tones={'Бандит':'#8b4f55','Разбойник':'#7b4650','Волк':'#6d7e81','Скелет':'#b8b09c','Драугр':'#557c78','Ведьма':'#69557d','Наемник':'#576a7b','Пират':'#806548','Паукообразный жук':'#6e5a45','Лесной призрак':'#5c88a3','Медведь':'#765844'};const image=enemy.image||'bandit';return `<div class="portrait" style="border-color:${tones[enemy.name]||'#4f6870'}"><img src="enemies/${image}.jpg" alt="${esc(enemy.name)}" loading="lazy" style="width:100%;height:100%;object-fit:cover"></div>`}
function startBattle(enemyName){const e=enemyDb[enemyName]||enemyDb['Бандит'];p.battle={enemy:enemyName,hp:e.hp,maxHp:e.hp,round:1,poison:0,playerBlock:0,status:'В бою'};addLog(`⚔️ На тебя нападает ${enemyName}!`,'bad');showScreen('combat')}
function battleEnemy(){let e=enemyDb[p.battle.enemy]||enemyDb['Бандит']; if(p.battle&&p.battle.mode==='danger'){return {...e,name:p.battle.enemy,lvl:p.battle.enemyLevel||e.lvl,hp:p.battle.maxHp||e.hp}} return {...e,name:p.battle.enemy}}
function enemyTurn(){let e=battleEnemy();if(Math.random()*100<heroDodge()){addLog(`💨 Ты уклоняешься от удара ${p.battle.enemy}!`,'good');return}let raw=p.battle.mode==='danger'?(p.battle.enemyAttack||8)+Math.floor(Math.random()*7):(4+Math.floor(Math.random()*7)+Math.floor(e.lvl/2));let dmg=Math.max(1,raw-Math.floor(heroDefense()*.20));if(p.battle.enemy==='Волк')dmg+=2;if(p.battle.playerBlock){dmg=Math.max(0,Math.floor(dmg*(1-p.battle.playerBlock)));p.battle.playerBlock=0;addLog(`🛡️ Ты блокируешь часть удара: получаешь ${dmg} урона.`,'info')}else addLog(`${e.icon} ${p.battle.enemy} наносит тебе ${dmg} урона.`,'bad');p.hp-=dmg;if(Math.random()<.18){p.battle.poison=2;addLog('☠️ Тебя отравили.')}if(p.battle.poison>0){p.hp-=4;p.battle.poison--;addLog('Яд наносит 4 дополнительного урона.','bad')}}
function finishWin(){let e=battleEnemy();let gold=20+e.lvl*8+Math.floor(Math.random()*25);const questCtx=p.battle.questContext;const battleMode=p.battle.mode;p.gold+=gold;gainXp(25+e.lvl*9);skill(e.type==='animal'?'Стрельба':'Одноручное оружие',1);e.loot.forEach(([name,ch])=>{if(Math.random()<ch && name!=='Золото')addItem(name)});if(battleMode==='danger'){const rare=dangerEventReward(0.028);p.worldEvents=p.worldEvents||[];p.worldEvents.unshift({city:p.loc,text:`⚠️ Опасность: ${p.battle.enemy} повержен. Получено ${gold} золота${rare?' и редкая находка: '+rare:''}.`,day:p.day,cls:'good'});addLog(`🏆 Победа над ${p.battle.enemy}: +${gold} золота${rare?` • 🎒 ${rare}`:''}.`,'good');p.battle=null;save();renderDanger();return}finishIncidentBattle();addLog(`🏆 Победа! ${p.battle.enemy} повержен. Ты получаешь ${gold} золота.`,'good');p.battle=null;if(questCtx&&questCtx.q){const st=questState(questCtx.q),def=questDef(questCtx.q);st.stage=Math.min(def.stages.length-1,(st.stage||0)+1);st.history=st.history||[];st.history.push(`Ты победил ${e.name} и продвинулся по заданию.`);save();showToast('Задание продвинулось','Победа открыла следующий этап.','good','📜',2200)}save();showScreen(questCtx?'quests':'world')}
function combatAction(kind){if(!p.battle)return;let e=battleEnemy();let damage=0;
if(kind==='attack'){p.battle.status='Ты атакуешь противника.';let levelPenalty=p.battle.mode==='danger'?Math.max(0,Number(p.battle.levelDelta||0))*.025:0;damage=Math.max(4,Math.round((heroAttack()*.78)*(1-levelPenalty))+Math.floor(Math.random()*5));if(Math.random()*100<heroCrit()){damage=Math.round(damage*1.65);addLog(`💥 КРИТИЧЕСКИЙ УДАР! ${damage} урона.`,'good')}if(p.weakness==='Вспыльчивость')damage=Math.ceil(damage*1.05);p.battle.hp-=Math.max(1,damage-Math.floor(heroPenetration()*.35));skill('Одноручное оружие',1);p.st=Math.max(0,p.st-5);addLog(`⚔️ Ты наносишь ${damage} урона.`,'info')}
if(kind==='heavy'){p.battle.status='Ты готовишь мощный удар.';if(p.st<18){addLog('Не хватает выносливости.','bad');return}let levelPenalty=p.battle.mode==='danger'?Math.max(0,Number(p.battle.levelDelta||0))*.035:0;damage=Math.max(8,Math.round((heroAttack()*1.45)*(1-levelPenalty))+Math.floor(Math.random()*7));if(Math.random()*100<(heroCrit()+8)){damage=Math.round(damage*1.8);addLog(`🔥 КРИТИЧЕСКИЙ СИЛЬНЫЙ УДАР! ${damage} урона.`,'good')}if(p.weakness==='Вспыльчивость')damage=Math.ceil(damage*1.05);p.battle.hp-=Math.max(1,damage-Math.floor(heroPenetration()*.5));p.st-=18;skill('Одноручное оружие',2);addLog(`💥 Сильный удар наносит ${damage} урона!`,'good')}
if(kind==='block'){p.battle.status='Ты готов блокировать следующий удар.';p.battle.playerBlock=.65;p.st=Math.max(0,p.st-4);skill('Блокирование',1);addLog('🛡️ Ты готовишься блокировать следующий удар.','info')}
if(kind==='spell'){p.battle.status='Ты используешь магию разрушения.';if(p.mp<15){addLog('Недостаточно магии.','bad');return}damage=Math.max(10,Math.round(heroAttack()*.62)+Math.floor((p.skills['Магия разрушения']||0)*.55)+Math.floor(Math.random()*8));p.mp-=15;skill('Магия разрушения',1);p.battle.hp-=damage;addLog(`🔮 Заклинание разрушения наносит ${damage} урона.`,'good')}
if(kind==='potion'){p.battle.status='Ты восстанавливаешь здоровье зельем.';if(!removeItem('Зелье лечения')){addLog('Нет зелья лечения.','bad');return}p.hp=Math.min(heroMaxHp(),p.hp+45);addLog('🧪 Ты выпиваешь зелье лечения.','good')}
if(kind==='flee'){p.battle.status='Ты пытаешься отступить.';if(Math.random()<.55){addLog('🏃 Ты успешно отступаешь.','info');const mode=p.battle.mode;p.battle=null;save();if(mode==='danger'){renderDanger();return}showScreen('world');return}else addLog('❌ Отступить не удалось!','bad')}
if(p.battle.hp<=0){finishWin();return}
enemyTurn();p.battle.round++;p.battle.status=`Противник отвечает. Раунд ${p.battle.round}.`;if(p.hp<=0){const mode=p.battle.mode;if(mode==='danger'){p.hp=Math.max(1,Math.floor(heroMaxHp()*.3));p.worldEvents=p.worldEvents||[];p.worldEvents.unshift({city:p.loc,text:`⚠️ Опасность: ${p.battle.enemy} победил тебя. Ты чудом выжил.`,day:p.day,cls:'bad'});addLog(`☠️ Опасность оказалась смертельно опасной: ${p.battle.enemy}.`,'bad');p.battle=null;save();renderDanger();return}p.hp=Math.max(35,Math.floor(heroMaxHp()*.45));p.loc='Вайтран';addLog(`☠️ Ты проиграл битву с ${p.battle.enemy} и очнулся у лекаря.`,'bad');p.battle=null;showScreen('world');return}save();renderCombat()}
const questBlueprints={
 'Защита торгового каравана':{brief:'Караван должен пройти безопасно через опасный участок тракта.',stages:[{title:'Отправиться к торговому тракту',desc:'Караван ждёт на дороге. Доберись до него и осмотри маршрут.',actions:[['travel','🚶 Отправиться на тракт','45 мин • путь к каравану']]},{title:'Караван атакован',desc:'Бандиты перекрыли дорогу. Теперь нужно решить, как действовать.',actions:[['fight','⚔️ Защитить караван лично','Бой • шанс на добычу'],['guard','🛡️ Заплатить за охрану','20 золота • безопасный вариант'],['negotiate','💬 Попробовать договориться','Красноречие • риск']]} ,{title:'Сопроводить караван',desc:'Нападение устранено. Проводи купцов до городских ворот.',actions:[['escort','🐎 Сопроводить до ворот','60 мин • безопасность города +']] }]},
 'Кража из склада':{brief:'Из складов пропадают дорогие товары. Нужно выяснить, кто стоит за кражами.',stages:[{title:'Добраться до склада',desc:'Склад закрыт. Осмотри район и найди точку входа.',actions:[['travel','🚶 Отправиться к складам','30 мин • расследование начинается']]},{title:'Проникновение',desc:'Ты нашёл следы взлома. Выбери способ проникнуть внутрь.',actions:[['stealth','🕵️ Проникнуть тайком','Скрытность • шанс на дополнительную добычу'],['lockpick','🔓 Вскрыть замок','Взлом • риск шума'],['bribe','💰 Подкупить сторожа','12 золота • быстро и тихо']]},{title:'Вернуть украденное',desc:'Ты нашёл часть товара. Верни его владельцу и раскрой дело.',actions:[['return','📦 Вернуть товар','20 мин • репутация +'],['keep','🤫 Оставить часть себе','Меньше репутации, больше добычи']] }]},
 'Пропавшая охотница':{brief:'Охотница не вернулась из леса. Нужно найти её след и помочь.',stages:[{title:'Поиск в лесу',desc:'Отправься по последнему известному маршруту.',actions:[['travel','🌲 Выйти к лесу','50 мин • поиск следов']]},{title:'Следы у костра',desc:'Ты нашёл лагерь и следы борьбы. Реши, что делать дальше.',actions:[['investigate','🔎 Осмотреть следы','Шанс найти охотницу'],['call','📯 Позвать стражу','10 золота • безопаснее'],['continue','🗡️ Идти по следу одному','Рискованный путь']]},{title:'Вернуть охотницу',desc:'Охотница найдена. Сопроводи её обратно.',actions:[['return','🏹 Сопроводить домой','40 мин • награда и репутация +']] }]}
};
function questDef(q){return questBlueprints[q]||{brief:'Поручение связано с событиями этого города.',stages:[{title:'Отправиться к месту',desc:'Доберись до указанного места и осмотрись.',actions:[['travel','🚶 Отправиться','40 мин • начать выполнение']]},{title:'Разобраться с проблемой',desc:'Выбери способ решения ситуации.',actions:[['investigate','🔎 Расследовать','Время • шанс успеха'],['negotiate','💬 Договориться','Красноречие • риск'],['fight','⚔️ Вступить в бой','Бой • риск и добыча']]},{title:'Вернуться с результатом',desc:'Вернись к заказчику и заверши работу.',actions:[['return','✅ Вернуться к заказчику','20 мин • завершить задание']]}]};}
function ensureQuestLimits(){
  p.questLimits=p.questLimits||{day:p.day||1,taken:0,completed:0,goldEarned:0,maxTaken:4,maxCompleted:3,maxActive:2,maxGold:240,cooldowns:{}};
  p.questLimits.cooldowns=p.questLimits.cooldowns||{};
  p.questLimits.maxTaken=4;p.questLimits.maxCompleted=3;p.questLimits.maxActive=2;p.questLimits.maxGold=240;
  if(p.questLimits.day!==p.day){p.questLimits.day=p.day||1;p.questLimits.taken=0;p.questLimits.completed=0;p.questLimits.goldEarned=0;}
  return p.questLimits;
}
function questCooldownDays(q){ensureQuestLimits();return Math.max(0,Number(p.questLimits.cooldowns[q]||0)-(p.day||1));}
function canTakeQuest(q){const lim=ensureQuestLimits();if(p.quests.active.includes(q)){showToast('Задание уже активно','Сначала закончи его.','warn','📜');return false}if((p.quests.active||[]).length>=lim.maxActive){showToast('Слишком много поручений',`Одновременно можно вести не более ${lim.maxActive} активных заданий.`,'warn','📜');return false}if(lim.taken>=lim.maxTaken){showToast('На сегодня поручений достаточно','Возвращайся завтра — новые дела появятся утром.','info','🕒',3000);return false}const cd=questCooldownDays(q);if(cd>0){showToast('Поручение ещё не обновилось',`Новая работа по этому делу появится через ${cd} дн.`,'info','📜',2800);return false}return true;}
function registerQuestTaken(q){const lim=ensureQuestLimits();lim.taken++;lim.cooldowns[q]=(p.day||1)+2;}
function questState(q){p.questProgress=p.questProgress||{};if(!p.questProgress[q])p.questProgress[q]={stage:0,history:[]};return p.questProgress[q];}
function questForCity(q){let d=world[p.loc];q=q||d.quests[Math.floor(Math.random()*d.quests.length)]||'Случайное поручение';if(!canTakeQuest(q))return;p.quests.active.push(q);questState(q);registerQuestTaken(q);addLog(`📜 Получено задание: «${q}». Начни его через журнал.`,'good');renderQuests();save()}
function completeQuest(q,rewardOverride){if(!p.quests.active.includes(q))return;const lim=ensureQuestLimits();if(lim.completed>=lim.maxCompleted){addLog('Сегодня ты уже выполнил дневной лимит поручений.','info');return}let reward=rewardOverride??(40+Math.floor(Math.random()*80));const left=Math.max(0,lim.maxGold-lim.goldEarned);reward=Math.min(reward,left);p.quests.active=p.quests.active.filter(x=>x!==q);p.quests.done.push(q);delete (p.questProgress||{})[q];p.gold+=reward;lim.completed++;lim.goldEarned+=reward;lim.cooldowns[q]=(p.day||1)+2;gainXp(35);addLog(`✅ Задание «${q}» выполнено. Награда: ${reward} золота.`,'good');renderQuests();save()}
function openQuest(q){if(!p.quests.active.includes(q)){showToast('Задание недоступно','Возьми его снова через список поручений.','warn','📜');return}const st=questState(q),def=questDef(q),stage=def.stages[Math.min(st.stage,def.stages.length-1)];const actions=stage.actions.map(([id,label,meta])=>`<button class="choice quest-choice" onclick="questAction('${esc(q)}','${id}')"><strong>${label}</strong><small>${meta||''}</small></button>`).join('');main.innerHTML=`<section class="hero"><div class="title">📜 ${esc(q)}</div><div class="subtitle">ЭТАП ${st.stage+1} ИЗ ${def.stages.length}</div><p class="smallnote">${esc(def.brief)}</p></section><section class="card quest-detail"><div class="quest-progress"><div style="width:${Math.min(100,Math.round(st.stage/def.stages.length*100))}%"></div></div><h3>${esc(stage.title)}</h3><p class="muted">${esc(stage.desc)}</p><div class="decision-actions quest-actions">${actions}</div><div class="quest-history">${(st.history||[]).slice(-4).map(x=>`<div>• ${esc(x)}</div>`).join('')}</div><button class="btn" style="margin-top:12px" onclick="renderQuests()">↩️ В журнал</button></section>`}
function questAction(q,id){if(!p.quests.active.includes(q))return;const st=questState(q),def=questDef(q),stage=def.stages[Math.min(st.stage,def.stages.length-1)];st.history=st.history||[];let outcome='';
  if(id==='travel'){advanceTime(40,`Ты отправляешься выполнять задание «${q}»`);outcome='Ты добрался до места и можешь продолжить расследование.';st.stage=Math.min(def.stages.length-1,st.stage+1)}
  else if(id==='escort'){advanceTime(60,'Ты сопровождаешь караван к воротам');p.cityMood=Math.min(100,p.cityMood+3);if(p.worldEngine?.cities?.[p.loc]){p.worldEngine.cities[p.loc].security=Math.min(95,p.worldEngine.cities[p.loc].security+3)};outcome='Караван благополучно прибыл к воротам.';st.stage++}
  else if(id==='guard'){if(p.gold<20){showToast('Недостаточно золота','Охрана просит 20 золота.','bad','💰');return}p.gold-=20;advanceTime(15,'Ты нанимаешь охрану для каравана');outcome='Охрана принимает заказ и проводит караван.';st.stage++}
  else if(id==='negotiate'){const score=(p.skills?.['Красноречие']||0)+(p.attributes?.Харизма||5);advanceTime(15,'Ты пытаешься договориться');if(score>=30){outcome='Переговоры удались. Нападающие отступили.';p.worldInfluence=p.worldInfluence||{};p.worldInfluence.reputation=(p.worldInfluence.reputation||0)+2;st.stage++}else{outcome='Переговоры сорвались. Придётся действовать иначе.';showToast('Не получилось','Красноречия недостаточно. Попробуй другой вариант.','warn','💬',2200)}}
  else if(id==='stealth'){advanceTime(25,'Ты пробираешься внутрь склада');const chance=Math.min(.88,.45+(p.skills?.['Скрытность']||0)/100);if(Math.random()<chance){outcome='Ты проник внутрь незаметно и нашёл место, где спрятан товар.';st.stage++}else{outcome='Тебя заметили. Ситуация становится опасной.';p.crime=(p.crime||0)+2;showToast('Тревога','Сторож тебя заметил.','bad','⚠️',1800)}}
  else if(id==='lockpick'){advanceTime(20,'Ты вскрываешь замок');const chance=Math.min(.9,.35+(p.skills?.['Взлом']||0)/100);if(Math.random()<chance){outcome='Замок поддался. Внутри ты находишь украденный товар.';st.stage++}else{outcome='Замок заклинило, а внутри поднялся шум.';p.heat=(p.heat||0)+2;showToast('Шум','Теперь нужно действовать осторожнее.','warn','🔓',2000)}}
  else if(id==='bribe'){if(p.gold<12){showToast('Недостаточно золота','Нужно 12 золота.','bad','💰');return}p.gold-=12;advanceTime(10,'Ты платишь сторожу');outcome='Сторож отворачивается и пропускает тебя внутрь.';st.stage++}
  else if(id==='return'){advanceTime(20,`Ты возвращаешься с результатом задания «${q}»`);outcome='Ты возвращаешься к заказчику.';st.stage++;}
  else if(id==='investigate'){advanceTime(30,'Ты тщательно расследуешь ситуацию');st.stage=Math.min(def.stages.length-1,st.stage+1);outcome='Ты находишь важную зацепку.'}
  else if(id==='call'){if(p.gold<10){showToast('Недостаточно золота','Нужно 10 золота на помощь стражи.','bad','💰');return}p.gold-=10;advanceTime(25,'Ты зовёшь стражу');st.stage++;outcome='Стража помогает найти след.'}
  else if(id==='continue'){advanceTime(40,'Ты идёшь по следу один');st.stage++;outcome='След привёл к безопасному маршруту.'}
  else if(id==='keep'){advanceTime(5,'Ты оставляешь часть товара себе');p.crime=(p.crime||0)+1;p.worldInfluence=p.worldInfluence||{};p.worldInfluence.reputation=(p.worldInfluence.reputation||0)-2;st.stage++;outcome='Ты оставляешь часть добычи себе. Репутация немного страдает.'}
  else if(id==='help'){advanceTime(20,'Ты помогаешь местным');st.stage++;outcome='Местные благодарят тебя.'}
  else if(id==='fight'){const enemy=(p.loc==='Ривервуд'?'Бандит':'Бандит');p.battle={enemy,hp:(enemyDb[enemy]||enemyDb['Бандит']).hp,maxHp:(enemyDb[enemy]||enemyDb['Бандит']).hp,round:1,poison:0,playerBlock:0,status:'В бою',questContext:{q,stage:st.stage}};addLog(`⚔️ Ты решил решить задание боем: ${enemy}.`,'bad');save();showScreen('combat');return}
  else {advanceTime(15,`Ты работаешь над заданием «${q}»`);st.stage=Math.min(def.stages.length-1,st.stage+1);outcome='Ты продвигаешься дальше.'}
  st.history.push(outcome);if(st.stage>=def.stages.length){const reward=55+Math.floor(Math.random()*65);completeQuest(q,reward);showToast('Задание завершено',`Ты получил ${reward} золота и опыт.`,'good','🏆',2400);return}save();openQuest(q)}
function cityActivity(type){if(type==='raids'){showScreen('raids');return}if(type==='tavern'){showScreen('tavern');return}if(type==='market'){showScreen('market');return}if(type==='arena'){showScreen('arena');return}if(type==='people'){showScreen('people');return}if(type==='quests'){showScreen('quests');return}if(type==='house'){buyHouse();return}}
function showToast(title,body='',tone='good',icon='✨',ms=2200){let w=document.getElementById('toastWrap');if(!w){w=document.createElement('div');w.id='toastWrap';w.className='toast-wrap';document.body.appendChild(w)}clearTimeout(window.__toastTimer);w.innerHTML=`<div class="toast-card ${tone}"><div class="toast-title">${icon} ${esc(title)}</div><div class="toast-body">${esc(body)}</div></div>`;requestAnimationFrame(()=>w.classList.add('show'));window.__toastTimer=setTimeout(()=>w.classList.remove('show'),ms)}
function closeTavernModal(){const m=document.getElementById('tavernModal');if(m)m.remove()}
function tavernMeter(label,val,max,cls,icon){const pct=Math.max(0,Math.min(100,(val/max)*100));return `<div class="tavern-meter"><div class="meter-head"><span>${icon} ${label}</span><b>${Math.round(val)}/${max}</b></div><div class="meter-bar ${cls}"><i style="width:${pct}%"></i></div></div>`}
function visitTavernAction(type){
 if(type==='eat'){if(p.gold<12){showToast('Недостаточно золота','Горячая еда стоит 12 золота.','bad','💰');return}p.gold-=12;const before=p.hunger;p.hunger=Math.min(100,p.hunger+25);advanceTime(20,'Ты заказываешь горячую еду в таверне');p.st=Math.min(heroMaxSt(),p.st+6);showToast('Ты поел',`Сытость +${p.hunger-before}. Выносливость +6. Потрачено 12 золота.`,'good','🍲');renderTavern();return}
 if(type==='drink'){const cost=6;if(p.gold<cost){showToast('Недостаточно золота',`Кружка и отдых стоят ${cost} золота.`,'bad','💰');return}p.gold-=cost;const before=p.energy;advanceTime(30,'Ты проводишь время за кружкой в таверне');p.cityMood=Math.min(100,p.cityMood+5);p.energy=Math.min(100,p.energy+6);playWorldSfx('drink');playWorldSfx('coin');showToast('Ты выпил и отдохнул',`Бодрость +${p.energy-before}. Настроение города +5. Потрачено ${cost} золота.`,'good','🍺');save();renderTavern();return}
 if(type==='sleep'){const beforeH=p.hunger;const beforeHp=p.hp;const beforeGold=p.gold;if(!sleepAtInn())return;showToast('Комната оплачена',`8 часов сна. Здоровье +${Math.max(0,p.hp-beforeHp)}, бодрость восстановлена. Снято ${beforeGold-p.gold} золота.`,'good','🛏️',2800);renderTavern();return}
 if(type==='dice'){if(p.gold<15){showToast('Недостаточно золота','Для игры нужно 15 золота.','bad','🎲');return}p.gold-=15;advanceTime(25,'Ты играешь в кости');if(Math.random()<.48){p.gold+=35;showToast('Ты выиграл','Получено 35 золота. Чистый выигрыш: +20.','good','🎲')}else{showToast('Не повезло','Ты проиграл ставку 15 золота.','bad','🎲')}renderTavern();return}
 if(type==='bard'){const cost=5;if(p.gold<cost){showToast('Недостаточно золота',`Послушать барда стоит ${cost} золота.`,'bad','💰');return}p.gold-=cost;advanceTime(20,'Ты слушаешь барда');p.energy=Math.min(100,p.energy+5);p.cityMood=Math.min(100,p.cityMood+3);playWorldSfx('coin');showToast('Музыка закончилась',`Ты немного отдохнул. Бодрость +5, настроение города +3. Потрачено ${cost} золота.`,'good','🎵');save();renderTavern();return}
 if(type==='innkeeper') {
  if(p.tavernInnkeeperDay!==p.day){p.tavernInnkeeperDay=p.day;p.tavernInnkeeperUses=0;}
  const used=Number(p.tavernInnkeeperUses||0);
  if(used>=3){
    showToast('На сегодня всё готово','Мы всё сделали по таверне. Приходи завтра — отдохнём и снова возьмёмся за дела.','info','🧹',3200);
    renderTavern();
    return;
  }
  advanceTime(25,'Ты помогаешь хозяину таверны');
  // День мог смениться во время работы — фиксируем награду за исходный игровой день.
  const workDay=p.day;
  if(p.tavernInnkeeperDay!==workDay){p.tavernInnkeeperDay=workDay;p.tavernInnkeeperUses=0;}
  const reward=10+Math.floor(Math.random()*16);
  p.gold+=reward;
  p.cityMood=Math.min(100,p.cityMood+2);
  p.tavernInnkeeperUses=Number(p.tavernInnkeeperUses||0)+1;
  const left=Math.max(0,3-p.tavernInnkeeperUses);
  if(left===0){
    showToast('Хозяин доволен','Ты всё сделал на сегодня. Мы всё закончили — приходи завтра.','good','🧹',3200);
  } else {
    showToast('Хозяин благодарит тебя',`Ты помог с делами и получил ${reward} золота. Осталось работ на сегодня: ${left}.`,'good','🧹',2400);
  }
  save();
  renderTavern();
  return;
 }
 if(type==='talk'){startTavernMeeting();return}
}
function tavernVisitorPool(){return [['Эйлин','Охотница','Спокойная, наблюдательная и любит лес.','🏹',true],['Марек','Наёмник','Ищет работу и надёжных людей.','⚔️',false],['Селия','Торговка','Путешествует между городами и знает цены.','🛒',true],['Торвин','Кузнец','Мечтает открыть собственную кузницу.','🔨',false],['Нира','Ученица мага','Ищет древние книги и редкие заклинания.','🔮',true],['Бранд','Рыбак','Знает почти все слухи у воды.','🎣',false],['Лира','Музыкантка','Играет на лютне и собирает истории путешественников.','🎵',true],['Дагар','Караванщик','Ездит между Вайтраном и Рифтеном.','🐎',false]]}
function startTavernMeeting(){ensureLivingState();const pool=tavernVisitorPool();const unknown=pool.filter(x=>!(p.knownPeople||[]).some(v=>v.name===x[0]));const x=(unknown.length?unknown:pool)[Math.floor(Math.random()*(unknown.length?unknown.length:pool.length))];let n=p.knownPeople.find(v=>v.name===x[0]);if(!n){n={name:x[0],role:x[1],about:x[2],icon:x[3],relation:Math.floor(Math.random()*16)+5,romance:0,friend:false,knownDay:p.day,city:p.loc};p.knownPeople.push(n)}else{n.city=p.loc}p.tavernVisitor=n.name;p.tavernMeeting={stage:0,spent:false};advanceTime(10,`Ты замечаешь ${n.name} в таверне`);showToast('Новое знакомство',`${n.name} — ${n.role}. Можно начать разговор.`,'good','👤',1800);save();renderTavernMeeting()}
function tavernMeetingAction(action){const name=p.tavernVisitor;const n=(p.knownPeople||[]).find(v=>v.name===name);if(!n)return closeTavernModal();if(!p.tavernMeeting)p.tavernMeeting={stage:0,spent:false};if(action==='intro'){const g=3+Math.floor(Math.random()*4);n.relation=Math.min(100,n.relation+g);p.tavernMeeting.stage=Math.max(1,p.tavernMeeting.stage);advanceTime(8,`Ты представился ${name}`);showToast('Разговор начался',`Отношения с ${name} +${g}.`,'good','💬',1800)}else if(action==='gift'){if(p.gold<8){showToast('Недостаточно золота','Угостить посетителя стоит 8 золота.','bad','💰');return}p.gold-=8;const g=6+Math.floor(Math.random()*5);n.relation=Math.min(100,n.relation+g);n.romance=Math.min(100,(n.romance||0)+2);p.tavernMeeting.spent=true;advanceTime(10,`Ты угостил ${name}`);showToast('Гость оценил жест',`Отношения +${g}, романтика +2. Потрачено 8 золота.`,'good','🍺',2200)}else if(action==='ask'){const rumors=['На рынке сегодня поднялись цены на железо.','У западных ворот видели подозрительных наёмников.','Говорят, завтра в городе будет маленький праздник.','Караван из Рифтена должен прибыть поздно вечером.'];const rumor=rumors[Math.floor(Math.random()*rumors.length)];n.relation=Math.min(100,n.relation+2);p.tavernMeeting.stage=Math.max(1,p.tavernMeeting.stage);advanceTime(8,`Ты расспрашиваешь ${name} о городе`);showToast('Новый слух',rumor,'info','👂',3000)}else if(action==='flirt'){const g=4+Math.floor(Math.random()*4);n.relation=Math.min(100,n.relation+g);n.romance=Math.min(100,(n.romance||0)+g);advanceTime(8,`Ты флиртуешь с ${name}`);showToast('Между вами появилась искра',`Отношения +${g}, романтика +${g}.`,'good','❤️',2200)}else if(action==='friend'){if(n.relation<35){showToast('Пока слишком рано',`Сначала лучше узнать ${name} получше.`,'warn','🤝');return}n.friend=true;n.relation=Math.min(100,n.relation+5);advanceTime(5,`Ты предлагаешь ${name} дружбу`);showToast('Новый друг',`${name} теперь считает тебя другом.`,'good','🤝',2200)}else if(action==='companion'){if(n.relation<60||!n.friend){showToast('Доверие ещё недостаточно',`Для совместного путешествия нужно дружелюбие и отношения 60+.`,'warn','🧭');return}if(!p.companions.includes(n.name)){p.companions.push(n.name);addLog(`🤝 ${n.name} присоединяется к твоему отряду.`,'good');showToast('Новый спутник',`${n.name} присоединяется к твоему отряду.`,'good','🧭',2400)}else showToast('Уже с тобой',`${n.name} уже входит в твой отряд.`,'info','🤝')}else if(action==='leave'){p.tavernVisitor=null;p.tavernMeeting=null;closeTavernModal();renderTavern();return}save();renderTavernMeeting()}
function renderTavernMeeting(){const n=(p.knownPeople||[]).find(v=>v.name===p.tavernVisitor);if(!n)return renderTavern();const stage=p.tavernMeeting?.stage||0;const friend=!!n.friend;const canCompanion=friend&&n.relation>=60;const romance=(n.romance||0);const actions=[`<button class="btn cyan" onclick="tavernMeetingAction('intro')">💬 Представиться и поговорить</button>`,`<button class="btn" onclick="tavernMeetingAction('ask')">👂 Спросить о городе и слухах</button>`,`<button class="btn" onclick="tavernMeetingAction('gift')">🍺 Угостить за 8 золота</button>`,`<button class="btn" onclick="tavernMeetingAction('flirt')">❤️ Немного пофлиртовать</button>`,`<button class="btn" onclick="tavernMeetingAction('friend')">🤝 Предложить дружбу</button>`];if(canCompanion)actions.push(`<button class="btn blue" onclick="tavernMeetingAction('companion')">🧭 Предложить путешествовать вместе</button>`);actions.push(`<button class="btn red" onclick="tavernMeetingAction('leave')">👋 Попрощаться</button>`);const modal=document.createElement('div');modal.id='tavernModal';modal.className='tavern-modal-backdrop';modal.innerHTML=`<div class="tavern-modal"><div class="kicker">ТРАКТИР • ВАЙТРАН • ${esc(timeLabel())}</div><h3>${esc(n.icon||'👤')} ${esc(n.name)}</h3><p>${esc(n.role)} • ${esc(n.about)}</p><div class="tavern-statline"><span class="tavern-chip">🤝 Отношения ${n.relation}/100</span><span class="tavern-chip romance">❤️ Романтика ${romance}/100</span>${friend?'<span class="tavern-chip friend">🤝 Друг</span>':''}</div><div class="tavern-dialog">${stage?`«Рад, что мы познакомились. Может, ещё поговорим?»`:`«Привет. Не часто вижу тебя здесь. Как тебя зовут?»`}</div><div class="tavern-dialog-actions">${actions.join('')}</div></div>`;document.body.appendChild(modal)}
function meetPerson(){startTavernMeeting()}
function talkPerson(name){const n=p.knownPeople.find(x=>x.name===name);if(!n)return;advanceTime(15,`Ты разговариваешь с ${name}`);const gain=1+Math.floor(Math.random()*4);n.relation=Math.min(100,n.relation+gain);if(n.relation>=35)n.friend=true;addLog(`💬 ${name}: «Рад снова тебя видеть». Отношения +${gain}.`,'good');save();renderPeople()}
function recruitKnown(name){const n=p.knownPeople.find(x=>x.name===name);if(!n||n.relation<45)return addLog('Сначала нужно укрепить доверие этого человека.','bad');if(!p.companions.includes(name)){p.companions.push(name);addLog(`🤝 ${name} присоединяется к твоему отряду.`,'good');save()}renderPeople()}
function treeUnlocked(id){return p.abilities.includes(id)}
function treeNodeCost(tree,idx){return 3+(idx*2)+Math.floor(idx/2)}
function treeNodeLevelReq(idx){return 2+(idx*5)}
function treeNodeSkillReq(idx){return 20+(idx*15)}
function spendSkillPoint(treeId,nodeId){const tree=skillTrees[treeId]||[];const idx=tree.findIndex(n=>n.id===nodeId);const node=tree[idx];if(!node)return;if(treeUnlocked(node.id)){addLog('Эта способность уже изучена.','bad');renderProfile();return}const cost=treeNodeCost(tree,idx),lvlReq=treeNodeLevelReq(idx),skillReq=treeNodeSkillReq(idx);if(p.level<lvlReq)return addLog(`Нужен ${lvlReq}-й уровень для этого узла.`,'bad');if((p.skills?.[node.skill]||0)<skillReq)return addLog(`Навык «${node.skill}» должен быть не ниже ${skillReq}.`,'bad');if(p.skillPoints<cost){addLog(`Нужно ${cost} очков развития.` ,'bad');renderProfile();return}if(idx>0&&!treeUnlocked(tree[idx-1].id)){addLog('Сначала изучи предыдущий узел ветки.','bad');renderProfile();return}p.skillPoints-=cost;p.abilities.push(node.id);p.skills[node.skill]=Math.min(100,(p.skills[node.skill]||0)+5);addLog(`✨ Изучено умение: ${node.name}.`,'good');save();renderProfile()}

function worldInfluenceRecord(kind,city,text,delta=0){
  ensureLivingState();
  p.worldInfluence=p.worldInfluence||{decisions:0,helped:0,harmed:0,reputation:0};
  p.worldEngine.heroInfluence=p.worldEngine.heroInfluence||{decisions:0,helped:0,harmed:0,reputation:0};
  p.worldInfluence.decisions++;p.worldEngine.heroInfluence.decisions++;
  if(kind==='help'){p.worldInfluence.helped++;p.worldEngine.heroInfluence.helped++}
  if(kind==='harm'){p.worldInfluence.harmed++;p.worldEngine.heroInfluence.harmed++}
  p.worldInfluence.reputation=Math.max(-100,Math.min(100,(p.worldInfluence.reputation||0)+delta));
  p.worldEngine.heroInfluence.reputation=Math.max(-100,Math.min(100,(p.worldEngine.heroInfluence.reputation||0)+delta));
  if(city)worldEngineRecordEvent(city,`🧭 ${text}`,'info');
}
function worldNpcSceneClass(name){const role=(npcDb[name]?.role||'').toLowerCase();if(role.includes('страж'))return 'guard';if(role.includes('торгов'))return 'merchant';if(role.includes('бард'))return 'bard';return 'citizen'}
function npcSceneFigure(n,i){
  const role=worldNpcSceneClass(n.name);const cfg={guard:{coat:'#3d4d58',metal:'#9ba8ad',accent:'#9e7851',skin:'#a66f53',hair:'#2f2725'},merchant:{coat:'#654b38',metal:'#6f756f',accent:'#b78b5a',skin:'#b98365',hair:'#4a3224'},bard:{coat:'#5d4053',metal:'#82706c',accent:'#c89c56',skin:'#b47d62',hair:'#3a292b'},citizen:{coat:'#314b51',metal:'#6d7777',accent:'#8d6b4c',skin:'#ad7a5e',hair:'#46342b'}}[role]||{coat:'#314b51',metal:'#6d7777',accent:'#8d6b4c',skin:'#ad7a5e',hair:'#46342b'};
  const title={guard:'Стражник',merchant:'Торговец',bard:'Бард',citizen:'Житель'}[role]||'Житель';
  const weapon=role==='guard'?'<path d="M122 78 L138 27" stroke="#d7e0e3" stroke-width="5"/><path d="M119 75 L133 78" stroke="#9e7851" stroke-width="5"/><path d="M90 77 Q74 70 68 87 L74 101 Q85 104 94 95" fill="#4f6873" stroke="#d9d6c7" stroke-width="2"/>':role==='merchant'?'<path d="M20 77 Q10 95 28 112" stroke="#7c5a3d" stroke-width="13" fill="none"/><circle cx="24" cy="113" r="7" fill="#b78b5a"/>':role==='bard'?'<ellipse cx="123" cy="88" rx="12" ry="20" fill="#8b6043"/><path d="M118 76 Q108 68 110 54" stroke="#c99b63" stroke-width="3"/>':'';
  const svg=`<svg class="npc-3d-svg" viewBox="0 0 160 220" aria-hidden="true"><defs><linearGradient id="body${i}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity=".18"/><stop offset=".35" stop-color="${cfg.coat}"/><stop offset="1" stop-color="#0a1115"/></linearGradient><linearGradient id="metal${i}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e2e7e6"/><stop offset=".45" stop-color="${cfg.metal}"/><stop offset="1" stop-color="#2a3337"/></linearGradient><radialGradient id="skin${i}" cx="32%" cy="25%"><stop offset="0" stop-color="#e0aa86"/><stop offset=".55" stop-color="${cfg.skin}"/><stop offset="1" stop-color="#5a3d35"/></radialGradient></defs><ellipse cx="80" cy="203" rx="42" ry="8" fill="#000" opacity=".45"/><g class="npc-3d-body"><path d="M51 61 Q80 48 109 61 L119 104 Q112 122 80 125 Q48 122 41 104Z" fill="url(#body${i})" stroke="#c7d0cd" stroke-opacity=".18"/><path d="M55 66 Q80 56 105 66 L100 92 Q80 102 60 92Z" fill="url(#metal${i})" opacity=".72"/><rect x="57" y="89" width="46" height="7" rx="3" fill="${cfg.accent}" opacity=".92"/><path d="M51 73 Q37 82 34 105" stroke="url(#body${i})" stroke-width="13" stroke-linecap="round"/><path d="M109 73 Q123 82 126 105" stroke="url(#body${i})" stroke-width="13" stroke-linecap="round"/><circle cx="34" cy="108" r="7" fill="url(#skin${i})"/><circle cx="126" cy="108" r="7" fill="url(#skin${i})"/><path d="M64 120 L58 181" stroke="#182025" stroke-width="17" stroke-linecap="round"/><path d="M96 120 L102 181" stroke="#182025" stroke-width="17" stroke-linecap="round"/><path d="M54 184 L39 202" stroke="#11181d" stroke-width="12" stroke-linecap="round"/><path d="M106 184 L121 202" stroke="#11181d" stroke-width="12" stroke-linecap="round"/><ellipse cx="80" cy="40" rx="25" ry="29" fill="url(#skin${i})" stroke="#d8c1aa" stroke-opacity=".2"/><path d="M58 37 Q61 7 80 10 Q102 7 104 39 Q96 27 80 28 Q66 28 58 37Z" fill="${cfg.hair}"/><path d="M68 43 Q72 39 76 43 M84 43 Q88 39 92 43" stroke="#2a2220" stroke-width="3" stroke-linecap="round"/><path d="M71 56 Q80 61 89 56" stroke="#4d312e" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M65 66 Q80 58 95 66" stroke="#d7e0df" stroke-opacity=".22" stroke-width="4" fill="none"/>${weapon}</g></svg>`;
  return `<button type="button" class="npc-realistic npc-${role} n${i+1}" onclick="npcAction(decodeURIComponent('${encodeURIComponent(n.name)}'))" aria-label="${esc(n.name)}"><span class="npc-depth-shadow"></span>${svg}<span class="npc-nameplate"><b>${esc(n.name)}</b><small>${esc(n.place||title)}</small></span></button>`;
}
function livingNpcCycle(snap){
  const hour=Number(p.hour||8);
  const day=Number(p.day||1);
  const pool=(snap.npcs||[]).filter(n=>n.alive);
  const fallback=[
    {name:'Капитан стражи',role:'Стражник',place:'Патруль'},
    {name:'Кузнец Адрианна',role:'Кузнец',place:'Кузница'},
    {name:'Караванщик Лод',role:'Караванщик',place:'Рынок'},
    {name:'Фаэндаль',role:'Лучник',place:'Улица'}
  ];
  const candidates=pool.length?pool:fallback;
  const morning=['Капитан стражи','Кузнец Адрианна','Караванщик Лод','Фаэндаль'];
  const dayCast=['Торговец Мадези','Кузнец Адрианна','Караванщик Лод','Гердур'];
  const evening=['Фаэндаль','Вунферт','Караванщик Лод','Капитан стражи'];
  const night=['Капитан стражи','Вунферт','Путник','Торговец Мадези'];
  const wished=hour<10?morning:(hour<18?dayCast:(hour<22?evening:night));
  const found=[];
  wished.forEach(name=>{const n=candidates.find(x=>x.name===name)||pool.find(x=>x.name===name)||fallback.find(x=>x.name===name);if(n&&!found.some(x=>x.name===n.name))found.push(n)});
  let idx=(day+Math.floor(hour/2))%Math.max(1,candidates.length);
  while(found.length<4&&found.length<candidates.length){const n=candidates[idx%candidates.length];idx++;if(n&&!found.some(x=>x.name===n.name))found.push(n)}
  if(found.length<4)fallback.forEach(n=>{if(found.length<4&&!found.some(x=>x.name===n.name))found.push(n)});
  return found.slice(0,4);
}
const sceneLocationAssets={'Вайтран':'whiterun_scene_clean','Ривервуд':'rivervud','Рифтен':'riften','Виндхельм':'vindhelm','Солитьюд':'solityud','Фолкрит':'folkrit','Морфал':'morfal','Данстар':'danstar','Айварстед':'ayvarsted','Рорикстед':'roriksted','Хелген':'helgen','Драконий мост':'drakoniy_most','Картвастен':'kartvasten','Шорс-Стон':'shors_ston','Каменные холмы':'kamennye_holmy','Торговый тракт':'torgovyy_trakt','Ледяной берег':'ledyanoy_bereg','Черный перевал':'chernyy_pereval','Высокий Хротгар':'vysokiy_hrotgar','Заброшенный форт':'zabroshennyy_fort','Снежная пещера':'sne_naya_peschera','Старые руины':'starye_ruiny','Туманный лес':'tumannyy_les','Озеро Хьялмарк':'ozero_hyalmark','Красный перевал':'krasnyy_pereval','Долина охотников':'dolina_ohotnikov'};
const sceneNpcPools={
'Вайтран':['Ярл Балгруф','Кузнец Адрианна','Караванщик Лод','Капитан стражи','Фаренгар'],
'Ривервуд':['Гердур','Ортор','Фаэндаль','Альвор','Сигрид'],
'Рифтен':['Бриньольф','Торговец Мадези','Сапфир','Мариса','Страж ворот'],
'Виндхельм':['Вунферт','Кузнец Орит','Капитан стражи','Гульмей','Борри'],
'Солитьюд':['Тит Медиус','Фальк Огненный Борода','Сейда','Капитан Аста','Торговец Белетор'],
'Фолкрит':['Нари','Денгейр','Охотник Сонд','Хильда','Талос Хранитель'],
'Морфал':['Лейла','Алхимик Лами','Мастер болот','Селий','Виола Джордано'],
'Данстар':['Скалд','Капитан Хальд','Торговец Редди','Рыбак','Бринья'],
'Айварстед':['Климмек','Жена лесника','Тельрав','Фермер Ингольф','Паломник'],
'Рорикстед':['Рорик','Юрга','Фермер Гром','Караванщик Лод','Охотница Мира'],
'Хелген':['Выживший солдат','Бродячий торговец','Разведчик','Раненый стражник','Наёмник'],
'Драконий мост':['Хозяйка трактира','Старый ветеран','Караванщик Лод','Страж моста','Путник'],
'Картвастен':['Кузнец Ральф','Шахтер Эйнар','Скупщик руды','Шахтер Халдин','Охранник шахты'],
'Шорс-Стон':['Шахтер Халдин','Скупщик руды','Шахтер Эйнар','Торговец Мадези','Страж шахты'],
'Каменные холмы':['Охотник-отшельник','Исследователь','Проводник Ральф','Разведчик','Паломник'],
'Торговый тракт':['Купец Алдар','Наемная охрана','Караванщик Лод','Страж дороги','Путник'],
'Ледяной берег':['Пират-перебежчик','Рыбак','Моряк Эйрик','Караванщик','Следопыт'],
'Черный перевал':['Следопыт','Разведчик','Наемник','Страж дороги','Проводник'],
'Высокий Хротгар':['Учитель Голоса','Паломник','Старший монах','Ученик','Хранитель храма'],
'Заброшенный форт':['Заключенный','Контрабандист','Бандит-наемник','Скаут','Воин'],
'Снежная пещера':['Пленник','Исследователь','Охотник','Разведчик','Бродяга'],
'Старые руины':['Исследователь','Пилигрим','Охотница Элия','Маг-археолог','Страж руин'],
'Туманный лес':['Следопытка Элия','Охотник Бран','Травница','Следопыт','Бродячая охотница'],
'Озеро Хьялмарк':['Алхимик','Рыбак','Охотник','Лодочник','Травница'],
'Красный перевал':['Караванщик','Страж дороги','Наемник','Охотник','Купец'],
'Долина охотников':['Охотник Бран','Охотница Элия','Следопыт','Кожевник','Рыбак']
};
function sceneNpcRole(name){const low=String(name||'').toLowerCase();if(npcDb[name]?.role)return npcDb[name].role;if(/страж|капитан|охран|воин|солдат|сержант|скаут/.test(low))return 'Стражник';if(/торгов|купец|караван|скупщик/.test(low))return 'Торговец';if(/кузнец/.test(low))return 'Кузнец';if(/шахтер|шахт/.test(low))return 'Шахтёр';if(/алхим|маг/.test(low))return 'Маг';if(/охот|следопыт|кожев/.test(low))return 'Охотник';if(/монах|паломник|учитель голоса|хранитель храма|ученик/.test(low))return 'Монах';if(/рыбак|лодочник|моряк|пират/.test(low))return 'Рыбак';return 'Житель'}
function ensureSceneNpc(name){if(npcDb[name])return;const role=sceneNpcRole(name);npcDb[name]={role,about:`Житель локации ${p.loc}. Его жизнь зависит от времени суток и событий мира.`,rumors:['Город живёт своей жизнью.','Ночью на дорогах особенно неспокойно.'],quests:[]};}
function renderLivingCityScene(snap){
  const loc=p.loc; const asset=sceneLocationAssets[loc]||'whiterun_scene_clean'; const pool=(sceneNpcPools[loc]||world[loc]?.npcs||['Житель','Торговец','Стражник','Путник']).map(String); pool.forEach(ensureSceneNpc);
  const period=timeLabel(); const bucket=['утро','день','вечер','ночь'].indexOf(String(period).toLowerCase().split(' ')[0]); const start=(p.day*3+Math.floor(p.hour/2)+Math.max(0,bucket)*2)%pool.length;
  const list=[]; for(let i=0;i<Math.min(4,pool.length);i++) list.push(pool[(start+i*2)%pool.length]);
  const defaultSlots=[['s1','18%','57%'],['s2','42%','64%'],['s3','64%','49%'],['s4','76%','63%']];
  const whiterunSlots=[['s1','72%','10%'],['s2','18%','48%'],['s3','46%','30%'],['s4','73%','48%']];
  const slots=(loc==='Вайтран'?whiterunSlots:defaultSlots);
  const spots=list.map((name,i)=>{const [cl,left,top]=slots[i];const role=sceneNpcRole(name);const cover=(loc==='Вайтран'&&i===0)?' cover-npc':'';return `<button type="button" class="npc-hotspot ${cl}${cover}" style="left:${left};top:${top}" onclick="npcAction(decodeURIComponent('${encodeURIComponent(name)}'))" aria-label="${esc(name)}"><b>${esc(name)}</b><span>${esc(role)}</span></button>`}).join('');
  const cleanMask=(loc==='Вайтран')?'<div class="scene-clean-mask whiterun-mask" aria-hidden="true"></div>':'';
  return `<div class="living-city-scene city-realistic dynamic-location-scene" style="--scene-image:url('world/${asset}.jpg')"><div class="realistic-backdrop"></div><div class="scene-dark-top"></div><div class="realistic-vignette"></div><div class="realistic-fog"></div><div class="realistic-light l1"></div><div class="realistic-light l2"></div><div class="realistic-embers"><i></i><i></i><i></i><i></i></div><div class="npc-cycle">${esc(period)} • жители меняются</div>${cleanMask}${spots}<div class="scene-interact-hint">Нажми на NPC — поговорить, узнать слухи, взять работу, торговать или изменить отношения</div></div>`
}
function chooseIncidentAction(city,type,action){
  ensureLivingState();
  const inc=(p.worldEngine.incidents||[]).find(x=>x.city===city&&x.type===type&&x.expiresDay>=p.day);
  if(!inc){showToast('Событие уже прошло','Мир уже изменился.','info','ℹ️',1800);renderWorld();return}
  const c=p.worldEngine.cities[city]; let outcome=''; let kind='help'; let delta=0; let reward=0;
  const charisma=(p.attributes?.Харизма||5)+(p.skills?.Красноречие||0)/8;
  if(type==='mercenaries'){
    if(action==='fight'){startIncidentBattle(city,type,'Наемник');return}
    if(action==='guard'){if(p.gold<20){showToast('Не хватает золота','Стража просит 20 золота.','bad','💰',1800);return}p.gold-=20;c.security=Math.min(95,c.security+4);c.tension=Math.max(0,(c.tension||20)-5);outcome='Ты заплатил за помощь стражи. Наёмники отступили.';reward=0}
    else if(action==='negotiate'){if(Math.random()<(0.35+charisma/100)){c.security=Math.min(95,c.security+2);c.tension=Math.max(0,(c.tension||20)-3);outcome='Ты договорился с главарём. Группа ушла без боя.';reward=6}else{outcome='Переговоры провалились. Наёмники напали.';worldInfluenceRecord('harm',city,'Твои переговоры с наёмниками провалились.',-1);save();startIncidentBattle(city,type,'Наемник');return}}
    else {kind='neutral';c.security=Math.max(20,c.security-5);c.tension=Math.min(100,(c.tension||20)+8);outcome='Ты прошёл мимо. Через некоторое время стража сообщила о новых проблемах.';delta=-2}
  } else if(type==='road_attack'){
    if(action==='fight'){startIncidentBattle(city,type,'Бандит');return}
    if(action==='guard'){if(p.gold<10){showToast('Не хватает золота','На срочный вызов стражи нужно 10 золота.','bad','💰',1800);return}p.gold-=10;c.security=Math.min(95,c.security+3);c.economy=Math.max(75,c.economy-1);outcome='Стража успела к каравану и отбила нападение.'}
    else if(action==='bribe'){if(p.gold<25){showToast('Не хватает золота','Нападающие требуют 25 золота.','bad','💰',1800);return}p.gold-=25;c.economy=Math.min(135,c.economy+2);outcome='Ты заплатил нападающим. Караван продолжил путь, но преступники получили деньги.';kind='harm';delta=-1}
    else {c.economy=Math.max(75,c.economy-6);c.security=Math.max(20,c.security-3);c.tension=Math.min(100,(c.tension||20)+9);outcome='Ты не вмешался. Караван потерял часть груза, цены на рынке выросли.';kind='harm';delta=-4}
  } else if(type==='crime'){
    if(action==='guard'){c.security=Math.min(95,c.security+7);c.morale=Math.min(95,c.morale+2);c.tension=Math.max(0,(c.tension||20)-7);outcome='Ты помог страже задержать подозреваемого.'}
    else if(action==='investigate'){advanceTime(30,'Ты расследуешь преступление');if(Math.random()<0.65){c.security=Math.min(95,c.security+5);reward=12;outcome='Ты нашёл улику и помог раскрыть преступление.'}else{c.tension=Math.min(100,(c.tension||20)+3);outcome='След оборвался. Преступник скрылся.';kind='neutral'}}
    else if(action==='negotiate'){if(Math.random()<(0.35+charisma/100)){c.tension=Math.max(0,(c.tension||20)-4);outcome='Ты убедил подозреваемого сдаться мирно.'}else{outcome='Разговор не помог. Стража продолжит поиски.';kind='neutral'}}
    else {c.security=Math.max(20,c.security-5);c.tension=Math.min(100,(c.tension||20)+7);outcome='Ты решил не вмешиваться. Преступники почувствовали безнаказанность.';kind='harm';delta=-3}
  } else if(type==='fire'){
    if(action==='help'){advanceTime(45,'Ты помогаешь тушить пожар');c.security=Math.min(95,c.security+2);c.morale=Math.min(95,c.morale+4);c.economy=Math.max(75,c.economy-2);outcome='Ты помог потушить пожар и спасти часть квартала.'}
    else if(action==='water'){p.st=Math.max(0,p.st-6);advanceTime(20,'Ты носишь воду к пожару');c.morale=Math.min(95,c.morale+3);outcome='Ты таскал воду, пока пожар не удалось локализовать.'}
    else if(action==='guard'){c.security=Math.min(95,c.security+4);c.morale=Math.min(95,c.morale+2);outcome='Ты организовал людей и помог стражникам оцепить квартал.'}
    else {c.economy=Math.max(70,c.economy-7);c.morale=Math.max(15,c.morale-6);c.tension=Math.min(100,(c.tension||20)+8);outcome='Ты ушёл. Огонь уничтожил часть запасов и домов.';kind='harm';delta=-5}
  } else if(type==='horses'){
    if(action==='catch'){p.st=Math.max(0,p.st-8);advanceTime(20,'Ты ловишь сорвавшихся лошадей');reward=8+Math.floor(Math.random()*5);p.gold+=reward;c.morale=Math.min(95,c.morale+2);outcome=`Ты поймал лошадей и получил ${reward} золота.`}
    else if(action==='stable'){if(p.gold<3){showToast('Не хватает золота','Конюху нужно 3 золота.','bad','💰',1800);return}p.gold-=3;advanceTime(10,'Ты зовёшь конюха');c.morale=Math.min(95,c.morale+1);outcome='Конюх быстро успокоил животных.'}
    else if(action==='calm'){if(Math.random()<(0.4+(p.skills?.Красноречие||0)/120+(p.attributes?.Воля||5)/120)){c.morale=Math.min(95,c.morale+2);outcome='Ты успокоил животных и помог вернуть их владельцам.'}else{p.st=Math.max(0,p.st-5);outcome='Лошади испугались ещё сильнее. К счастью, конюхи быстро помогли.';kind='neutral'}}
    else {c.economy=Math.max(75,c.economy-3);c.tension=Math.min(100,(c.tension||20)+3);outcome='Ты не вмешался. Несколько торговых мест пришлось закрыть.';kind='harm';delta=-2}
  } else if(type==='shortage'){
    if(action==='food'){const foodItem=['Хлеб','Мясо','Рыба','Суп'].find(x=>(p.inv||[]).some(v=>v[0]===x&&v[1]>0));if(!foodItem){showToast('Нет еды','Нужны хлеб, мясо, рыба или суп.','warn','🍞',1800);return}removeItem(foodItem);c.food=Math.min(160,(c.food||100)+10);c.morale=Math.min(95,c.morale+3);outcome=`Ты отдал горожанам ${foodItem}.`}
    else if(action==='buy'){if(p.gold<18){showToast('Не хватает золота','Нужно 18 золота.','bad','💰',1800);return}p.gold-=18;c.food=Math.min(160,(c.food||100)+12);c.morale=Math.min(95,c.morale+2);c.economy=Math.min(135,c.economy+1);outcome='Ты закупил продовольствие для города.'}
    else if(action==='negotiate'){if(Math.random()<(0.35+charisma/100)){c.food=Math.min(160,(c.food||100)+7);c.economy=Math.min(135,c.economy+1);outcome='Ты убедил торговцев отдать часть запасов по честной цене.'}else{outcome='Торговцы отказались. Дефицит пока остаётся.';kind='neutral'}}
    else {c.food=Math.max(20,(c.food||100)-12);c.morale=Math.max(15,c.morale-6);c.economy=Math.max(75,c.economy-3);outcome='Ты не вмешался. Цены на еду выросли, жители недовольны.';kind='harm';delta=-4}
  }
  if(reward)p.gold+=reward;
  if(kind!=='neutral')worldInfluenceRecord(kind,city,`${outcome}`,delta+(kind==='help'?2:0)); else worldInfluenceRecord('neutral',city,outcome,0);
  worldEngineClearIncident(city,type);
  worldEngineRecordEvent(city,`🌍 Последствие твоего решения: ${outcome}`,kind==='help'?'good':kind==='harm'?'bad':'info');
  if(reward)worldEngineRecordEvent(city,`💰 Ты получил ${reward} золота.`,'good');
  addLog(`🧭 ${outcome}`,kind==='help'?'good':kind==='harm'?'bad':'info');
  save();showToast('Мир отреагировал',outcome,kind==='help'?'good':kind==='harm'?'bad':'info','🌍',2600);renderWorld();
}
function renderDecisionCard(inc){
  const opts=incidentDecisionOptions(inc);if(!opts.length)return worldIncidentActions(inc);
  const c=encodeURIComponent(inc.city),t=encodeURIComponent(inc.type);
  return `<div class="decision-actions">${opts.map(([a,label,meta])=>`<button type="button" class="choice" onclick="chooseIncidentAction(decodeURIComponent('${c}'),decodeURIComponent('${t}'),'${a}')"><strong>${label}</strong><small class="choice-consequence">${meta}</small></button>`).join('')}</div>`;
}


// ===== NORD RAID SYSTEM V2 — DUNGEON RUN =====
window.saveGame = window.saveGame || function(){ save(); };

window.nordRaids = window.nordRaids || {
  caves:[
    {id:'forgotten_pass',name:'Забытый проход',subtitle:'Ледяные катакомбы под древним курганом',danger:3,boss:'Драугр-Повелитель',enemies:['Драугры','Морозные пауки','Скелеты'],reward:420,color:'ice'},
    {id:'old_mine',name:'Старая шахта',subtitle:'Заброшенные штольни двемеров',danger:6,boss:'Двемерский центурион',enemies:['Драугры','Фалмеры','Паучьи механизмы'],reward:780,color:'amber'},
    {id:'cursed_cave',name:'Проклятая пещера',subtitle:'Затерянный храм, где не гаснет чёрный огонь',danger:9,boss:'Древний вампир',enemies:['Фалмеры','Чаурусы','Вампиры'],reward:1350,color:'blood'}
  ],
  monsters:[
    ['Скелеты',44,9,1.00],['Морозные пауки',50,11,1.04],['Драугры',62,14,1.08],['Фалмеры',70,16,1.10],['Чаурусы',74,17,1.12],['Тролли',82,20,1.18],['Вампиры',88,21,1.20],['Двемерские сферы',92,22,1.22],['Паучьи механизмы',96,24,1.25]
  ]
};

const RAID_RARITIES=[
  {id:'common',name:'Обычная',icon:'⚪',chance:.66,mul:1.00},
  {id:'uncommon',name:'Необычная',icon:'🟢',chance:.23,mul:1.16},
  {id:'rare',name:'Редкая',icon:'🔵',chance:.085,mul:1.34},
  {id:'epic',name:'Легендарная',icon:'🟣',chance:.024,mul:1.72},
  {id:'mythic',name:'Мифическая',icon:'🟠',chance:.001,mul:2.25}
]

const RAID_EVENT_DEFS=[
 {id:'tracks',title:'Кровавые следы',icon:'🩸',text:'Следы уходят в боковой тоннель. Оттуда доносится хриплое дыхание.',choices:[['follow','Пойти по следам','Высокая награда, но засада может закончить рейд.'],['observe','Наблюдать','Шанс найти обычную или редкую вещь без боя.'],['leave','Пройти мимо','Безопасно, но ты теряешь возможность добычи.']]},
 {id:'chest',title:'Сундук драугра',icon:'🧰',text:'Старый сундук покрыт инеем. На замке видны едва заметные руны.',choices:[['open','Открыть','Большой шанс на вещь, но ловушка может убить.'],['trap','Проверить ловушку','Ловкость увеличит шанс обезвредить механизм.'],['leave','Оставить','Ничего не получишь, зато не рискуешь.']]},
 {id:'altar',title:'Древний алтарь',icon:'🕯️',text:'Камень начинает гудеть, когда ты касаешься вырезанных рун.',choices:[['touch','Коснуться','Можно получить благословение, проклятие или редкий предмет.'],['pray','Помолиться','Восстановление здоровья с небольшим риском.'],['leave','Не трогать','Продолжить без последствий.']]},
 {id:'fork',title:'Тёмная развилка',icon:'🕳️',text:'Перед тобой два прохода. Из одного идёт холод, из другого — запах гнили.',choices:[['right','Холодный проход','Короткий путь, но встречаются сильные неживые.'],['left','Запах гнили','Длиннее, зато шанс на сундук.'],['wait','Подождать','Можно услышать врага раньше, но есть риск внезапной атаки.']]},
 {id:'collapse',title:'Обвал',icon:'🪨',text:'Потолок трещит. Камни сыплются всё быстрее, а путь назад уже закрывается.',choices:[['run','Бежать','Большой риск потерять здоровье или погибнуть.'],['cover','Прижаться к стене','Средний урон, высокий шанс выжить.'],['jump','Рвануть вперёд','Редкий шанс найти секретный проход.']]},
 {id:'camp',title:'Тихий костёр',icon:'🔥',text:'В заброшенном лагере ещё тлеют угли. Рядом лежит рюкзак.',choices:[['search','Обыскать','Можно найти зелье, золото или экипировку.'],['rest','Передохнуть','Восстановишь здоровье, но можешь привлечь врага.'],['leave','Не останавливаться','Самый безопасный выбор.']]},
 {id:'whisper',title:'Шёпот из саркофага',icon:'💀',text:'Каменная крышка чуть приоткрыта. Изнутри слышен голос, который произносит твоё имя.',choices:[['open','Открыть саркофаг','Очень редкая награда или немедленная смерть.'],['listen','Слушать','Можно получить знание и усиление, но есть риск проклятия.'],['seal','Запечатать','Безопасно, но шанс награды исчезает.']]}
];

const RAID_WEAPON_BASES=[
  ['Железный меч',12,'weapon','Меч'],['Железная булава',10,'weapon','Булава'],['Железный боевой топор',15,'weapon','Топор'],['Железный кинжал',8,'weapon','Кинжал'],
  ['Охотничий лук',13,'weapon','Лук'],['Стальной меч',17,'weapon','Меч'],['Стальной боевой топор',20,'weapon','Топор'],['Стальной кинжал',12,'weapon','Кинжал'],['Стальной лук',18,'weapon','Лук'],
  ['Двемерский меч',23,'weapon','Меч'],['Двемерский боевой топор',26,'weapon','Топор'],['Эбонитовый клинок',32,'weapon','Меч'],['Даэдрический меч',42,'weapon','Меч'],['Эльфийский лук',36,'weapon','Лук'],
  ['Кинжал ночного ветра',44,'weapon','Кинжал'],['Лук древнего охотника',41,'weapon','Лук']
]
const RAID_ARMOR_BASES=[
  ['Железный щит',10,'armor','Щит'],['Железный шлем',8,'armor','Шлем'],['Кожаная броня',8,'armor','Броня'],['Кожаные сапоги',3,'armor','Сапоги'],
  ['Стальной щит',15,'armor','Щит'],['Стальной шлем',12,'armor','Шлем'],['Стальная броня',22,'armor','Броня'],['Стальные сапоги',7,'armor','Сапоги'],
  ['Двемерский щит',20,'armor','Щит'],['Двемерский шлем',18,'armor','Шлем'],['Двемерская броня',30,'armor','Броня'],['Сапоги следопыта',9,'armor','Сапоги'],
  ['Эбонитовая броня',40,'armor','Броня'],['Шлем хранителя',24,'armor','Шлем'],['Корона древнего драуга',32,'armor','Шлем'],['Кираса пепельного стража',46,'armor','Броня'],['Сапоги морозного следопыта',13,'armor','Сапоги']
]

function raidRarityRoll(){let r=Math.random(),sum=0;for(const x of RAID_RARITIES){sum+=x.chance;if(r<sum)return x;}return RAID_RARITIES[0]}
function raidLootName(base,rarity){const prefixes={common:'',uncommon:'Боевой ',rare:'Закалённый ',epic:'Легендарный ',mythic:'Мифический '};return (prefixes[rarity.id]||'')+base}
function raidGiveLoot(forceMin=false){
  const rarity=raidRarityRoll();
  const pool=Math.random()<.68?RAID_WEAPON_BASES:RAID_ARMOR_BASES;
  const base=pool[Math.floor(Math.random()*pool.length)];
  const item=raidLootName(base[0],rarity);
  const source=itemDb[base[0]]||{};
  const mul=rarity.mul;
  const d={price:Math.round((source.price||100)*mul),damage:base[2]==='weapon'?Math.max(1,Math.round(base[1]*mul)):undefined,armor:base[2]==='armor'?Math.max(1,Math.round(base[1]*mul)):undefined,type:base[2],slot:base[3],rarity:rarity.id,rarityName:rarity.name,rarityIcon:rarity.icon,baseName:base[0],hpBonus:Math.round((source.hpBonus||0)*mul),mpBonus:Math.round((source.mpBonus||0)*mul),stBonus:Math.round((source.stBonus||0)*mul),damageBonus:Math.round((source.damageBonus||0)*mul)};
  itemDb[item]=d; p.generatedItems=p.generatedItems||{}; p.generatedItems[item]=d; addItem(item,1); return {item,rarity,d};
}
function raidLootText(x){return `${x.rarity.icon} ${x.item} — ${x.rarity.name}`}
function raidReadyDay(raidId){const last=Number(p.lastRaidDay||0);return !last || gameDays()-last>=3;}
function raidDaysLeft(raidId){const last=Number(p.lastRaidDay||0);return last?Math.max(0,3-(gameDays()-last)):0;}
function raidCooldownText(raidId){const n=raidDaysLeft(raidId);return n?`Все рейды закрыты ещё на ${n} игровых дн.`:'Рейды доступны сейчас';}
function raidRandomMonster(stage,raid){
  const minLvl=Math.max(9,Math.floor(8+(stage-1)*1.15+(raid?.danger||3)*.55));
  const maxLvl=7+stage*2+(raid?.danger||3);
  // Early stages stay inside a controlled level band; later stages deliberately climb into elite monsters.
  let pool=window.nordRaids.monsters.filter(x=>x[2]<=maxLvl && x[2]>=Math.max(7,minLvl-(stage<7?3:0)));
  if(stage>=7)pool=pool.filter(x=>x[2]>=minLvl);
  if(raid?.id==='forgotten_pass')pool=pool.filter(x=>!['Вампиры','Двемерские сферы'].includes(x[0]));
  if(raid?.id==='old_mine')pool=pool.filter(x=>!['Волки'].includes(x[0]));
  if(raid?.id==='cursed_cave')pool=pool.filter(x=>!['Скелеты'].includes(x[0]));
  return pool[Math.floor(Math.random()*pool.length)]||window.nordRaids.monsters[2];
}
function renderRaids(){
  const main=document.getElementById('main');if(!main)return;const day=gameDays();
  main.innerHTML=`<section class="raid-hub">
    <div class="raid-hero" style="background-image:linear-gradient(180deg,rgba(4,10,14,.05),rgba(4,8,12,.97)),url('world/chernyy_pereval.jpg')"><div class="raid-hero-top"><button class="raid-icon-btn" type="button" onclick="showScreen('world')">←</button><div class="raid-day">ДЕНЬ ${day}</div><div class="raid-rune">⚔️</div></div><div class="raid-hero-copy"><div class="raid-kicker">NORD • ПОДЗЕМЕЛЬЯ</div><h1>РЕЙДЫ</h1><p>10 этапов. 7 случайных событий. Всё может закончиться в один момент. Добыча остаётся навсегда.</p></div></div>
    <div class="raid-stats"><div><span>❤️</span><b>${Math.max(0,p.hp??100)}</b><small>здоровье</small></div><div><span>🪙</span><b>${p.gold||0}</b><small>золото</small></div><div><span>⭐</span><b>${p.level||1}</b><small>уровень</small></div><div><span>🎒</span><b>${(p.inv||[]).length}</b><small>предметы</small></div></div>
    <div class="raid-section-title"><div><span>ПОДЗЕМЕЛЬЯ</span><small>Выбери маршрут и риск</small></div><div class="raid-status-dot"></div></div>
    <div class="raid-dungeons">${window.nordRaids.caves.map(r=>{const ready=raidReadyDay(r.id);return `<article class="raid-dungeon ${r.color||''} ${ready?'':'locked'}"><div class="raid-dungeon-art" style="background-image:linear-gradient(180deg,transparent 15%,rgba(3,8,12,.98)),url('world/chernyy_pereval.jpg')"><div class="raid-danger">ОПАСНОСТЬ ${r.danger}/10</div><div class="raid-dungeon-icon">${r.color==='blood'?'☠️':r.color==='amber'?'⚙️':'❄️'}</div><div class="raid-dungeon-title"><h3>${esc(r.name)}</h3><p>${esc(r.subtitle)}</p></div></div><div class="raid-dungeon-body"><div class="raid-enemy-line"><span>Враги</span><b>${r.enemies.join(' • ')}</b></div><div class="raid-enemy-line"><span>Босс</span><b>👹 ${esc(r.boss)}</b></div><div class="raid-rewards"><span>🏆 ${r.reward} зол.</span><span>🗺️ 10 этапов</span><span>🎲 7 событий</span></div><button type="button" class="raid-main-btn" ${ready?'':'disabled'} onclick="window.startRaid('${r.id}')">${ready?'⚔️ НАЧАТЬ РЕЙД':'⏳ '+raidCooldownText(r.id)}</button></div></article>`}).join('')}</div>
    <div class="raid-warning"><span>☠️</span><div><b>СМЕРТЬ — КОНЕЦ РЕЙДА</b><small>Погиб в подземелье — забег потерян. После победы тот же рейд закроется на 3 игровых дня.</small></div></div>
  </section>`;
  try{window.updateMusicForScreen('raids')}catch(e){}
}
window.startRaid=function(id){
  const r=window.nordRaids.caves.find(x=>x.id===id);if(!r)return;
  if(!raidReadyDay(id)){showToast('Рейд ещё закрыт',raidCooldownText(id),'warn','⏳',2200);return;}
  const hp=Math.max(1,Number(p.hp||100));
  p.raidInventory=p.raidInventory||{};p.raidCooldowns=p.raidCooldowns||{};p.raidCooldowns[id]=gameDays();p.lastRaidDay=gameDays();p.activeRaid={id,name:r.name,boss:r.boss,stage:1,total:10,heroHp:hp,maxHp:Math.max(100,hp),enemyHp:0,enemyMax:0,enemy:'',enemyAttack:0,enemyArmor:0,guard:false,potions:Math.max(3,(p.inv||[]).filter(x=>x[0].includes('Зелье')).reduce((n,x)=>n+x[1],0)),loot:[],log:['⚔️ Ты входишь в подземелье. Назад дороги нет. Рейд закрыт на 3 игровых дня.'],pendingEvent:RAID_EVENT_DEFS[Math.floor(Math.random()*RAID_EVENT_DEFS.length)],eventResolved:false,bossPhase:0,eventsSeen:0,turn:1};
  save();showRaidStage();
};
function raidSetMusic(){try{window.updateMusicForScreen('raids')}catch(e){}}
function raidLog(text){const a=p.activeRaid;a.log=a.log||[];a.log.unshift(text);a.log=a.log.slice(0,8)}
function raidApplyDamage(n,reason){const a=p.activeRaid;const reduced=a.guard?Math.max(1,Math.floor(n*.35)):n;a.heroHp=Math.max(0,a.heroHp-reduced);raidLog(`💥 ${reason}: -${reduced} HP`);a.guard=false}
function raidNextEvent(){const a=p.activeRaid;a.pendingEvent=RAID_EVENT_DEFS[Math.floor(Math.random()*RAID_EVENT_DEFS.length)];a.eventResolved=false;a.eventsSeen=(a.eventsSeen||0)+1}
function raidEnemyName(a){const r=window.nordRaids.caves.find(x=>x.id===a.id);if(a.stage===10)return a.boss;return raidRandomMonster(a.stage,r)[0]}
function raidSpawnEnemy(){
  const a=p.activeRaid;const r=window.nordRaids.caves.find(x=>x.id===a.id);
  const heroLvl=Math.max(1,Number(p.level||1));
  // Every floor is materially harder, and more dangerous dungeons scale much faster.
  const stageScale=1+((a.stage-1)*0.32)+((r.danger-3)*0.15)+(Math.max(0,heroLvl-1)*0.035);
  if(a.stage===10){
    a.enemy=a.boss;
    a.enemyMax=Math.round((300+r.danger*48+120)*stageScale);
    a.enemyHp=a.enemyMax;
    a.enemyArmor=Math.round(24+r.danger*5+a.stage*3.8);
    a.enemyAttack=Math.round((40+r.danger*6+a.stage*4.4)*stageScale);
    return;
  }
  const m=raidRandomMonster(a.stage,r);
  a.enemy=m[0];
  a.enemyMax=Math.round((m[1]+a.stage*24+r.danger*7)*stageScale);
  a.enemyHp=a.enemyMax;
  a.enemyArmor=Math.max(1,Math.round((m[2]*1.05)+a.stage*2.9+r.danger*2.6));
  a.enemyAttack=Math.round((m[2]*1.55+a.stage*4.8+r.danger*3.2)*stageScale);
}
function raidEnemyIcon(name){const map={'Скелеты':'💀','Морозные пауки':'🕷️','Драугры':'☠️','Фалмеры':'👹','Чаурусы':'🦂','Тролли':'🧌','Вампиры':'🧛','Двемерские сферы':'⚙️','Паучьи механизмы':'🕷️','Двемерский центурион':'🤖','Драугр-Повелитель':'👑','Древний вампир':'🧛'};return map[name]||'👹'}
function renderRaidCombat(a){
  const boss=a.stage===10;const ePct=Math.max(0,Math.round(a.enemyHp/a.enemyMax*100));
  const playerDmg=raidPlayerDamage();const armor=raidPlayerArmor();
  return `<div class="raid-battle ${boss?'boss':''}"><div class="raid-battle-head"><div><span class="raid-kicker">${boss?'БОСС':'УГРОЗА'}</span><h2>${esc(a.enemy)}</h2></div><div class="raid-battle-badge">ЭТАП ${a.stage}/10</div></div><div class="raid-foe-art"><div class="raid-foe-glow"></div><div class="raid-foe-icon">${raidEnemyIcon(a.enemy)}</div><div class="raid-bar"><i style="width:${ePct}%"></i></div><small>${a.enemyHp} / ${a.enemyMax} HP</small><small style="display:block;margin-top:5px">⚔️ ${a.enemyAttack||0} • 🛡️ ${a.enemyArmor||0} броня</small></div><div class="raid-vs">⚔️ ПРОТИВ ⚔️</div><div class="raid-hero-mini"><div><b>${esc(p.name||'Герой')}</b><small>⚔️ ${playerDmg} урон • 🛡️ ${armor} броня</small></div><div class="raid-heart">❤️ ${a.heroHp}/${a.maxHp}</div></div><div class="raid-battle-bars"><div class="raid-bar hp"><i style="width:${Math.max(0,Math.min(100,a.heroHp/a.maxHp*100))}%"></i></div><div class="raid-stamina">🟢 Выносливость ${Math.max(0,p.st||0)}/${heroMaxSt()}</div></div><div class="raid-actions"><button type="button" onclick="raidAction('attack')"><span>⚔️</span><b>Атака</b><small>${playerDmg} баз. урон</small></button><button type="button" class="power" onclick="raidAction('power')"><span>💥</span><b>Сильный удар</b><small>больше урона • выносливость</small></button><button type="button" class="guard" onclick="raidAction('defend')"><span>🛡️</span><b>Защита</b><small>снизить ответный удар</small></button><button type="button" class="potion" onclick="raidAction('potion')"><span>🧪</span><b>Зелье</b><small>+45 HP</small></button></div><button type="button" class="raid-leave-btn" onclick="window.raidLeave()">↩️ Покинуть рейд</button></div>`;
}
function raidPlayerDamage(){return heroAttack()}
function raidPlayerArmor(){return heroDefense()}
function raidEventReward(chance=.28){if(Math.random()>chance)return null;return raidGiveLoot()}
function raidEventDamage(base,lethalBonus=0){const a=p.activeRaid;const n=base+Math.floor(Math.random()*18);if(Math.random()<lethalBonus)return a.maxHp+50;return n}
window.raidEvent=function(id){
  const a=p.activeRaid;if(!a||!a.pendingEvent)return;let note='';let lethal=false;const luck=Number(p.attributes?.Ловкость||5);
  const give=(chance)=>{const x=raidEventReward(chance);if(x){a.loot.push(raidLootText(x));return x}return null};
  if(id==='follow'){if(Math.random()<.28+luck*.012){const x=give(.40);note=x?`✨ Ты нашёл ${raidLootText(x)}.`:'🔎 Следы привели в пустой тоннель.'}else{raidApplyDamage(28+Math.floor(Math.random()*28),'Засада');note='☠️ Из темноты ударила засада.'}}
  else if(id==='observe'){const x=give(.22+.005*luck);note=x?`🔎 Найдено: ${raidLootText(x)}.`:'👁️ Ты заметил движение и ушёл с пустыми руками.'}
  else if(id==='open'){if(Math.random()<.26){const x=give(.55);note=x?`📦 Сундук открылся: ${raidLootText(x)}.`:'📦 Сундук был пуст.'}else{raidApplyDamage(38+Math.floor(Math.random()*28),'Ловушка сундука');if(a.heroHp<=0)lethal=true;note='☠️ Сундук оказался смертельной ловушкой.'}}
  else if(id==='trap'){if(Math.random()<.72){const x=give(.18);note=x?`🧰 Ловушка обезврежена. ${raidLootText(x)}.`:'🧰 Ловушка обезврежена, но внутри ничего ценного.'}else{raidApplyDamage(24+Math.floor(Math.random()*16),'Неудачная попытка обезвредить ловушку');note='⚠️ Механизм сработал прямо под ногами.'}}
  else if(id==='touch'){const r=Math.random();if(r<.10){raidApplyDamage(a.maxHp+10,'Проклятие алтаря');lethal=true;note='☠️ Алтарь поглотил жизненную силу.'}else if(r<.42){a.heroHp=Math.min(a.maxHp,a.heroHp+35);note='✨ Алтарь восстановил 35 HP.'}else{const x=give(.22);note=x?`🌟 Алтарь даровал ${raidLootText(x)}.`:'🌟 Алтарь ответил эхом. Ничего не произошло.'}}
  else if(id==='pray'){a.heroHp=Math.min(a.maxHp,a.heroHp+28);note='🙏 Ты восстановил 28 HP.';if(Math.random()<.12){raidApplyDamage(16,'Проклятое пламя');note+=' Но алтарь обжёг тебя.'}}
  else if(id==='right'){a.heroHp=Math.max(0,a.heroHp-12);const x=give(.14);note=x?`❄️ Морозный проход. Найдено: ${raidLootText(x)}.`:'❄️ Холодный проход ранил тебя, но путь пройден.'}
  else if(id==='left'){const x=give(.24);note=x?`📦 В боковом тоннеле лежало: ${raidLootText(x)}.`:'🚶 Ты прошёл тихий тоннель без добычи.'}
  else if(id==='wait'){if(Math.random()<.45){raidApplyDamage(18,'Скрытый враг');note='👂 Ты услышал врага, но он успел ударить первым.'}else note='👂 Ты дождался момента и прошёл незамеченным.'}
  else if(id==='run'){if(Math.random()<.10){raidApplyDamage(a.maxHp+50,'Обвал');lethal=true;note='☠️ Обвал похоронил героя.'}else{raidApplyDamage(20+Math.floor(Math.random()*18),'Обвал');note='🏃 Ты вырвался из обвала, получив ранение.'}}
  else if(id==='cover'){raidApplyDamage(16+Math.floor(Math.random()*14),'Обвал');note='🪨 Камни сбили тебя с ног.'}
  else if(id==='jump'){const x=give(.17);if(x)note=`✨ Тайный проход! Найдено: ${raidLootText(x)}.`;else{raidApplyDamage(22,'Неудачный прыжок');note='💥 Ты сорвался на камни.'}}
  else if(id==='search'){const x=give(.30);if(x)note=`🎒 В рюкзаке: ${raidLootText(x)}.`;else if(Math.random()<.28){addItem('Зелье лечения',1);note='🧪 Ты нашёл зелье лечения.'}else note='🎒 Старый рюкзак пуст.'}
  else if(id==='rest'){a.heroHp=Math.min(a.maxHp,a.heroHp+30);note='🔥 Передышка восстановила 30 HP.';if(Math.random()<.35){a.enemy='Скелеты';a.enemyMax=55;a.enemyHp=55;note+=' ☠️ Но покой потревожили скелеты.'}}
  else if(id==='listen'){const r=Math.random();if(r<.10){raidApplyDamage(a.maxHp+50,'Проклятие саркофага');lethal=true;note='☠️ Шёпот вырвал душу из тела.'}else if(r<.48){a.heroHp=Math.min(a.maxHp,a.heroHp+20);note='🕯️ Ты получил благословение: +20 HP.'}else{gainXp(45);const x=give(.08);note=x?`📜 Древнее знание и ${raidLootText(x)}.`:'📜 Древнее знание: +45 XP.'}}
  else if(id==='seal'){note='🔒 Ты запечатал саркофаг.'}
  else if(id==='leave'){note='🚶 Ты отказался от риска.'}
  a.eventResolved=true;a.pendingEvent=null;raidLog(note);if(a.heroHp<=0||lethal)return raidFinish(false);save();showRaidStage();
};

// Dedicated raid-event tap bridge. Defined immediately after raidEvent so Android WebView always has it.
window.__nordRaidTap=(function(){
  let last=0;
  return function(el){
    if(!el)return;
    const b=el.closest?el.closest('.raid-choice[data-raid-action]'):el;
    if(!b)return;
    const now=Date.now();
    if(now-last<550)return;
    last=now;
    const act=b.getAttribute('data-raid-action');
    if(!act)return;
    b.classList.add('tap-active');
    setTimeout(()=>b.classList.remove('tap-active'),260);
    if(typeof window.raidEvent==='function')window.raidEvent(act);
  };
})();

window.raidAction=function(type){
  const a=p.activeRaid;if(!a)return;const boss=a.stage===10;
  if(type==='potion'){
    if(!removeItem('Зелье лечения',1)){showToast('Нет зелий','Нужен предмет «Зелье лечения».','warn','🧪',1800);return}
    const heal=45;a.heroHp=Math.min(a.maxHp,a.heroHp+heal);raidLog(`🧪 Зелье восстановило ${heal} HP`);
  }else if(type==='defend'){a.guard=true;p.st=Math.min(heroMaxSt(),(p.st||0)+6);raidLog('🛡️ Ты занял оборонительную стойку.');}
  else{
    const base=Math.max(1,raidPlayerDamage()-Math.floor((a.enemyArmor||0)*0.52));let dmg=type==='power'?Math.round(base*1.62):base;if(type==='power'){if((p.st||0)<18){showToast('Не хватает выносливости','Нужно хотя бы 18.','warn','🟢',1600);return}p.st=Math.max(0,p.st-18);if(Math.random()<.18){dmg=Math.round(dmg*1.7);raidLog('💥 Сильный критический удар!')}}
    a.enemyHp=Math.max(0,a.enemyHp-dmg);raidLog(`⚔️ ${type==='power'?'Сильный удар':'Атака'}: -${dmg} HP`);skill('Одноручное оружие',type==='power'?2:1);
  }
  if(a.enemyHp<=0){raidLog(boss?'👑 Босс повержен!':'☠️ Враг повержен!');if(boss)return raidFinish(true);if(Math.random()<.24){const x=raidEventReward();a.loot.push(raidLootText(x));raidLog(`🎁 С врага выпало: ${raidLootText(x)}`)}a.stage++;a.enemy='';a.enemyHp=0;raidNextEvent();save();showRaidStage();return;}
  let enemyDmg=Math.max(6,Math.round((a.enemyAttack||12)*(0.72+Math.random()*0.38)));if(a.stage>=6)enemyDmg+=Math.floor(a.stage*1.8);if(boss&&a.enemyHp<a.enemyMax*.5){enemyDmg+=10;if(!a.bossPhase){a.bossPhase=1;raidLog('🔥 Босс входит в ярость. Удары стали намного сильнее.')}}
  const armor=raidPlayerArmor();enemyDmg=Math.max(1,enemyDmg-Math.floor(armor*.22));raidApplyDamage(enemyDmg,`${a.enemy} атакует`);
  if(a.heroHp<=0)return raidFinish(false);p.st=Math.min(heroMaxSt(),(p.st||0)+5);a.turn++;save();showRaidStage();
};

function raidFinish(success){
  const a=p.activeRaid;const r=window.nordRaids.caves.find(x=>x.id===a.id);
  if(success){const reward=r.reward+(a.loot.length*55);p.gold=(p.gold||0)+reward;gainXp(260+a.stage*35);p.raidCooldowns=p.raidCooldowns||{};p.worldEvents=p.worldEvents||[];p.worldEvents.unshift({city:p.loc,text:`🏆 Рейд «${a.name}» завершён. Добыча: ${reward} золота.`,day:gameDays(),cls:'good'});showToast('РЕЙД ПРОЙДЕН',`Золото: +${reward} • Предметов: ${a.loot.length}`,'good','🏆',3200)}
  else{p.worldEvents=p.worldEvents||[];p.worldEvents.unshift({city:p.loc,text:`☠️ Герой погиб в рейде «${a.name}». Забег потерян.`,day:gameDays(),cls:'bad'});showToast('ГЕРОЙ ПОГИБ','Рейд окончен. Добыча этого забега потеряна.','bad','☠️',3600);p.hp=Math.max(1,Math.floor(heroMaxHp()*.3))}
  p.activeRaid=null;save();showScreen('world');
}
function showRaidStage(){
  const a=p.activeRaid;if(!a)return;raidSetMusic();if(!a.enemy||a.enemyHp<=0)raidSpawnEnemy();const main=document.getElementById('main');
  const stageNames=['Вход','Следы','Ловушка','Дверь кургана','Подземный грот','Глубины','Алтарь','Чёрный коридор','Преддверие','Босс'];
  main.innerHTML=`<section class="raid-run"><div class="raid-run-top"><button class="raid-icon-btn" type="button" onclick="window.raidLeave()">←</button><div><div class="raid-kicker">${esc(a.name)}</div><div class="raid-run-stage">ЭТАП ${a.stage}/10 • ${stageNames[a.stage-1]}</div></div><div class="raid-heart">❤️ ${a.heroHp}/${a.maxHp}</div></div><div class="raid-progress">${Array.from({length:10},(_,i)=>`<span class="${i<a.stage-1?'done':''} ${i===a.stage-1?'active':''}">${i===9?'👑':i+1}</span>`).join('')}</div>${a.pendingEvent&&!a.eventResolved?renderRaidEvent(a.pendingEvent):renderRaidCombat(a)}<div class="raid-log">${(a.log||[]).map(x=>`<div>${esc(x)}</div>`).join('')}</div></section>`;window.scrollTo({top:0,behavior:'smooth'})
}
function renderRaidEvent(ev){return `<div class="raid-event-choices raid-event-click-zone">${ev.choices.map(([id,label,meta])=>`<button type="button" class="raid-choice" data-raid-action="${id}" onclick="window.__nordRaidTap(this)" onpointerdown="window.__nordRaidTap(this)" ontouchstart="window.__nordRaidTap(this)" onmousedown="window.__nordRaidTap(this)"><b>${label}</b><small>${meta}</small></button>`).join('')}</div>`}
window.raidLeave=function(){if(!p.activeRaid){showScreen('raids');return}if(confirm('Покинуть рейд? Текущая добыча этого забега будет потеряна, а рейд останется закрыт на 3 игровых дня.')){p.activeRaid=null;save();showScreen('raids')}};
window.showRaidStage=showRaidStage;
window.raidRandomMonster=raidRandomMonster;

function renderWorld(){
  ensureLivingState();
  let d=world[p.loc];
  const snap=worldEngineSnapshot(p.loc);
  applyWeatherVisual(snap.weather);
  const recent=(p.worldEvents||[]).filter(e=>e.city===p.loc).slice(0,3).map(e=>{
    const safeText=esc(e.text); const incident=(snap.incidents||[]).find(i=>i.text&&safeText.includes(esc(i.text).replace(/&quot;/g,'"')))||null;
    return `<div class="city-event ${e.cls||''}">${safeText}<small class="muted" style="display:block;margin-top:3px">День ${e.day}</small></div>`;
  }).join('')||'<div class="muted">Город пока спокоен.</div>';
  const incidentCards=(snap.incidents||[]).map(inc=>`<div class="decision-card ${inc.cls||'warn'}"><div class="decision-title">${esc(inc.text)}</div><div class="decision-meta">Активно до дня ${inc.expiresDay} • Ты можешь изменить исход.</div>${renderDecisionCard(inc)}</div>`).join('');
  const people=(d.npcs||[]).slice(0,4).map(n=>`<div class="npc-card"><strong>${esc(n)}</strong><div class="muted">${esc(npcDb[n]?.role||'Житель')} • ${esc(npcDb[n]?.about||'Местный житель')}</div><div class="smallnote">Сейчас: <b>${esc(p.worldEngine.npcs[n]?.place||'Улицы')}</b> • настроение ${Math.round(p.worldEngine.npcs[n]?.mood||50)}/100</div><button class="choice" onclick="npcAction(decodeURIComponent('${encodeURIComponent(n)}'))">💬 Подойти и поговорить</button></div>`).join('');
  const h=Math.max(0,p.hunger),e=Math.max(0,p.energy),wicon=worldEngineWeatherIcon(snap.weather),wclass=worldEngineWeatherClass(snap.weather);
  main.innerHTML=`<section class="hero"><div class="cityHead"><div><div class="title" style="text-align:left;margin-top:0">${esc(p.loc.toUpperCase())}</div><div class="subtitle" style="text-align:left">${esc(d.type)} • ${esc(d.desc)}</div></div><span class="cityBadge">🏙️ Живой город</span></div>${renderLivingCityScene(snap)}<div class="weather-panel"><div class="weather-main"><div class="weather-icon">${wicon}</div><div><div class="weather-name">${esc(snap.weather)}</div><div class="weather-detail">Погода влияет на настроение, дороги и запасы города.</div></div></div><div class="weather-changing">${wclass==='clear'?'Стабильно':'Меняется'}</div></div><div class="city-status"><div class="pillbox"><b>📅 День ${gameDays()}</b>${dateLabel()}</div><div class="pillbox"><b>🕒 ${String(p.hour).padStart(2,'0')}:${String(p.minute).padStart(2,'0')}</b>${timeLabel()}</div><div class="pillbox"><b>🍖 ${h}/100</b>Голод</div><div class="pillbox"><b>😴 ${e}/100</b>Бодрость</div></div><div class="stats"><div class="stat">❤️ ${p.hp}/${heroMaxHp()}<div class="bar hp"><span style="width:${Math.max(0,Math.min(100,p.hp/heroMaxHp()*100))}%"></span></div></div><div class="stat">🔷 ${p.mp}/${heroMaxMp()}<div class="bar mp"><span style="width:${Math.min(100,p.mp/heroMaxMp()*100)}%"></span></div></div><div class="stat">🟢 ${p.st}/${heroMaxSt()}<div class="bar st"><span style="width:${Math.min(100,p.st/heroMaxSt()*100)}%"></span></div></div></div></section><section class="card" style="margin-top:12px"><h3>🌍 Мир живёт</h3><div class="city-status"><div class="pillbox"><b>🛡️ ${snap.security}</b>Безопасность</div><div class="pillbox"><b>💰 ${snap.economy}%</b>Экономика</div><div class="pillbox"><b>🙂 ${snap.morale}</b>Настроение</div><div class="pillbox"><b>🌾 ${Math.round(snap.food||100)}%</b>Запасы еды</div><div class="pillbox"><b>⚠️ ${Math.round(snap.tension||20)}</b>Напряжение</div><div class="pillbox"><b>👥 ${snap.npcs.length}</b>NPC рядом</div></div><div class="smallnote" style="margin-top:8px">Последняя симуляция мира: ${p.worldEngine.stats.hours||0} ч. • событий: ${p.worldEngine.stats.events||0} • перемещений NPC: ${p.worldEngine.stats.npcMoves||0}</div><div class="influence-panel"><div class="influence-box"><b>${p.worldEngine.heroInfluence?.decisions||0}</b><small>решений героя</small></div><div class="influence-box"><b>${p.worldEngine.heroInfluence?.helped||0}</b><small>помощи миру</small></div><div class="influence-box"><b>${p.worldEngine.heroInfluence?.reputation||0}</b><small>влияние</small></div></div></section><section class="card" style="margin-top:12px"><h3>⚠️ Опасные события</h3>${incidentCards||'<div class="muted">Сейчас серьёзных проблем нет. Мир продолжает жить своей жизнью.</div>'}</section><section class="card" style="margin-top:12px"><h3>Что происходит?</h3>${recent}</section><section class="card" style="margin-top:12px"><h3>Чем заняться?</h3><div class="city-actions"><button class="city-action" onclick="cityActivity('tavern')">🍺 <strong>Таверна</strong><small>Еда, отдых, сон, знакомства, слухи и игры.</small></button><button class="city-action" onclick="cityActivity('market')">🛒 <strong>Рынок</strong><small>Еда, оружие, броня, материалы и редкие товары.</small></button><button class="city-action arena-card" onclick="cityActivity('arena')">🏟️ <strong>Арена</strong><small>Сражения за золото и репутацию.</small></button><button class="city-action raid-card" onclick="cityActivity('raids')">⚔️ <strong>Рейды</strong><small>Пещеры, подземелья и сильные боссы. Повтор через 3 дня.</small></button><button class="city-action danger-card" onclick="showScreen('danger')">⚠️ <strong>Опасность</strong><small>Случайные враги и события на дорогах. Никогда не знаешь, кто встретится.</small></button><button class="city-action" onclick="cityActivity('people')">👥 <strong>Люди города</strong><small>Новые знакомства, дружба и будущие спутники.</small></button><button class="city-action" onclick="cityActivity('quests')">📜 <strong>Задания</strong><small>Поручения жителей, события и активные дела.</small></button><button class="city-action" onclick="showScreen('guilds')">🏰 <strong>Гильдии города</strong><small>Местные гильдии, испытания, ранги и полномочия.</small></button><button class="city-action" onclick="inspectLocation()">🔎 <strong>Осмотреться</strong><small>Узнать, что происходит вокруг прямо сейчас.</small></button><button class="city-action" onclick="buyHouse()">🏠 <strong>Дом</strong><small>${d.house?'Купить жильё за '+d.house+' золота.':'В этом месте дома пока недоступны.'}</small></button></div></section>`;
  save();
}

function renderTavern(){ensureLivingState();if(p.tavernInnkeeperDay!==p.day){p.tavernInnkeeperDay=p.day;p.tavernInnkeeperUses=0;}const innUses=Number(p.tavernInnkeeperUses||0);const innkeeperDone=innUses>=3;const innkeeperLabel=innkeeperDone?'🧹 <strong>Мы всё сделали</strong><small>Приходи завтра — хозяин будет ждать.</small>':`🧹 <strong>Помочь хозяину</strong><small>Небольшая работа • золото • репутация • осталось ${3-innUses} сегодня</small>`;const hp=Math.max(0,p.hp),mp=Math.max(0,p.mp),st=Math.max(0,p.st),food=Math.max(0,p.hunger),sleep=Math.max(0,p.energy);const recent=(p.worldEvents||[]).filter(e=>e.city===p.loc).slice(0,2).map(e=>`<div class="city-event ${e.cls||''}">${esc(e.text)}<small class="muted" style="display:block;margin-top:3px">День ${e.day}</small></div>`).join('')||'<div class="muted">Пока всё спокойно.</div>';const friends=(p.knownPeople||[]).filter(x=>x.city===p.loc||x.knownDay===p.day).slice(0,3).map(n=>`<div class="tavern-visitor"><div class="visitor-avatar">${esc(n.icon||'👤')}</div><div class="visitor-meta"><strong>${esc(n.name)}</strong><small>${esc(n.role)} • Отношения ${n.relation}/100</small></div></div>`).join('');main.innerHTML=`<section class="hero"><div class="title">🍺 ТАВЕРНА</div><div class="subtitle">${esc(p.loc)} • ${timeLabel()} • ${dateLabel()} • ${String(p.hour).padStart(2,'0')}:${String(p.minute).padStart(2,'0')}</div><p class="smallnote">Здесь город особенно живой: посетители приходят и уходят, рождаются слухи, знакомства, романтические истории и случайные события.</p><div class="tavern-real-scene" aria-label="Реалистичная живая сцена таверны"><img class="tavern-real-art" src="ui/tavern_realistic_scene.jpg" alt="Живая реалистичная таверна с посетителями и воинами"><div class="tavern-firelight"></div><div class="tavern-lantern"></div><div class="tavern-smoke"></div><div class="tavern-caption">ЖИВАЯ ТАВЕРНА • ПОСЕТИТЕЛИ ОТДЫХАЮТ</div></div><div class="tavern-status">${tavernMeter('Здоровье',hp,heroMaxHp(),'meter-hp','❤️')}${tavernMeter('Сытость',food,100,'meter-food','🍖')}${tavernMeter('Сон / бодрость',sleep,100,'meter-sleep','😴')}${tavernMeter('Магия',mp,heroMaxMp(),'meter-mp','🔷')}${tavernMeter('Выносливость',st,heroMaxSt(),'meter-st','🟢')}</div></section><section class="card" style="margin-top:12px"><h3>Что делать?</h3><div class="tavern-activity-grid"><button class="btn cyan tavern-activity" onclick="visitTavernAction('eat')">🍲 <strong>Заказать еду</strong><small>+25 сытости • 12 золота</small></button><button class="btn tavern-activity" onclick="visitTavernAction('drink')">🍺 <strong>Выпить и отдохнуть</strong><small>6 золота • бодрость +6 • время +30 мин</small></button><button class="btn tavern-activity" onclick="visitTavernAction('talk')">💬 <strong>Познакомиться</strong><small>Диалоги • дружба • романтика • спутники</small></button><button class="btn tavern-activity" onclick="visitTavernAction('bard')">🎵 <strong>Послушать барда</strong><small>5 золота • +5 бодрости • настроение города +3</small></button><button class="btn tavern-activity" onclick="visitTavernAction('dice')">🎲 <strong>Играть в кости</strong><small>Ставка 15 золота</small></button><button class="btn tavern-activity ${innkeeperDone?'tavern-disabled':''}" ${innkeeperDone?'disabled aria-disabled="true"':''} onclick="visitTavernAction('innkeeper')">${innkeeperLabel}</button><button class="btn tavern-activity" onclick="visitTavernAction('sleep')">🛏️ <strong>Снять комнату</strong><small>15 золота • 8 часов сна • восстановление</small></button></div></section><section class="card" style="margin-top:12px"><h3>👥 Кто сегодня в таверне?</h3>${friends||'<div class="muted">Ты ещё ни с кем здесь не познакомился. Может, сегодня повезёт.</div>'}</section><section class="card" style="margin-top:12px"><h3>👂 Слухи</h3>${recent}<div class="city-event info">«У бармена всегда найдётся свежая история. Спроси посетителей — некоторые слухи могут стать настоящими событиями.»</div></section><button class="btn" style="margin-top:12px" onclick="showScreen('world')">↩️ Вернуться в город</button>`} 
const CITY_SHOP_STOCK={
 'Вайтран':['Железный меч','Железный щит','Железная булава','Железный шлем','Кожаная броня','Кожаные сапоги'],
 'Ривервуд':['Охотничий лук','Железный кинжал','Железные сапоги','Кожаная броня','Зелье лечения'],
 'Рифтен':['Стальной кинжал','Стальной лук','Кожаные сапоги','Стальной шлем','Зелье лечения'],
 'Виндхельм':['Стальной меч','Стальной боевой топор','Стальной щит','Стальной шлем','Стальная броня'],
 'Солитьюд':['Стальной меч','Стальной щит','Стальная броня','Стальные сапоги','Стальной лук'],
 'Фолкрит':['Охотничий лук','Железная булава','Кожаная броня','Кожаные сапоги','Зелье лечения'],
 'Морфал':['Железный кинжал','Стальной кинжал','Стальной щит','Стальные сапоги','Зелье лечения'],
 'Данстар':['Стальной боевой топор','Стальной меч','Стальной щит','Стальной шлем','Зелье лечения'],
 'Рорикстед':['Железный меч','Железный щит','Охотничий лук','Кожаная броня'],
 'Картвастен':['Железная булава','Стальной боевой топор','Стальной шлем','Стальная броня'],
 'Шорс-Стон':['Стальной меч','Стальной щит','Стальной шлем','Стальные сапоги'],
 'Айварстед':['Охотничий лук','Железный кинжал','Кожаная броня','Кожаные сапоги']
};
function cityShopStock(){return CITY_SHOP_STOCK[p.loc]||CITY_SHOP_STOCK['Вайтран']}
function renderMarket(){const goods=[...cityShopStock(), 'Зелье лечения'];const rows=goods.map(n=>{const d=itemDb[n]||{};const t=d.type==='potion'?'Зелье':(d.type==='weapon'?'Оружие':d.type==='armor'?'Экипировка':'Товар');const price=Math.round((d.price||30)*(p.cityPrices||100)/100);return `<div class="market-item"><b>${esc(n)}</b><small>${t}${d.rarityName?' • '+rarityLabel(d):''}${d.damage?' • ⚔️ '+d.damage:''}${d.armor?' • 🛡️ '+d.armor:''}</small><button class="pill price" onclick="buyMarketItem(decodeURIComponent('${encodeURIComponent(n)}'),${d.price||30})">${price} 🪙</button></div>`}).join('');main.innerHTML=`<section class="hero"><div class="title">🛒 РЫНОК</div><div class="subtitle">${esc(p.loc)} • Только обычные и необычные вещи</div><p class="smallnote">Ассортимент зависит от города. Редкие, легендарные и мифические предметы торговцы не продают — их ищут в рейдах.</p></section><section class="card" style="margin-top:12px"><h3>Товары этого города</h3><div class="market-grid">${rows}</div></section><button class="btn" style="margin-top:12px" onclick="showScreen('world')">↩️ Вернуться в город</button>`}
function buyMarketItem(name,base){const price=Math.round(base*(p.cityPrices||100)/100);if(p.gold<price)return addLog('Недостаточно золота.','bad');p.gold-=price;addItem(name);if(['Хлеб','Яблоко','Сыр','Мясо','Суп','Рыба'].includes(name))p.hunger=Math.min(100,p.hunger+({'Хлеб':20,'Яблоко':12,'Сыр':15,'Мясо':30,'Суп':35,'Рыба':25}[name]||10));advanceTime(8,`Покупка на рынке: ${name}`);renderMarket()}
function renderArena(){main.innerHTML=`<section class="hero arena-card"><div class="title">🏟️ АРЕНА</div><div class="subtitle">Сражайся • Рискуй • Зарабатывай</div><p class="smallnote">Каждый бой занимает время. Победы повышают твою репутацию, а поражения имеют последствия.</p></section><section class="card" style="margin-top:12px"><h3>Противники</h3><button class="btn" onclick="arenaFight('Бандит',25,55)">🗡️ Новичок • ставка 25 золота</button><button class="btn" style="margin-top:8px" onclick="arenaFight('Наемник',50,100)">🛡️ Воин • ставка 50 золота</button><button class="btn" style="margin-top:8px" onclick="arenaFight('Драугр',90,180)">💀 Чемпион • ставка 90 золота</button></section><button class="btn" style="margin-top:12px" onclick="showScreen('world')">↩️ Вернуться в город</button>`}
function arenaFight(enemy,bet,reward){if(p.gold<bet)return addLog('Не хватает золота на ставку.','bad');p.gold-=bet;advanceTime(35,`Ты выходишь на арену против ${enemy}`);if(Math.random()<0.62){p.gold+=reward;gainXp(20);addLog(`🏆 Ты побеждаешь на арене и получаешь ${reward} золота!`,'good')}else{p.hp=Math.max(1,p.hp-20);addLog(`💥 Ты проигрываешь бой на арене и теряешь ставку.`,'bad')}save();renderArena()}
function renderPeople(){const known=(p.knownPeople||[]).map(n=>`<div class="npc-card"><strong>${esc(n.name)}</strong><div class="muted">${esc(n.role)} • ${esc(n.about)}</div><div class="smallnote">Отношения: ${n.relation}/100 ${n.friend?'• 🤝 Друг':''}</div><button class="choice" onclick="talkPerson('${esc(n.name)}')">💬 Поговорить</button>${n.relation>=45&&!p.companions.includes(n.name)?`<button class="choice" onclick="recruitKnown('${esc(n.name)}')">🤝 Предложить путешествовать вместе</button>`:''}</div>`).join('')||'<div class="muted">Пока нет знакомых. Загляни в таверну.</div>';main.innerHTML=`<section class="hero"><div class="title">👥 ЛЮДИ ГОРОДА</div><div class="subtitle">ЗНАКОМСТВА • ДРУЖБА • СПУТНИКИ</div><button class="btn cyan" style="margin-top:12px" onclick="meetPerson()">👤 Познакомиться с кем-нибудь</button></section><section class="card" style="margin-top:12px"><h3>Твои знакомые</h3>${known}</section><button class="btn" style="margin-top:12px" onclick="showScreen('world')">↩️ Вернуться в город</button>`}
const mapPoints={
'Вайтран':[48,43],'Ривервуд':[40,51],'Рифтен':[68,56],'Виндхельм':[72,20],'Солитьюд':[27,22],'Фолкрит':[36,70],'Морфал':[43,31],'Данстар':[55,10],'Айварстед':[56,54],'Рорикстед':[30,47],'Хелген':[43,61],'Драконий мост':[31,32],'Картвастен':[20,43],'Шорс-Стон':[58,47],'Каменные холмы':[74,45],'Торговый тракт':[49,35],'Ледяной берег':[82,15],'Черный перевал':[73,30],'Высокий Хротгар':[59,42],'Заброшенный форт':[83,39],'Снежная пещера':[16,58],'Старые руины':[23,61],'Туманный лес':[25,52],'Озеро Хьялмарк':[49,27],'Красный перевал':[77,60],'Долина охотников':[65,71]
};
function selectMapLocation(name){if(!world[name])return;p.mapSelected=name;save();renderMap()}
function travelFromMap(name){if(!world[name])return;const exits=world[p.loc]?.exits||[];if(name===p.loc){p.mapSelected=name;renderMap();return}if(!exits.includes(name)){addLog(`🧭 Из ${p.loc} сейчас нельзя напрямую попасть в ${name}. Сначала выбери соседнюю точку.`,'bad');renderMap();return}travel(name)}
function renderMap(){
  const selected=world[p.mapSelected]&&p.mapSelected?p.mapSelected:p.loc;
  const current=p.loc;
  const exits=world[current]?.exits||[];
  const points=Object.keys(world).filter(n=>mapPoints[n]);
  const edges=[];const seen=new Set();
  points.forEach(a=>{(world[a].exits||[]).forEach(b=>{if(!mapPoints[b])return;const key=[a,b].sort().join('|');if(seen.has(key))return;seen.add(key);edges.push([a,b]);})});
  const route=exits.filter(n=>mapPoints[n]);
  const edgeSvg=edges.map(([a,b])=>{const [x1,y1]=mapPoints[a],[x2,y2]=mapPoints[b];const active=(a===current&&route.includes(b))||(b===current&&route.includes(a));return `<line class="map-road ${active?'active':''}" x1="${x1*10}" y1="${y1*7}" x2="${x2*10}" y2="${y2*7}"/>`}).join('');
  const pins=points.map(n=>{const [x,y]=mapPoints[n];const active=n===current,sel=n===selected,reachable=exits.includes(n);const icon=world[n].type==='Город'?'🏰':world[n].type==='Деревня'?'🏠':world[n].type==='Руины'?'⚔️':world[n].type==='Святилище'?'⛩️':world[n].type==='Побережье'?'⚓':world[n].type==='Лес'?'🌲':world[n].type==='Болото'?'🌫️':'◆';return `<button type="button" class="map-pin ${active?'current':''} ${sel?'selected':''} ${reachable?'reachable':''}" style="left:${x}%;top:${y}%" onclick="selectMapLocation('${esc(n)}')" aria-label="${esc(n)}"><span>${icon}</span><b>${active?'Ты здесь':sel?esc(n):''}</b></button>`}).join('');
  const d=world[selected];
  const selectedExits=(d?.exits||[]).filter(n=>world[n]);
  const travelBtn=selected===current?`<button class="map-action current" disabled>📍 Ты находишься здесь</button>`:exits.includes(selected)?`<button class="map-action travel" onclick="travelFromMap('${esc(selected)}')">🚶 Отправиться в ${esc(selected)}</button>`:`<button class="map-action disabled" onclick="addLog('🧭 Сначала доберись до соседней точки от текущей локации.','info');renderMap()">🔒 Нет прямого пути</button>`;
  const nearby=exits.map(n=>`<button type="button" class="map-nearby ${selected===n?'active':''}" onclick="selectMapLocation('${esc(n)}')"><span>📍</span><strong>${esc(n)}</strong><small>${esc(world[n]?.type||'Локация')}</small></button>`).join('');
  const allList=points.map(n=>`<button type="button" class="map-list-item ${n===current?'current':''} ${n===selected?'selected':''}" onclick="selectMapLocation('${esc(n)}')"><span>${n===current?'📍':'○'}</span><b>${esc(n)}</b><small>${esc(world[n].type)}</small></button>`).join('');
  main.innerHTML=`<section class="map-v3">
    <div class="map-v3-head"><div><div class="map-kicker">NORD • НОВАЯ СУДЬБА</div><h2>БОЛЬШАЯ КАРТА</h2><p>Северные земли живут своей жизнью. Выбирай точку, изучай её и двигайся по связанным дорогам.</p></div><div class="map-counter"><b>${points.length}</b><span>известных мест</span></div></div>
    <div class="map-board"><div class="map-atmosphere"></div><svg class="map-roads" viewBox="0 0 1000 700" preserveAspectRatio="none" aria-hidden="true"><path class="map-river" d="M610 0 C540 100 690 150 560 250 S690 420 520 700"/>${edgeSvg}</svg><div class="map-mountains m1">▲ ▲ ▲</div><div class="map-mountains m2">▲ ▲</div><div class="map-forest f1">♣ ♣ ♣ ♣</div><div class="map-forest f2">♣ ♣ ♣</div>${pins}<div class="map-legend"><span><i class="dot current"></i> Ты</span><span><i class="dot route"></i> Путь</span><span><i class="dot"></i> Известно</span></div></div>
    <div class="map-selected"><div class="map-selected-top"><div><span class="map-type">${esc(d?.type||'Локация')}</span><h3>${esc(selected)}</h3><p>${esc(d?.desc||'')}</p></div><div class="map-selected-icon">${selected===current?'📍':'🧭'}</div></div>${travelBtn}<div class="map-nearby-title">СВЯЗАННЫЕ ПУТИ</div><div class="map-nearby-grid">${nearby||'<div class="muted">Нет известных выходов.</div>'}</div></div>
    <details class="map-all"><summary>Все известные места <span>${points.length}</span></summary><div class="map-list">${allList}</div></details>
  </section>`;
}
function relationshipCategory(n){const romance=Number(n.romance||0);if(romance>=35)return 'love';if(n.friend)return 'friend';return 'acquaintance'}
function relationshipLabel(n){const c=relationshipCategory(n);return c==='love'?'❤️ Любовные отношения':(c==='friend'?'🤝 Друзья':'👋 Знакомые')}
function breakRelationship(name){const n=(p.knownPeople||[]).find(x=>x.name===name);if(!n)return;if(!confirm(`Разорвать отношения с ${name}?`))return;const wasCompanion=(p.companions||[]).includes(name);p.companions=(p.companions||[]).filter(x=>x!==name);p.knownPeople=(p.knownPeople||[]).filter(x=>x.name!==name);p.relationshipHistory=p.relationshipHistory||[];p.relationshipHistory.unshift({name,day:p.day,city:p.loc,reason:'отношения прекращены',wasCompanion});p.relationshipHistory=p.relationshipHistory.slice(0,30);addLog(`💔 Ты прекратил отношения с ${name}.`,'warn');save();showToast('Отношения завершены',`${name} больше не числится среди твоих близких знакомых.`,'warn','💔',2200);renderProfile()}
function renderRelations(){ensureLivingState();const people=(p.knownPeople||[]).slice();const buckets={love:people.filter(n=>relationshipCategory(n)==='love'),friend:people.filter(n=>relationshipCategory(n)==='friend'),acquaintance:people.filter(n=>relationshipCategory(n)==='acquaintance')};const card=(n)=>`<div class="npc-card"><div style="display:flex;gap:10px;align-items:center"><div class="visitor-avatar" style="font-size:30px">${esc(n.icon||'👤')}</div><div style="flex:1"><strong>${esc(n.name)}</strong><div class="muted">${esc(n.role)} • ${esc(n.city||'Неизвестно')}</div></div></div><div class="smallnote" style="margin-top:8px">${relationshipLabel(n)} • Связь ${n.relation||0}/100${n.friend?' • 🤝 Друг':''}${(n.romance||0)>0?` • ❤️ ${n.romance}/100`:''}${p.companions?.includes(n.name)?' • 🧭 Спутник':''}</div><button class="choice" style="margin-top:8px" onclick="breakRelationship('${esc(n.name)}')">💔 Завершить отношения</button></div>`;const empty=(t)=>`<div class="muted">${t}</div>`;main.innerHTML=`<section class="hero"><div class="title">❤️ ОТНОШЕНИЯ</div><div class="subtitle">ДРУЗЬЯ • ЛЮБОВЬ • ЗНАКОМЫЕ</div><p class="smallnote">Все люди, с которыми ты познакомился, собраны здесь. Отношения развиваются поступками и могут быть прекращены в любой момент.</p></section><section class="card" style="margin-top:12px"><h3>❤️ Любовные отношения <span class="pill">${buckets.love.length}</span></h3>${buckets.love.map(card).join('')||empty('Пока нет любовных отношений.')}</section><section class="card" style="margin-top:12px"><h3>🤝 Друзья <span class="pill">${buckets.friend.length}</span></h3>${buckets.friend.map(card).join('')||empty('Пока нет друзей.')}</section><section class="card" style="margin-top:12px"><h3>👋 Знакомые <span class="pill">${buckets.acquaintance.length}</span></h3>${buckets.acquaintance.map(card).join('')||empty('Ты пока ни с кем не знаком.')}</section><section class="card" style="margin-top:12px"><h3>🕯️ Память об отношениях</h3>${(p.relationshipHistory||[]).slice(0,8).map(x=>`<div class="item"><span>${esc(x.name)}</span><span class="pill">День ${x.day}</span></div>`).join('')||empty('Здесь появятся завершённые отношения.')}</section><button class="btn" style="margin-top:12px" onclick="showScreen('profile')">↩️ Вернуться в профиль</button>`}
function renderSkills(){renderProfile()}
function renderInv(){
  p.equipment=p.equipment||{weapon:null,shield:null,helmet:null,armor:null,boots:null};
  const slots=[['weapon','⚔️ Оружие'],['shield','🛡️ Щит'],['helmet','⛑️ Шлем'],['armor','🧥 Броня'],['boots','🥾 Сапоги'],['amulet','📿 Амулет']];
  const equip=slots.map(([slot,label])=>{const item=p.equipment[slot];const d=item?(itemDb[item]||{}):{};return `<div class="item"><span>${label}<small class="muted" style="display:block">${item?esc(item):'Пусто'}${item&&d.rarityName?` • ${rarityLabel(d)}`:''}${d.damage?` • Урон ${d.damage}`:''}${d.armor?` • Броня ${d.armor}`:''}</small></span>${item?`<button class="btn small" onclick="unequipItem('${slot}')">Снять</button>`:'<span class="pill">—</span>'}</div>`}).join('');
  const rows=p.inv.map((x)=>{const db=itemDb[x[0]]||{};const slot=['Меч','Топор','Булава','Кинжал','Лук'].includes(db.slot)?'weapon':db.slot==='Щит'?'shield':db.slot==='Шлем'?'helmet':db.slot==='Броня'?'armor':db.slot==='Сапоги'?'boots':db.type==='accessory'?'amulet':null;return `<div class="item"><span><b>${esc(x[0])}</b><small class="muted" style="display:block">${db.rarityName?`${rarityLabel(db)} • `:''}${db.damage?'Урон '+db.damage+' • ':''}${db.armor?'Броня '+db.armor+' • ':''}${db.hpBonus?'❤️ +'+db.hpBonus+' HP • ':''}${db.mpBonus?'🔷 +'+db.mpBonus+' маны • ':''}${db.stBonus?'🟢 '+(db.stBonus>0?'+':'')+db.stBonus+' выносл. • ':''}${db.damageBonus?'⚔️ +'+db.damageBonus+' атаки • ':''}${db.price?'Цена '+db.price+' золота':''}</small></span><span style="display:flex;gap:6px;align-items:center"><span class="pill">×${x[1]}</span>${slot?`<button class="btn small cyan" onclick="equipItem('${encodeURIComponent(x[0])}','${slot}')">Экипировать</button>`:''}</span></div>`}).join('');
  main.innerHTML=`<section class="card"><h3>🎒 Инвентарь</h3>${rows||'<div class="muted">Пока пусто.</div>'}<div class="item"><span>💰 Золото</span><span class="pill">${p.gold}</span></div></section><section class="card" style="margin-top:12px"><h3>⚔️ Экипировка</h3>${equip}</section>`;
}
window.equipItem=function(encoded,slot){const name=decodeURIComponent(encoded);if(!p.inv.some(x=>x[0]===name))return;const db=itemDb[name]||{};if(db.type!=='weapon'&&db.type!=='armor'&&db.type!=='accessory')return;if(p.equipment[slot]===name)return;const old=p.equipment[slot];p.equipment[slot]=name;if(old)addItem(old,1);removeItem(name,1);save();showToast('Экипировано',name,'good','⚔️',1400);renderInv()};
window.unequipItem=function(slot){const old=p.equipment?.[slot];if(!old)return;addItem(old,1);p.equipment[slot]=null;save();renderInv()};
function renderLog(){main.innerHTML=`<section class="card"><h3>Журнал приключений</h3><div class="log">${p.log.map(x=>`<div class="msg">${esc(x)}</div>`).join('')}</div><button class="btn red" style="margin-top:12px" onclick="if(confirm('Очистить журнал?')){p.log=[];save();renderLog()}">Очистить журнал</button></section>`}
function renderCombat(){const e=battleEnemy(),ratio=Math.max(0,p.battle.hp/e.hp),maxHp=100+p.level*10+(p.abilities.includes('survive')?15:0),maxMp=50+(p.abilities.includes('mana')?10:0);document.body.classList.add('combat-mode');main.innerHTML=`<section class="hero"><div class="title">СРАЖЕНИЕ</div><div class="subtitle">РАУНД ${p.battle.round} • ${esc(p.loc)}</div></section><section class="card" style="margin-top:10px"><div class="combat-arena"><div class="combat-side"><div class="combat-portrait hero-combat-portrait"><img src="${portraitPath(p.heroPortrait||portraitList()[0]||'nord_m1')}" alt="${esc(p.name||'Герой')}"></div><strong>${esc(p.name||'Герой')}</strong><div class="muted">Уровень ${p.level}</div><div class="combat-bars" style="margin-top:7px"><div class="smallnote">❤️ ${Math.max(0,p.hp)}/${maxHp}<div class="bar hp"><span style="width:${Math.max(0,p.hp/maxHp*100)}%"></span></div></div><div class="smallnote">🔷 ${Math.max(0,p.mp)}/${maxMp}<div class="bar mp"><span style="width:${Math.max(0,p.mp/maxMp*100)}%"></span></div></div><div class="smallnote">🟢 ${Math.max(0,p.st)}/100<div class="bar st"><span style="width:${Math.max(0,p.st)}%"></span></div></div></div></div><div class="combat-side enemy"><div class="combat-portrait">${enemyIcon(e)}</div><strong>${esc(p.battle.enemy)}</strong><div class="muted">Уровень ${e.lvl}</div><div class="smallnote" style="margin-top:7px">❤️ ${Math.max(0,p.battle.hp)}/${e.hp}<div class="enemyHp"><span style="width:${ratio*100}%"></span></div></div><div class="smallnote" style="margin-top:7px">${e.skills.slice(0,3).join(' • ')}${p.battle.mode==='danger'?` • 🛡️ ${p.battle.enemyArmor||0} • ⚔️ ${p.battle.enemyAttack||0}`:''}</div></div></div></section><section class="card turn-card" style="margin-top:10px"><h3>⚡ Текущий ход</h3><div class="notice">${esc(p.battle.status||'Твой ход. Кнопки боя закреплены внизу экрана.')}</div><div class="smallnote" style="margin-top:6px">Энергия: ${Math.max(0,p.st)}/100 • Магия: ${Math.max(0,p.mp)}/${maxMp}</div></section><section class="card" style="margin-top:10px"><h3>Ход боя</h3><div class="log combat-log">${p.log.slice(0,6).map(x=>`<div class="msg">${esc(x)}</div>`).join('')}</div></section><div class="combat-actions"><div class="combat-actions-grid"><button class="btn cyan" onclick="combatAction('attack')"><strong>⚔️ Атака</strong><small>Надёжный удар</small></button><button class="btn" onclick="combatAction('heavy')"><strong>💥 Сильный</strong><small>-18 выносливости</small></button><button class="btn blue" onclick="combatAction('block')"><strong>🛡️ Блок</strong><small>На 1 ход</small></button><button class="btn purple" onclick="combatAction('spell')"><strong>🔮 Магия</strong><small>-15 маны</small></button><button class="btn" onclick="combatAction('potion')"><strong>🧪 Зелье</strong><small>+45 ❤️</small></button><button class="btn red" onclick="combatAction('flee')"><strong>🏃 Бежать</strong><small>55% шанс</small></button></div></div>`}
function renderQuests(){ensureQuestLimits();const lim=p.questLimits;const active=p.quests.active.length?p.quests.active.map(q=>{const st=questState(q),def=questDef(q),pct=Math.min(100,Math.round(st.stage/def.stages.length*100));return `<div class="item quest-active-card"><div><span>📜 ${esc(q)}</span><div class="quest-mini"><div><span style="width:${pct}%"></span></div><small>Этап ${st.stage+1}/${def.stages.length} • ${esc(def.stages[Math.min(st.stage,def.stages.length-1)].title)}</small></div></div><button class="pill" onclick="openQuest('${esc(q)}')">Продолжить</button></div>`}).join(''):'<div class="muted">Нет активных заданий.</div>';const done=p.quests.done.map(q=>`<div class="item questDone"><span>✅ ${esc(q)}</span></div>`).join('')||'<div class="muted">Пока нет выполненных заданий.</div>';const cityQ=(world[p.loc]?.quests||[]).map(q=>{const cd=questCooldownDays(q),blocked=cd>0||lim.taken>=lim.maxTaken||p.quests.active.length>=lim.maxActive;const meta=cd>0?`Следующее поручение через ${cd} дн.`:blocked?`Сегодня лимит: ${lim.taken}/${lim.maxTaken}`:'Новое дело доступно';return `<div class="npc-card"><strong>📜 ${esc(q)}</strong><div class="muted">${esc(questDef(q).brief)}</div><div class="smallnote" style="margin:6px 0">${meta} • До ${lim.maxCompleted} выполненных/день • До ${lim.maxGold} золота за день</div><button class="choice" ${blocked?'disabled aria-disabled="true"':''} onclick="questForCity('${esc(q)}')">${blocked?'🔒 Недоступно':'Взять'}</button></div>`}).join('');main.innerHTML=`<section class="hero"><div class="title">📜 ЗАДАНИЯ</div><div class="subtitle">ЖИВОЙ ГОРОД • ЗАДАНИЯ С РЕАЛЬНЫМ ВЫПОЛНЕНИЕМ</div><p class="smallnote">Поручения имеют дневной лимит и восстановление. Ты не можешь бесконечно зарабатывать на одной доске — новые дела появляются постепенно.</p></section><section class="card" style="margin-top:12px"><h3>📊 Лимиты сегодня</h3><div class="city-status"><div class="pillbox"><b>${lim.taken}/${lim.maxTaken}</b> взято</div><div class="pillbox"><b>${lim.completed}/${lim.maxCompleted}</b> выполнено</div><div class="pillbox"><b>${lim.goldEarned}/${lim.maxGold}</b> золота</div><div class="pillbox"><b>${p.quests.active.length}/${lim.maxActive}</b> активных</div></div></section><section class="card" style="margin-top:12px"><h3>Активные</h3>${active}</section><section class="card" style="margin-top:12px"><h3>Доступные сейчас</h3>${cityQ||'<div class="muted">Новых поручений сейчас нет.</div>'}</section><section class="card" style="margin-top:12px"><h3>Выполненные</h3>${done}</section><button class="btn" style="margin-top:12px" onclick="showScreen('world')">↩️ Вернуться в город</button>`}
function ensureGuildState(){if(!p.guild)p.guild={};if(!p.guildRep)p.guildRep={};if(!p.guildWorld)p.guildWorld={};if(p.activeGuild===undefined)p.activeGuild=null;if(p.guildCooldown===undefined)p.guildCooldown=0;if(!p.guildJoinedAt)p.guildJoinedAt={};for(const g of guilds){if(p.guild[g.id]===undefined)p.guild[g.id]=0;if(p.guildRep[g.id]===undefined)p.guildRep[g.id]=0;if(!p.guildWorld[g.id])p.guildWorld[g.id]={level:1,treasury:0,influence:0,prosperity:50,warWins:0,warLosses:0,warCooldown:0,atWarWith:null}}if(p.activeGuild&&guildRank(p.activeGuild)<=0)p.activeGuild=null}
function guildLocation(g){return g.city||'По всему миру'}
function guildOwned(g){return guildRank(g.id)>0}
function guildCityIds(){return cityGuilds[p.loc]||[]}
function guildRank(id){return Number(p.guild?.[id]||0)}
function guildRepNeeded(rank){return rank<=0?guildRepReq[0]:(guildRepReq[rank-1]||999)}
function activeGuild(){return guilds.find(g=>g.id===p.activeGuild)||null}
function guildWorldState(id){ensureGuildState();return p.guildWorld[id]}
function canGuildAction(id,minRank=1){return p.activeGuild===id&&guildRank(id)>=minRank}
function startGuildTrial(id){ensureGuildState();if(p.activeGuild&&p.activeGuild!==id){addLog(`🏰 Ты уже состоишь в гильдии «${activeGuild()?.name||'другой'}». Сначала покинь её.`,'bad');renderGuilds();return}if(guildRank(id)>0){addLog(`🏰 Ты уже состояшь в гильдии «${guilds.find(g=>g.id===id).name}».`);renderGuilds();return}p.guildTrial={id,question:0,score:0};showScreen('guildTrial')}
function answerGuildTrial(choice){const t=p.guildTrial;if(!t)return;const pack=guildTrials[t.id];const q=pack.questions[t.question];if(choice===q[2]){t.score++;addLog('✅ Испытание: верный ответ.','good')}else addLog('❌ Испытание: ошибка.','bad');t.question++;if(t.question>=pack.questions.length){const g=guilds.find(x=>x.id===t.id);if(t.score>=2&&(!p.activeGuild||p.activeGuild===t.id)){p.guild[t.id]=Math.max(1,p.guild[t.id]||0);p.guildRep[t.id]=p.guildRep[t.id]||0;p.activeGuild=t.id;p.guildJoinedAt[t.id]=gameDays();addLog(`🏰 Испытание пройдено! Ты принят в «${g.name}» как «${guildRanks[t.id][guildRank(t.id)-1]}».`,'good')}else addLog(p.activeGuild&&p.activeGuild!==t.id?'❌ Нельзя вступить в другую гильдию, пока ты состоишь в текущей.':`❌ Ты провалил испытание «${g.name}». Нужно минимум 2 из 3.`,'bad');p.guildTrial=null;save();showScreen('guilds');return}save();renderGuildTrial()}
function leaveGuild(){ensureGuildState();const g=activeGuild();if(!g){addLog('Ты сейчас не состоишь в гильдии.');renderGuilds();return}p.activeGuild=null;p.guildTrial=null;p.guildCooldown=1;p.guildJoinedAt[g.id]=gameDays();addLog(`🚪 Ты покинул «${g.name}». Ранг и репутация сохранены. Новую гильдию можно выбрать после следующего игрового дня.`,'info');advanceTime(60,'Выход из гильдии');save();showScreen('guilds')}
function checkGuildPromotion(id){let r=guildRank(id),rep=p.guildRep[id]||0;if(r<=0)return;while(r<10&&rep>=guildRepNeeded(r)){const need=guildRepNeeded(r);rep-=need;r++;p.guild[id]=r;addLog(`⭐ Повышение в «${guilds.find(g=>g.id===id).name}»: ${guildRanks[id][r-1]}. Открыто: ${guildUnlocks[id][r-1]}.`,'good')}p.guildRep[id]=rep}
function guildMission(id){if(!canGuildAction(id,1)){if(guildRank(id)<=0)return startGuildTrial(id);return addLog('Только текущая гильдия может выдавать тебе полноценные поручения.','bad')}const g=guilds.find(x=>x.id===id),r=guildRank(id);const reward=4+r*2;p.guildRep[id]=(p.guildRep[id]||0)+reward;gainXp(18+r*2);guildWorldState(id).influence+=2+r;addLog(`🎯 Выполнено поручение «${g.mission}». Репутация +${reward}, влияние +${2+r}.`,'good');checkGuildPromotion(id);save();renderGuilds()}
function guildTrain(id){if(!canGuildAction(id,2))return addLog('Тренировка открывается с 2-го ранга.','bad');const r=guildRank(id),skillsMap={companions:'Одноручное оружие',mages:'Магия разрушения',thieves:'Скрытность',dark:'Скрытность',guards:'Блокирование',hunters:'Стрельба',miners:'Тяжёлая броня',alchemists:'Алхимия',sailors:'Красноречие',merchants:'Красноречие',warriors_east:'Двуручное оружие',voice:'Воля'},sk=skillsMap[id];if(sk)skill(sk,1+r);guildWorldState(id).influence+=1;advanceTime(20,'Гильдейская тренировка');addLog(`⚔️ Тренировка: ${sk||'профильный навык'} +${1+r}.`,'good');save();renderGuilds()}
function guildInvest(id){if(!canGuildAction(id,4))return addLog('Развитие гильдии открывается с 4-го ранга.','bad');const w=guildWorldState(id),cost=80+w.level*60;if(p.gold<cost)return addLog(`Нужно ${cost} золота.`,'bad');p.gold-=cost;w.treasury+=cost;w.level=Math.min(10,w.level+1);w.prosperity=Math.min(100,w.prosperity+8);w.influence+=6;advanceTime(45,'Развитие гильдии');addLog(`🏗️ Гильдия «${guilds.find(g=>g.id===id).name}» улучшена до уровня ${w.level}.`,'good');save();renderGuilds()}
function guildRecruit(id){if(!canGuildAction(id,6))return addLog('Вербовка доступна с 6-го ранга.','bad');const w=guildWorldState(id);w.influence+=5;w.treasury+=25;addLog(`👥 Ты помог пополнить ряды гильдии. Влияние +5, казна +25.`,'good');save();renderGuilds()}
function guildDiplomacy(id){if(!canGuildAction(id,7))return addLog('Дипломатия доступна с 7-го ранга.','bad');const rivalId=guildRival[id];const rival=guilds.find(g=>g.id===rivalId);const w=guildWorldState(id);w.influence+=4;w.prosperity=Math.min(100,w.prosperity+5);addLog(`🤝 Переговоры с «${rival?.name||'соседней гильдией'}» завершены. Влияние +4.`,'good');save();renderGuilds()}
function guildWar(id){if(!canGuildAction(id,8))return addLog('Война доступна с 8-го ранга.','bad');const w=guildWorldState(id);if(w.warCooldown>0)return addLog(`До следующей войны ${w.warCooldown} дней.`,'bad');const rivalId=guildRival[id],rival=guilds.find(g=>g.id===rivalId)||guilds.find(g=>g.id!==id);const rw=guildWorldState(rival.id),power=w.level*10+w.influence+guildRank(id)*7+Math.floor(Math.random()*20),enemyPower=rw.level*10+rw.influence+guildRank(rival.id)*4+Math.floor(Math.random()*20);w.atWarWith=rival.id;rw.atWarWith=id;w.warCooldown=5;advanceTime(180,'Гильдейская война');if(power>=enemyPower){w.warWins++;w.treasury+=120;w.influence+=10;w.prosperity=Math.min(100,w.prosperity+7);rw.prosperity=Math.max(0,rw.prosperity-10);addLog(`🏆 Тысяча факелов войны: «${guilds.find(g=>g.id===id).name}» побеждает «${rival.name}». В казну +120.`,'good')}else{w.warLosses++;w.prosperity=Math.max(0,w.prosperity-8);rw.influence+=8;addLog(`⚔️ Война проиграна. «${rival.name}» усиливается.`,'bad')}save();renderGuilds()}
function guildActivity(id,action){if(action==='training')return guildTrain(id);if(action==='contract')return guildMission(id);if(action==='privilege'){if(!canGuildAction(id,3))return addLog('Полномочия открываются с 3-го ранга.','bad');addLog(`✨ Тебе доступно: ${guildUnlocks[id][guildRank(id)-1]}.`,'good');return renderGuilds()}if(action==='invest')return guildInvest(id);if(action==='recruit')return guildRecruit(id);if(action==='diplomacy')return guildDiplomacy(id);if(action==='war')return guildWar(id)}
function renderGuilds(){ensureGuildState();const localIds=new Set(guildCityIds()),current=activeGuild();const cards=guilds.map(g=>{const r=guildRank(g.id),rep=p.guildRep[g.id]||0,w=guildWorldState(g.id),local=localIds.has(g.id),member=p.activeGuild===g.id,other=p.activeGuild&&p.activeGuild!==g.id,need=r<10?guildRepNeeded(r):0;const join=!p.activeGuild&&!p.guildCooldown&&r===0?`<button class="choice" onclick="startGuildTrial('${g.id}')">🏰 Пройти испытание</button>`:(!p.activeGuild&&p.guildCooldown?`<div class="notice" style="margin-top:8px">После ухода из гильдии нужно прожить ещё ${p.guildCooldown} игровой день.</div>`:'');const acts=member?`<div class="smallnote" style="margin-top:7px">🏛️ Уровень ${w.level}/10 • Казна ${w.treasury} • Влияние ${w.influence} • Процветание ${w.prosperity}</div><div class="smallnote">⚔️ Войны: ${w.warWins} побед / ${w.warLosses} поражений</div><div class="guild-actions" style="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:8px"><button class="choice" onclick="guildActivity('${g.id}','training')">⚔️ Тренировка</button><button class="choice" onclick="guildActivity('${g.id}','contract')">📜 Контракт</button><button class="choice" onclick="guildActivity('${g.id}','privilege')">✨ Полномочие</button><button class="choice" onclick="guildActivity('${g.id}','invest')">🏗️ Развивать</button><button class="choice" onclick="guildActivity('${g.id}','recruit')">👥 Вербовать</button><button class="choice" onclick="guildActivity('${g.id}','diplomacy')">🤝 Дипломатия</button><button class="choice guild-war" onclick="guildActivity('${g.id}','war')">⚔️ Вести войну</button><button class="choice red" onclick="leaveGuild()">🚪 Покинуть</button></div>`:'';const info=r?`⭐ Ранг: <b>${esc(guildRanks[g.id][r-1])}</b> (${r}/10) • Репутация ${rep}${r<10?` / ${need}`:' • МАКСИМУМ'}`:'🔒 Не состоишь';return `<div class="entity" style="border-left:${member||local?'3px solid #69d6c9':'3px solid #263c43'}"><div class="avatar">${g.icon}</div><div style="flex:1"><strong>${esc(g.name)}</strong><div class="muted">${esc(g.desc)}</div><div class="smallnote">🏙️ Штаб: <b>${esc(guildLocation(g))}</b>${local?' • 📍 Ты здесь':''}</div><div class="smallnote" style="margin-top:4px">${info}</div><div class="smallnote" style="margin-top:4px">🔓 ${esc(guildUnlocks[g.id][Math.max(0,r-1)]||guildUnlocks[g.id][0])}</div>${member?acts:(other?`<div class="notice" style="margin-top:8px">Ты уже состоишь в «${esc(current?.name||'другой гильдии')}».</div>`:join)}</div></div>`}).join('');const memberBox=current?`<div class="notice" style="margin-bottom:10px">🏰 Твоя гильдия: <b>${esc(current.name)}</b> • Ранг ${guildRank(current.id)}/10 • Репутация ${p.guildRep[current.id]||0}</div>`:'<div class="notice" style="margin-bottom:10px">Ты пока не состоишь ни в одной гильдии.</div>';main.innerHTML=`<section class="hero"><div class="title">🏰 ГИЛЬДИИ</div><div class="subtitle">${esc(p.loc)} • ${current?`Твоя: ${esc(current.name)}`:'Выбери путь'}</div><p class="smallnote">Можно состоять только в одной гильдии. Ранги, репутация и развитие сохраняются. На высоких рангах открываются развитие штаба, вербовка, дипломатия и войны.</p></section><section class="card">${memberBox}${cards}</section><button class="btn" style="margin-top:12px" onclick="showScreen('world')">↩️ Вернуться в город</button>`}
function renderGuildTrial(){const t=p.guildTrial;if(!t){showScreen('guilds');return}const g=guilds.find(x=>x.id===t.id),q=guildTrials[t.id].questions[t.question],n=t.question+1;main.innerHTML=`<section class="hero"><div class="title">ИСПЫТАНИЕ ГИЛЬДИИ</div><div class="subtitle">${g.icon} ${esc(g.name)} • ШАГ ${n}/3</div><p style="line-height:1.55;color:#c7d3cf">${esc(g.trial)}</p></section><section class="card" style="margin-top:12px"><h3>${esc(q[0])}</h3>${q[1].map((a,i)=>`<button class="choice" onclick="answerGuildTrial(${i})">${i+1}. ${esc(a)}</button>`).join('')}<div class="notice" style="margin-top:12px">Правильных ответов: ${t.score}/3. Нужно минимум 2.</div></section><button class="btn" style="margin-top:12px" onclick="p.guildTrial=null;save();showScreen('guilds')">↩️ Отказаться от испытания</button>`}
function buyHouse(){let d=world[p.loc];if(!d.house){addLog('В этом месте нет подходящих домов.');return}if(p.ownedHouses.includes(p.loc)){addLog('Дом уже принадлежит тебе.');return}if(p.gold<d.house){addLog(`Не хватает ${d.house-p.gold} золота.`,'bad');return}p.gold-=d.house;p.ownedHouses.push(p.loc);addLog(`🏠 Ты покупаешь дом в ${p.loc} за ${d.house} золота.`,'good');save();renderWorld()}
function recruitNpc(name){if(p.companions.includes(name)){addLog('Этот спутник уже с тобой.');return}p.companions.push(name);addLog(`🤝 ${name} становится твоим спутником.`,'good');save();renderCompanions()}
function tradeBuy(item){let d=itemDb[item];if(!d)return;worldEngineEnsureState();const econ=p.worldEngine.cities[p.loc]?.economy||100;let price=Math.max(1,Math.round(d.price*(econ/100)));if(p.gold<price){addLog('Недостаточно золота.','bad');return}p.gold-=price;addItem(item);addLog(`🛒 Ты покупаешь ${item} за ${price} золота.`,'good');save();renderTrade()}
function tradeSell(item){let d=itemDb[item];if(!d||!removeItem(item)){addLog('Этого предмета нет в инвентаре.');return}worldEngineEnsureState();const econ=p.worldEngine.cities[p.loc]?.economy||100;let price=Math.max(1,Math.floor(d.price*.55*(econ/100)));p.gold+=price;addLog(`💰 Ты продаешь ${item} за ${price} золота.`,'good');save();renderTrade()}
function castMagic(){if(p.mp<12){addLog('Недостаточно магии.','bad');return}p.mp-=12;skill('Магия разрушения',1);addLog('🔮 Ты тренируешь магию разрушения и создаешь искры льда.','good');save();renderMagic()}
let npcSceneRefreshTimer=null;
function startNpcSceneRefresh(){clearInterval(npcSceneRefreshTimer);npcSceneRefreshTimer=setInterval(()=>{if(document.body.classList.contains('creating'))return;if(window.__NORD_ACTIVE_SCREEN==='world'){try{renderWorld()}catch(e){}}},12000)}
startNpcSceneRefresh();
function npcAction(n){p.dialogNpc=n;p.tradeNpc=null;p.dialogMsg='';showScreen('dialog')}
function npcTalk(n){const d=npcDb[n]||{about:'У этого человека пока нет подробной истории.'};p.dialogMsg=`${n}: ${d.about||'Человек внимательно смотрит на тебя.'}`;addLog(`💬 ${p.dialogMsg}`,'info');save()}
function npcRumor(n){const d=npcDb[n]||{};const r=(d.rumors&&d.rumors.length?d.rumors:['Ничего нового. Город живет своей жизнью.'])[Math.floor(Math.random()*(d.rumors?.length||1))];p.dialogMsg=`${n} делится слухом: «${r}»`;addLog(`👂 ${p.dialogMsg}`,'info');save()}
function npcQuest(n){const d=npcDb[n]||{};const pool=d.quests||[];if(!pool.length){p.dialogMsg=`${n}: Сейчас у меня нет работы для тебя.`;addLog(p.dialogMsg);save();return}const q=pool.find(q=>!p.quests.active.includes(q)&&questCooldownDays(q)===0)||pool[0];if(!canTakeQuest(q)){p.dialogMsg=`${n}: Сейчас новых поручений для тебя нет. Попробуй позже.`;save();return}p.quests.active.push(q);questState(q);registerQuestTaken(q);p.dialogMsg=`${n} поручает тебе: «${q}». Задание добавлено в журнал.`;addLog(`📜 ${p.dialogMsg}`,'good');save();showToast('Новое поручение',`Сегодня взято: ${p.questLimits.taken}/${p.questLimits.maxTaken}.`,'good','📜',2000)}
function npcKey(n){return encodeURIComponent(String(n))}
function tradeWithNpc(n){if(!npcDb[n]?.vendor){addLog(`${n} ничего не продает.`);return}p.tradeNpc=n;showScreen('trade')}
function renderTrade(){const shop=cityShopStock().filter(n=>{const r=(itemDb[n]||{}).rarity;return !r||r==='common'||r==='uncommon'});const rows=shop.map(n=>{const d=itemDb[n]||{};const price=Math.round((d.price||30)*(p.cityPrices||100)/100);return `<div class="item"><span><b>${esc(n)}</b><small class="muted" style="display:block">${rarityLabel(d)}${d.damage?' • Урон '+d.damage:''}${d.armor?' • Броня '+d.armor:''}</small></span><button class="pill action-pill" onclick="tradeBuy(decodeURIComponent('${encodeURIComponent(n)}'))">Купить • ${price} 🪙</button></div>`}).join('');const sell=(p.inv||[]).map(x=>{const d=itemDb[x[0]]||{};const price=Math.max(1,Math.floor((d.price||10)*.55));return `<div class="item"><span>${esc(x[0])} ×${x[1]}</span><button class="pill action-pill" onclick="tradeSell(decodeURIComponent('${encodeURIComponent(x[0])}'))">Продать • ${price} 🪙</button></div>`}).join('');main.innerHTML=`<section class="hero"><div class="title">🛒 ТОРГОВЕЦ</div><div class="subtitle">${esc(p.loc)} • Ассортимент города</div></section><section class="card" style="margin-top:12px"><h3>Купить</h3>${rows||'<div class="muted">В этом городе торговец сегодня пуст.</div>'}</section><section class="card" style="margin-top:12px"><h3>Продать добычу</h3>${sell||'<div class="muted">Нечего продавать.</div>'}</section><button class="btn" style="margin-top:12px" onclick="showScreen('world')">↩️ Вернуться</button>`}

function renderDialog(){const n=p.dialogNpc||'Житель';const d=npcDb[n]||{role:'Житель',about:'Местный житель.',rumors:[],quests:[]};const q=(d.quests||[]).map(x=>`<div class="item"><span>📜 ${esc(x)}</span><button class="pill" onclick="npcQuest(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">Взять</button></div>`).join('')||'<div class="muted">У этого NPC сейчас нет поручений.</div>';const rumors=(d.rumors||[]).slice(0,4).map(x=>`<div class="item"><span>👂 ${esc(x)}</span></div>`).join('')||'<div class="muted">Слухов пока нет.</div>';main.innerHTML=`<section class="hero"><div class="title">РАЗГОВОР</div><div class="subtitle">${esc(n)} • ${esc(d.role||'Житель')}</div></section><section class="card" style="margin-top:12px"><div class="entity"><div class="npc-portrait"><div style="width:100%;height:100%;display:grid;place-items:center;font-size:44px">${d.companion?'🤝':d.vendor?'🛒':'👤'}</div></div><div><h3 style="margin:0">${esc(n)}</h3><div class="muted">${esc(d.about||'')}</div>${d.vendor?'<span class="vendorTag" style="margin-top:6px">Торговец</span>':''}</div></div><div class="dialogBox notice" style="margin-top:12px">${esc(p.dialogMsg||'«Добрый день. Чем могу помочь?»')}</div><div class="dialog-actions" style="margin-top:12px"><button class="btn cyan" onclick="npcTalk(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">💬 Поговорить</button><button class="btn" onclick="npcRumor(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">👂 Спросить слухи</button>${d.vendor?`<button class="btn" onclick="tradeWithNpc(decodeURIComponent('${encodeURIComponent(n)}'))">🛒 Торговать</button>`:''}<button class="btn" onclick="npcQuest(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">📜 Спросить о работе</button><button class="btn red" onclick="p.dialogNpc=null;p.dialogMsg='';showScreen('world')">↩️ Попрощаться</button></div></section><section class="card" style="margin-top:12px"><h3>Слухи</h3>${rumors}</section><section class="card" style="margin-top:12px"><h3>Доступные задания</h3>${q}</section><button class="btn" style="margin-top:12px" onclick="showScreen('world')">↩️ Вернуться в город</button>`}
let creatorTab=1;
function setCreatorTab(n){creatorTab=Math.max(1,Math.min(4,Number(n)||1));showCreate();requestAnimationFrame(()=>document.querySelector('[data-creator-section=\"'+creatorTab+'\"]')?.scrollIntoView({behavior:'smooth',block:'start'}))}
function selectRace(r){p.race=r;const list=portraitList(r,p.gender);if(!list.includes(p.heroPortrait))p.heroPortrait=list[0]||'nord_1';showCreate()}
function selectGender(g){p.gender=g;const list=portraitList(p.race,g);if(!list.includes(p.heroPortrait))p.heroPortrait=list[0]||'nord_1';save();showCreate()}
function selectPortrait(k){const list=portraitList();if(list.includes(String(k)))p.heroPortrait=String(k);save();showCreate();return false}
function creatorOrigin(){return originOptions[p.origin||'Северные земли']||originOptions['Северные земли']}
function creatorPast(){return pastOptions[p.past||'Воин']||pastOptions['Воин']}
function creatorPersonality(){return personalityOptions[p.trait||'Воин']||personalityOptions['Воин']}
function creatorSign(){return signs[p.sign||'Воин']||signs['Воин']}
function creatorTalent(){return talents[p.talent||'Крепкое тело']||talents['Крепкое тело']}
function creatorWeakness(){return weaknesses[p.weakness||'Боязнь нежити']||weaknesses['Боязнь нежити']}
function creatorStyle(){return combatStyles[p.combatStyle||'Меч и щит']||combatStyles['Меч и щит']}
function creatorAlignment(){return alignments[p.alignment||'Нейтральный']||alignments['Нейтральный']}
function allocPointsTotal(){return Object.values(p.attrPoints||{}).reduce((a,b)=>a+b,0)}
function attrBase(k){return 5+(raceBonuses[p.race]?.[k]||0)+(creatorOrigin().bonus[k]||0)+(creatorPersonality().bonus[k]||0)+(creatorSign().bonus[k]||0)}
function attrValue(k){return attrBase(k)+(p.attrPoints?.[k]||0)}
function changeAttr(k,d){p.attrPoints=p.attrPoints||{};let cur=p.attrPoints[k]||0;let total=allocPointsTotal();if(d>0&&(cur>=10||total>=10))return;if(d<0&&cur<=0)return;p.attrPoints[k]=cur+d;showCreate()}
function applyCreation(){
  p.name=(document.getElementById('nm')?.value||p.name||'Безымянный').trim()||'Безымянный';
  p.attributes={};attrDefs.forEach(([k])=>p.attributes[k]=attrValue(k));
  p.origin=p.origin||'Северные земли';p.past=p.past||'Воин';p.trait=p.trait||'Воин';p.sign=p.sign||'Воин';p.talent=p.talent||'Крепкое тело';p.weakness=p.weakness||'Боязнь нежити';p.combatStyle=p.combatStyle||'Меч и щит';p.alignment=p.alignment||'Нейтральный';p.heroPortrait=p.heroPortrait||portraitList()[0]||'nord_1';
  if(!p.baseSkillsApplied){
    for(const src of [creatorOrigin().skills,creatorPast().skills,creatorStyle().skills]) for(const [k,v] of Object.entries(src||{})) p.skills[k]=(p.skills[k]||0)+v;
    p.baseSkillsApplied=true;
  }
  if(!p.characterCreated){
    creatorStyle().gear.forEach(x=>addItem(x[0],x[1]));addItem('Зелье лечения',2);p.characterCreated=true;
  }
  p.characterCreated=true;save();addLog('⚔️ Ты создал героя и выбрал свою судьбу.','good');creatorTab=1;showScreen('world')
}
function optionButtons(obj,current,field){return Object.keys(obj).map(k=>{const x=obj[k];return `<button class="miniChoice ${current===k?'active':''}" onclick="p.${field}=${JSON.stringify(k)};showCreate()"><span class="ic">${x.icon}</span>${esc(k)}</button>`}).join('')}
function handleCreatorAction(el){
  if(!el)return false;
  const a=el.dataset.creatorAction, v=el.dataset.value;
  if(!a)return false;
  try{
    if(a==='tab'){setCreatorTab(Number(v));}
    else if(a==='race') selectRace(v);
    else if(a==='portrait') selectPortrait(v);
    else if(a==='origin'){p.origin=v;showCreate();}
    else if(a==='past'){p.past=v;showCreate();}
    else if(a==='attr') changeAttr(v,Number(el.dataset.delta||0));
    else if(a==='talent'){p.talent=v;showCreate();}
    else if(a==='weakness'){p.weakness=v;showCreate();}
    else if(a==='combatStyle'){p.combatStyle=v;showCreate();}
    else if(a==='alignment'){p.alignment=v;showCreate();}
    else if(a==='gender') selectGender(v);
    else if(a==='start'){if(creatorTab!==4){setCreatorTab(4);return true;}applyCreation();}
    return true;
  }catch(err){console.error('creator action failed',a,v,err);return true;}
}
function bindCreatorInteractions(){
  const root=document.querySelector('.creator-v9'); if(!root)return;
  root.addEventListener('click',function(ev){
    const el=ev.target.closest('[data-creator-action]');
    if(el && root.contains(el)){ev.preventDefault();ev.stopPropagation();handleCreatorAction(el);}
  },true);
  const age=root.querySelector('[data-creator-age]');
  if(age){age.addEventListener('input',function(){p.age=Number(this.value);const lab=root.querySelector('.age-value');if(lab)lab.textContent=p.age;});age.addEventListener('change',function(){p.age=Number(this.value);showCreate();});}
}
function showCreate(){
  p.attrPoints=p.attrPoints||{};creatorTab=Math.max(1,Math.min(4,creatorTab||1));p.origin=p.origin||'Северные земли';p.past=p.past||'Воин';p.trait=p.trait||'Воин';p.sign=p.sign||'Воин';p.talent=p.talent||'Крепкое тело';p.weakness=p.weakness||'Боязнь нежити';p.combatStyle=p.combatStyle||'Меч и щит';p.alignment=p.alignment||'Нейтральный';p.heroPortrait=p.heroPortrait||portraitList()[0]||'nord_1';
  const raceIcons={'Норд':'🏔️','Имперец':'🦅','Эльф':'🌿','Тёмный эльф':'🌑','Орк':'🛡️','Каджит':'🐾','Аргонианин':'🐊'};
  const raceBtns=races.map(r=>`<button type="button" class="creator-race ${p.race===r?'active':''}" data-creator-action="race" data-value="${esc(r)}"><span class="ic">${raceIcons[r]}</span>${r}</button>`).join('');
  const portraits=portraitList().map((k,i)=>`<button type="button" class="creator-portrait ${p.heroPortrait===k?'active':''}" data-creator-action="portrait" data-value="${esc(k)}"><img src="${portraitPath(k)}" alt="Портрет ${i+1}"></button>`).join('');
  const originBtns=Object.keys(originOptions).map(k=>{const x=originOptions[k];return `<button type="button" class="creator-mini ${p.origin===k?'active':''}" data-creator-action="origin" data-value="${esc(k)}"><span class="ic">${x.icon}</span>${esc(k)}</button>`}).join('');
  const pastBtns=Object.keys(pastOptions).map(k=>{const x=pastOptions[k];return `<button type="button" class="creator-mini ${p.past===k?'active':''}" data-creator-action="past" data-value="${esc(k)}"><span class="ic">${x.icon}</span>${esc(k)}</button>`}).join('');
  const attrs=attrDefs.map(([k,ic])=>{let v=attrValue(k);let on=Math.min(7,Math.max(1,Math.round(v/2)));return `<div class="creator-attr"><span>${ic}</span><span>${k}</span><button type="button" data-creator-action="attr" data-value="${esc(k)}" data-delta="-1">−</button><span class="v">${v}</span><button type="button" data-creator-action="attr" data-value="${esc(k)}" data-delta="1">+</button></div><div class="creator-bars" style="margin:-3px 0 2px 20px">${Array.from({length:7},(_,i)=>`<i class="${i<on?'on':''}"></i>`).join('')}</div>`}).join('');
  const opt=(obj,current,field,extra='')=>Object.keys(obj).map(k=>{const x=obj[k];return `<button type="button" class="creator-option ${extra} ${current===k?'active':''}" data-creator-action="${field}" data-value="${esc(k)}"><strong>${x.icon||'✦'} ${esc(k)}</strong><span>${esc(x.desc||x.bonus||'')}</span></button>`}).join('');
  const styles=Object.keys(combatStyles).map(k=>{const x=combatStyles[k];return `<button type="button" class="creator-style ${p.combatStyle===k?'active':''}" data-creator-action="combatStyle" data-value="${esc(k)}"><span class="ic">${x.icon}</span>${esc(k)}</button>`}).join('');
  const aligns=Object.keys(alignments).map(k=>{const x=alignments[k];return `<button type="button" class="creator-style ${p.alignment===k?'active':''}" data-creator-action="alignment" data-value="${esc(k)}"><span class="ic">${x.icon}</span>${esc(k)}</button>`}).join('');
  const summaryStats=attrDefs.map(([k,ic])=>`<div class="creator-summary-stat"><b>${attrValue(k)}</b>${ic} ${k}</div>`).join('');
  main.innerHTML=`<section class="creator-v9">
    <div class="creator-top"><div class="creator-brandrow"><div><div class="kicker">NORD • НОВАЯ СУДЬБА</div></div><div class="gem">💎 0 &nbsp; ⚙</div></div><div class="creator-main-title">СОЗДАНИЕ ГЕРОЯ</div><div class="creator-main-sub">ТВОЯ ИСТОРИЯ НАЧИНАЕТСЯ</div><div class="creator-stepbar">${[['Внешность',1],['Происхождение',2],['Развитие',3],['Итог',4]].map(([name,n])=>`<button type="button" class="creator-step ${creatorTab===n?'active':''} ${creatorTab>n?'done':''}" data-creator-action="tab" data-value="${n}"><b>${n}</b>${name}</button>`).join('')}</div></div>
    <section data-creator-section="1" class="creator-section creator-step-section ${creatorTab===1?"":"is-hidden"}"><div class="creator-section-title"><div><span class="num">1</span> ВНЕШНОСТЬ</div><span>РАСА • ПОРТРЕТ • ДАННЫЕ</span></div>
      <div class="creator-races">${raceBtns}</div>
      <div class="creator-appearance" style="margin-top:8px"><div><div class="label">Выбери портрет</div><div class="creator-portraits">${portraits}</div></div><div><div class="creator-fields"><div class="creator-field name-field"><label>Имя героя</label><input id="nm" class="input" value="${esc(p.name)}" oninput="p.name=this.value" placeholder="Имя героя"></div><div class="creator-field"><label>Пол</label><div class="creator-gender"><button type="button" class="btn ${p.gender==='Мужской'?'cyan':''}" data-creator-action="gender" data-value="Мужской">♂</button><button type="button" class="btn ${p.gender==='Женский'?'cyan':''}" data-creator-action="gender" data-value="Женский">♀</button></div></div><div class="creator-field"><label>Возраст: <span class="age-value">${p.age}</span></label><input data-creator-age type="range" min="16" max="60" value="${p.age}" style="width:100%;margin-top:9px"></div></div><div class="creator-origin-note">🛡️ Выбранный портрет автоматически появится в бою, профиле и диалогах.</div></div></div><button type="button" class="btn cyan creator-next" data-creator-action="tab" data-value="2">Далее: Происхождение →</button>
    </section>
    <section data-creator-section="2" class="creator-section creator-step-section ${creatorTab===2?"":"is-hidden"}"><div class="creator-section-title"><div><span class="num">2</span> ПРОИСХОЖДЕНИЕ И ПРОШЛОЕ</div><span>ТВОЯ ИСТОРИЯ ФОРМИРУЕТ СТАРТ</span></div><div class="creator-origin-grid">${originBtns}</div><div class="creator-origin-note">${esc(creatorOrigin().desc)}</div><div class="creator-past-grid">${pastBtns}</div><div class="creator-fields" style="margin-top:8px"><div class="creator-field"><label>Характер</label><select class="select" onchange="p.trait=this.value;showCreate()">${Object.keys(personalityOptions).map(k=>`<option ${p.trait===k?'selected':''}>${esc(k)}</option>`).join('')}</select></div><div class="creator-field"><label>Знак рождения</label><select class="select" onchange="p.sign=this.value;showCreate()">${Object.keys(signs).map(k=>`<option ${p.sign===k?'selected':''}>${esc(k)}</option>`).join('')}</select></div><div class="creator-field"><label>Прошлое</label><div class="smallnote" style="padding-top:8px">${esc(creatorPast().desc)}</div></div></div><button type="button" class="btn cyan creator-next" data-creator-action="tab" data-value="3">Далее: Развитие →</button></section>
    <section data-creator-section="3" class="creator-section creator-step-section ${creatorTab===3?"":"is-hidden"}"><div class="creator-section-title"><div><span class="num">3</span> РАЗВИТИЕ ГЕРОЯ</div><span>ОЧКИ ДЛЯ РАСПРЕДЕЛЕНИЯ: <b class="creator-points">${10-allocPointsTotal()}</b></span></div><div class="creator-dev"><div class="creator-attrs">${attrs}</div><div><div class="creator-options">${opt(talents,p.talent,'talent')}</div><div class="creator-options" style="margin-top:6px">${opt(weaknesses,p.weakness,'weakness','danger')}</div><div class="label" style="margin-top:8px">Стиль боя</div><div class="creator-style-grid">${styles}</div><div class="label" style="margin-top:7px">Мировоззрение</div><div class="creator-align">${aligns}</div></div></div><button type="button" class="btn cyan creator-next" data-creator-action="tab" data-value="4">Далее: Итог →</button></section>
    <section data-creator-section="4" class="creator-section creator-step-section ${creatorTab===4?"":"is-hidden"}"><div class="creator-section-title"><div><span class="num">4</span> ИТОГОВЫЙ ОБЗОР</div><span>ПРОВЕРЬ ПЕРЕД НАЧАЛОМ</span></div><div class="creator-summary"><div class="creator-summary-img"><img src="${portraitPath(p.heroPortrait)}" alt="Герой"></div><div><h3>${esc(p.name||'Безымянный')}</h3><div class="creator-summary-meta">${esc(p.race)} • ${esc(p.gender)} • ${p.age} лет<br>${esc(p.origin)} • ${esc(p.past)}<br>${esc(p.trait)} • ${esc(p.sign)} • ${esc(p.combatStyle)}<br>Талант: ${esc(p.talent)} • Слабость: ${esc(p.weakness)}<br>Путь: ${esc(p.alignment)}</div></div></div><div class="creator-summary-stats">${summaryStats}</div><button type="button" class="btn cyan creator-start" data-creator-action="start">⚔️ НАЧАТЬ ПУТЬ</button></section>
  </section>`;
  bindCreatorInteractions();
}
function renderSettings(){const mState=window.__nordMusicState||{enabled:true};const sState=window.__nordSfxState||{enabled:true};main.innerHTML=`<section class="card"><h3>Настройки и сохранение</h3><div class="item"><span>Персонаж</span><span class="pill">${esc(p.name||'Не создан')}</span></div><div class="item"><span>Локация</span><span class="pill">${esc(p.loc)}</span></div><div class="item"><span>Уровень</span><span class="pill">${p.level}</span></div><button class="btn" onclick="save();showToast('Игра сохранена','Прогресс сохранён.','good','💾',1600)">💾 Сохранить игру</button><button class="btn" style="margin-top:8px" onclick="showScreen('create')">👤 Изменить героя</button><div class="item" style="margin-top:12px"><span>🎵 Музыка</span><span class="pill">${mState.enabled?'ВКЛ':'ВЫКЛ'}</span></div><button class="btn" style="margin-top:8px" onclick="window.toggleMusic()">🎵 Музыка: ${mState.enabled?'ВКЛ':'ВЫКЛ'}</button><div class="item" style="margin-top:10px"><span>🔊 Звуки мира</span><span class="pill">${sState.enabled?'ВКЛ':'ВЫКЛ'}</span></div><button class="btn" style="margin-top:8px" onclick="window.toggleSfx()">🔊 Звуки мира: ${sState.enabled?'ВКЛ':'ВЫКЛ'}</button><button class="btn" style="margin-top:8px" onclick="showScreen('house')">🏠 Дома</button><button class="btn" style="margin-top:8px" onclick="showScreen('mainmenu')">↩️ Главное меню</button><button class="btn red" style="margin-top:8px" onclick="if(confirm('Удалить весь прогресс?')){localStorage.removeItem(KEY);p=fresh();showScreen('create')}">🗑️ Новая игра</button></section>`}
// ===== NORD MAIN MENU V1 =====
function renderMainMenu(){
  const hasSave=Boolean(p&&p.characterCreated&&p.name);
  main.innerHTML=`<section class="main-menu-v2"><div class="main-menu-overlay"></div><div class="main-menu-content"><div class="main-menu-kicker">N O R D</div><h1>НОВАЯ СУДЬБА</h1><div class="main-menu-divider">✦ ❖ ✦</div><p class="main-menu-tagline">Северный мир, который живёт своей жизнью.<br>Твоя история начинается с одного решения.</p><div class="main-menu-actions"><button type="button" class="main-menu-btn" data-menu-action="new" onclick="startNewGameFromMenu();return false;"><span>⚔️</span><div><b>НОВАЯ ИГРА</b><small>Создать героя и начать новую судьбу</small></div></button><button type="button" class="main-menu-btn" data-menu-action="load" onclick="loadGameFromMenu();return false;"><span>📜</span><div><b>ЗАГРУЗИТЬ ИГРУ</b><small>${hasSave?'Сохранение найдено: '+esc(p.name):'Сохранений пока нет'}</small></div></button><button type="button" class="main-menu-btn" data-menu-action="settings" onclick="showScreen('settings');return false;"><span>⚙️</span><div><b>НАСТРОЙКИ</b><small>Музыка, звуки и управление</small></div></button><button type="button" class="main-menu-btn" data-menu-action="about" onclick="renderAboutGame();return false;"><span>📖</span><div><b>ОБ ИГРЕ</b><small>Мир, история и правила NORD</small></div></button><button type="button" class="main-menu-btn danger" data-menu-action="exit" onclick="confirmExitGame();return false;"><span>🚪</span><div><b>ВЫЙТИ</b><small>Закрыть главное меню</small></div></button></div><div class="main-menu-footer">NORD • НОВАЯ СУДЬБА • 4E 201</div></div></section>`;
}
function startNewGameFromMenu(){p=fresh();showScreen('create');}
function loadGameFromMenu(){const saved=localStorage.getItem(KEY)||localStorage.getItem(OLD_KEY)||localStorage.getItem(LEGACY_KEY)||localStorage.getItem(LEGACY2_KEY);if(!saved){showToast('Сохранение не найдено','Сначала начни новую игру.','info','📜',1800);return}try{p=Object.assign(fresh(),JSON.parse(saved));p.equipment=p.equipment||fresh().equipment;p.inv=p.inv||[];p.generatedItems=p.generatedItems||{};Object.assign(itemDb,p.generatedItems);showScreen(p.characterCreated?'world':'create');}catch(e){showToast('Ошибка сохранения','Не удалось прочитать сохранение.','bad','⚠️',2200)}}
function renderAboutGame(){main.innerHTML=`<section class="about-game"><div class="main-menu-kicker">N O R D • НОВАЯ СУДЬБА</div><h1>ОБ ИГРЕ</h1><div class="about-rune">⚔️ ❄️ 🐉</div><p>NORD — это текстовая RPG о северном мире, который не стоит на месте. Здесь нет единственного правильного пути: ты можешь стать воином, магом, торговцем, искателем приключений, членом гильдии или просто человеком, который пытается выжить.</p><p>Города меняются, жители запоминают поступки, дороги бывают опасны, подземелья скрывают случайные события, а редкие предметы нельзя просто купить в первом магазине.</p><p>Твоя сила строится из навыков, характеристик, экипировки, магии и союзников. Мир постепенно открывает новые истории — и далеко не все решения можно вернуть назад.</p><div class="about-quote">«Север не обещает тебе славы. Он предлагает шанс стать тем, кем ты решишь быть.»</div><button class="btn main-menu-back" onclick="showScreen('mainmenu')">↩️ В главное меню</button></section>`}
function confirmExitGame(){try{if(window.Android&&Android.exitApp){Android.exitApp();return}if(navigator.app&&navigator.app.exitApp){navigator.app.exitApp();return}}catch(e){}showToast('Выход','На Android закрытие приложения выполняет система.','info','🚪',2400)}
function showScreen(s){window.__NORD_ACTIVE_SCREEN=s;document.body.dataset.screen=s;if(s!=='tavern'&&s!=='world'&&s!=='create'&&s!=='mainmenu')closeTavernModal();if(s!=='create'&&s!=='mainmenu'&&s!=='settings'&&!p.characterCreated){s='create'}document.body.dataset.screen=s;document.body.classList.toggle('combat-mode',s==='combat');const isCreating=s==='create';const isMainMenu=s==='mainmenu';document.body.classList.toggle('creating',isCreating);const bottom=document.querySelector('.bottom');if(bottom){bottom.hidden=isCreating||isMainMenu;bottom.style.display=(isCreating||isMainMenu)?'none':'';}document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.screen===s));if(s==='mainmenu')renderMainMenu();else if(s==='create')showCreate();else if(s==='world')renderWorld();else if(s==='map')renderMap();else if(s==='profile')renderProfile();else if(s==='skills')renderSkills();else if(s==='inv')renderInv();else if(s==='raids')renderRaids();else if(s==='log')renderLog();else if(s==='combat')renderCombat();else if(s==='quests')renderQuests();else if(s==='guilds')renderGuilds();else if(s==='guildTrial')renderGuildTrial();else if(s==='trade')renderTrade();else if(s==='magic')renderMagic();else if(s==='house')renderHouse();else if(s==='companions')renderCompanions();else if(s==='dialog')renderDialog();else if(s==='tavern')renderTavern();else if(s==='market')renderMarket();else if(s==='arena')renderArena();else if(s==='danger')renderDanger();else if(s==='people')renderPeople();else if(s==='relations')renderRelations();else renderSettings();window.scrollTo({top:0,behavior:'smooth'});try{window.updateMusicForScreen(s);window.updateAmbientForScreen(s);}catch(e){} }

(function(){
  // Single audio engine: music loops, location ambience plays once per screen entry.
  const _musicEnabledKey='nord_music', _sfxEnabledKey='nord_sfx';
  const musicState=window.__nordMusicState={enabled:localStorage.getItem(_musicEnabledKey)!=='off',audio:null,current:'',fadeTimer:null};
  const sfxState=window.__nordSfxState={enabled:localStorage.getItem(_sfxEnabledKey)!=='off',ambient:null,ambientKey:'',ambientTimer:null};
  const musicMap={mainmenu:'loading_nord.ogg',create:'loading_nord.ogg',world:'city_nord.ogg',map:'travel_nord.ogg',tavern:'tavern_nord.ogg',market:'city_nord.ogg',arena:'combat_nord.ogg',combat:'combat_nord.ogg',raids:'night_nord.ogg',night:'night_nord.ogg'};
  const ambientMap={world:'city_ambient.ogg',tavern:'tavern_ambient.ogg',market:'market_ambient.ogg',combat:null,raids:null,map:null,night:'night_ambient.ogg',create:null,arena:'arena_ambient.ogg'};
  const assetMusic=k=>'music/'+k;
  const assetSfx=k=>'sfx/'+k;
  function stopMusic(fade=250){const a=musicState.audio;if(!a)return;clearInterval(musicState.fadeTimer);const start=a.volume,t0=performance.now();musicState.fadeTimer=setInterval(()=>{const t=Math.min(1,(performance.now()-t0)/fade);a.volume=Math.max(0,start*(1-t));if(t>=1){clearInterval(musicState.fadeTimer);try{a.pause();a.currentTime=0}catch(e){}if(musicState.audio===a)musicState.audio=null;musicState.current=''}},30)}
  function playMusic(key){if(!musicState.enabled||!key)return;if(musicState.current===key&&musicState.audio&&!musicState.audio.paused)return;const old=musicState.audio;if(old){try{old.pause();old.currentTime=0}catch(e){}}clearInterval(musicState.fadeTimer);try{const a=new Audio(assetMusic(key));a.loop=true;a.volume=.34;musicState.audio=a;musicState.current=key;const q=a.play();if(q&&q.catch)q.catch(()=>{});}catch(e){musicState.audio=null;musicState.current=''}}
  function playSfx(key,vol=1){if(!sfxState.enabled||!key)return;try{const a=new Audio(assetSfx(key+'.ogg'));a.volume=Math.max(0,Math.min(1,.34*vol));const q=a.play();if(q&&q.catch)q.catch(()=>{});}catch(e){}}
  function stopAmbient(fade=850,after){const a=sfxState.ambient;if(!a){sfxState.ambientKey='';if(after)setTimeout(after,0);return}sfxState.ambientToken=(sfxState.ambientToken||0)+1;const token=sfxState.ambientToken;clearTimeout(sfxState.ambientTimer);clearInterval(sfxState.ambientFadeTimer);const start=a.volume,t0=performance.now();sfxState.ambientFadeTimer=setInterval(()=>{const t=Math.min(1,(performance.now()-t0)/fade);a.volume=Math.max(0,start*(1-t));if(t>=1){clearInterval(sfxState.ambientFadeTimer);try{a.pause();a.currentTime=0}catch(e){}if(sfxState.ambient===a)sfxState.ambient=null;if(sfxState.ambientKey) sfxState.ambientKey='';if(after&&token===sfxState.ambientToken)setTimeout(after,60)}},30)}
  function playAmbientOnce(key){if(!sfxState.enabled||!key)return;if(sfxState.ambientKey===key&&sfxState.ambient&&!sfxState.ambient.paused)return;const startNew=()=>{if(!sfxState.enabled||sfxState.ambientKey===key&&sfxState.ambient)return;try{const a=new Audio(assetSfx(key));a.loop=false;a.volume=0;sfxState.ambient=a;sfxState.ambientKey=key;const end=()=>{if(sfxState.ambient===a){clearTimeout(sfxState.ambientTimer);clearInterval(sfxState.ambientFadeTimer);try{a.pause();a.currentTime=0}catch(e){}sfxState.ambient=null;sfxState.ambientKey=''}};a.addEventListener('ended',end,{once:true});const q=a.play();if(q&&q.catch)q.catch(()=>{});const t0=performance.now();clearInterval(sfxState.ambientFadeTimer);sfxState.ambientFadeTimer=setInterval(()=>{const t=Math.min(1,(performance.now()-t0)/320);a.volume=.12*t;if(t>=1)clearInterval(sfxState.ambientFadeTimer)},30);const scheduleFade=()=>{const ms=Math.max(1200,Math.floor((a.duration||4.8)*1000)-950);clearTimeout(sfxState.ambientTimer);sfxState.ambientTimer=setTimeout(()=>{if(sfxState.ambient===a){const st=a.volume,tt=performance.now();clearInterval(sfxState.ambientFadeTimer);sfxState.ambientFadeTimer=setInterval(()=>{const z=Math.min(1,(performance.now()-tt)/900);a.volume=Math.max(0,st*(1-z));if(z>=1){clearInterval(sfxState.ambientFadeTimer);end()}},30)}},ms)};if(a.readyState>=1)scheduleFade();else a.addEventListener('loadedmetadata',scheduleFade,{once:true});}catch(e){sfxState.ambient=null;sfxState.ambientKey=''}};if(sfxState.ambient)stopAmbient(850,startNew);else startNew()}
  function musicForScreen(s){let key=s;if(key==='world'&&typeof timeLabel==='function'&&timeLabel()==='Ночь')key='night';return musicMap[key]||'city_nord.ogg'}
  function ambientForScreen(s){let key=s;if(key==='world'&&typeof timeLabel==='function'&&timeLabel()==='Ночь')key='night';return ambientMap[key]||null}
  window.updateMusicForScreen=function(s){const key=musicForScreen(s);if(musicState.enabled)playMusic(key);else stopMusic(180)};
  window.stopWorldAmbient=function(){stopAmbient(700)};
  window.updateAmbientForScreen=function(s){if(document.body.classList.contains('booting')){stopAmbient(250);return}if(!sfxState.enabled){stopAmbient();return}const key=ambientForScreen(s);if(!key){stopAmbient();return}playAmbientOnce(key)};
  window.playWorldSfx=function(file){const k=String(file).replace(/\.ogg$/i,'');playSfx(k,.9)};
  window.toggleMusic=function(){musicState.enabled=!musicState.enabled;localStorage.setItem(_musicEnabledKey,musicState.enabled?'on':'off');if(musicState.enabled){window.updateMusicForScreen(document.body.dataset.screen|| (window.p&&window.p.characterCreated?'world':'create'));showToast('Музыка включена','Фоновая музыка снова играет.','good','🎵',1600)}else{stopMusic(220);showToast('Музыка выключена','Звуки мира можно оставить включёнными отдельно.','warn','🔇',1600)}if(document.body.dataset.screen==='settings'&&typeof renderSettings==='function')renderSettings()};
  window.toggleSfx=function(){sfxState.enabled=!sfxState.enabled;localStorage.setItem(_sfxEnabledKey,sfxState.enabled?'on':'off');if(sfxState.enabled){playSfx('ui_confirm',.8);window.updateAmbientForScreen(document.body.dataset.screen||'world');showToast('Звуки мира включены','Окружение проигрывается один раз при входе в место.','good','🔊',1800)}else{stopAmbient();showToast('Звуки мира выключены','Фоновая музыка продолжает работать отдельно.','warn','🔇',1800)}if(document.body.dataset.screen==='settings'&&typeof renderSettings==='function')renderSettings()};
  // Keep named globals available to the existing settings/profile code.
  window.__nordAudioReady=true;

(function(){
  // Tap feedback that never fires during a scroll/drag.
  // We wait until pointerup before showing the glow, then delay the action briefly.
  let gesture=null;
  const THRESHOLD=16;
  const FEEDBACK_MS=760;
  const ACTION_DELAY=160;

  function clear(el){
    if(!el) return;
    el.classList.remove('tap-active');
    clearTimeout(el.__nordTapTimer);
    el.__nordTapTimer=null;
  }

  function rememberTap(el){
    if(!el) return;
    window.__nordTapEl=el;
    window.__nordTapUntil=Date.now()+900;
    clearTimeout(el.__nordTapTimer);
    el.classList.add('tap-active');
    el.__nordTapTimer=setTimeout(()=>el.classList.remove('tap-active'),FEEDBACK_MS);
  }

  function start(e){
    const el=e.target.closest && e.target.closest('button');
    if(!el || el.disabled) return;
    gesture={el,x:e.clientX,y:e.clientY,pointerId:e.pointerId,moved:false};
    window.__nordPressEl=el;
    window.__nordCancelledEl=null;
  }

  function move(e){
    if(!gesture) return;
    if(gesture.pointerId!=null && e.pointerId!=null && gesture.pointerId!==e.pointerId) return;
    const dx=Math.abs((e.clientX||0)-gesture.x);
    const dy=Math.abs((e.clientY||0)-gesture.y);
    if(dx>THRESHOLD || dy>THRESHOLD){
      gesture.moved=true;
      window.__nordCancelledEl=gesture.el;
      window.__nordCancelUntil=Date.now()+900;
      window.__nordPressEl=null;
      clear(gesture.el);
      gesture=null;
    }
  }

  function end(e){
    if(!gesture) return;
    const g=gesture;
    if(g.pointerId!=null && e.pointerId!=null && g.pointerId!==e.pointerId) return;
    gesture=null;
    if(g.moved) return;
    rememberTap(g.el);
  }

  function cancel(){
    if(gesture){
      window.__nordCancelledEl=gesture.el;
      window.__nordCancelUntil=Date.now()+900;
      clear(gesture.el);
      gesture=null;
    }
    window.__nordPressEl=null;
    document.querySelectorAll('button.tap-active').forEach(clear);
  }

  document.addEventListener('pointerdown',start,true);
  document.addEventListener('pointermove',move,true);
  document.addEventListener('pointerup',end,true);
  document.addEventListener('pointercancel',cancel,true);
  document.addEventListener('scroll',cancel,{passive:true,capture:true});
  document.addEventListener('touchcancel',cancel,{passive:true,capture:true});
  document.addEventListener('touchmove',e=>{
    if(!gesture) return;
    const t=e.touches&&e.touches[0];
    if(t) move({clientX:t.clientX,clientY:t.clientY,pointerId:gesture.pointerId});
  },{passive:true,capture:true});

  document.addEventListener('click',function(e){
    const btn=e.target.closest && e.target.closest('button');
    if(!btn || btn.disabled) return;
    if(btn.classList.contains('raid-choice')) return;
    if(btn.dataset.nordReplay==='1'){
      delete btn.dataset.nordReplay;
      return;
    }
    if(window.__nordCancelledEl===btn && Date.now()<(window.__nordCancelUntil||0)){
      e.preventDefault();
      e.stopImmediatePropagation();
      return;
    }
    if(window.__nordTapEl!==btn || Date.now()>(window.__nordTapUntil||0)) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    rememberTap(btn);
    setTimeout(()=>{
      if(!btn.isConnected || btn.disabled) return;
      btn.dataset.nordReplay='1';
      try{btn.click();}catch(err){console.error('button replay failed',err)}
    },ACTION_DELAY);
  },true);
})();

})();
(function(){
  // ===== NORD V5: 100+ ITEMS / MAGIC / COMPANION RAID SUPPORT =====
  p.equipment = p.equipment || {weapon:null,shield:null,helmet:null,armor:null,boots:null,amulet:null,ring1:null,ring2:null};
  p.magicBook = Array.isArray(p.magicBook) ? p.magicBook : [];
  p.magicEquipped = p.magicEquipped || null;
  p.companions = Array.isArray(p.companions) ? p.companions : [];
  p.generatedItems = p.generatedItems || {};

  const V5_RARITY = {
    common:{name:'Обычная',color:'#d8d8d8',mul:1.00},
    uncommon:{name:'Необычная',color:'#6ddd7a',mul:1.14},
    rare:{name:'Редкая',color:'#5da9ff',mul:1.32},
    legendary:{name:'Легендарная',color:'#c37cff',mul:1.70},
    mythic:{name:'Мифическая',color:'#ffb45c',mul:2.20}
  };
  window.v5RarityLabel=function(d){
    const r=d&&d.rarity&&V5_RARITY[d.rarity];
    return r?`<span style="color:${r.color};font-weight:800">${r.name}</span>`:'<span>Обычная</span>';
  };

  const v5MaterialTier={
    'Железный':'common','Кожаный':'common','Охотничий':'common','Стальной':'uncommon','Северный':'uncommon',
    'Эльфийский':'rare','Орочий':'rare','Двемерский':'rare','Стеклянный':'legendary','Эбонитовый':'legendary','Даэдрический':'mythic','Драконорожденный':'mythic'
  };
  const v5Base={
    weapons:[
      ['меч','Меч',14],['боевой топор','Топор',16],['булава','Булава',13],['кинжал','Кинжал',10],['двуручный меч','Меч',22],['двуручный топор','Топор',24],['боевой молот','Булава',26],['лук','Лук',15],['арбалет','Лук',18],['боевой лук','Лук',20]
    ],
    armor:[
      ['щит','Щит',10],['шлем','Шлем',8],['броня','Броня',18],['сапоги','Сапоги',6],['перчатки','Перчатки',5]
    ]
  };
  const v5Materials=Object.keys(v5MaterialTier);
  const v5Qual={common:'',uncommon:'Боевой ',rare:'Закалённый ',legendary:'Древний ',mythic:'Легендарный '};
  // Generate a large, deterministic equipment catalogue (120+ unique entries).
  for(const mat of v5Materials){
    const rarity=v5MaterialTier[mat];
    const mul=V5_RARITY[rarity].mul;
    for(const [kind,slot,base] of v5Base.weapons){
      const name=`${mat} ${kind}`;
      if(itemDb[name]) continue;
      const d={price:Math.round((70+base*10)*mul),damage:Math.max(1,Math.round(base*mul)),type:'weapon',slot,rarity,rarityName:V5_RARITY[rarity].name};
      if(slot==='Лук') d.stBonus=Math.round(4*mul);
      if(slot==='Кинжал') d.dodge=Math.round(1*mul+1);
      if(rarity==='rare') d.critBonus=2;
      if(rarity==='legendary'){d.critBonus=4;d.penetration=3;}
      if(rarity==='mythic'){d.critBonus=6;d.penetration=6;d.damageBonus=4;}
      itemDb[name]=d;
    }
    for(const [kind,slot,base] of v5Base.armor){
      const name=`${mat} ${kind}`;
      if(itemDb[name]) continue;
      const d={price:Math.round((60+base*9)*mul),armor:Math.max(1,Math.round(base*mul)),type:'armor',slot,rarity,rarityName:V5_RARITY[rarity].name};
      if(slot==='Броня'){d.hpBonus=Math.round((rarity==='mythic'?30:rarity==='legendary'?22:rarity==='rare'?12:rarity==='uncommon'?7:4));d.stBonus=rarity==='mythic'?-2:rarity==='legendary'?-4:rarity==='rare'?-5:0;}
      if(slot==='Сапоги'){d.stBonus=Math.round((rarity==='mythic'?26:rarity==='legendary'?20:rarity==='rare'?14:rarity==='uncommon'?9:7));d.dodge=Math.round(rarity==='mythic'?5:rarity==='legendary'?4:rarity==='rare'?3:1);}
      if(slot==='Шлем') d.hpBonus=Math.round((rarity==='mythic'?24:rarity==='legendary'?16:rarity==='rare'?10:rarity==='uncommon'?6:3));
      if(slot==='Щит') d.blockChance=Math.round(rarity==='mythic'?8:rarity==='legendary'?6:rarity==='rare'?4:rarity==='uncommon'?2:1);
      if(slot==='Перчатки'){d.damageBonus=Math.round(rarity==='mythic'?5:rarity==='legendary'?3:rarity==='rare'?2:1);d.stBonus=2;}
      itemDb[name]=d;
    }
  }
  const v5Accessories=[
    ['Кольцо силы','ring',7,0,0,3],['Кольцо выносливости','ring',0,10,0,0],['Кольцо маны','ring',0,0,16,0],['Кольцо охотника','ring',3,4,0,2],['Кольцо тени','ring',2,8,0,1],
    ['Амулет воина','accessory',4,8,0,4],['Амулет мага','accessory',0,4,22,0],['Амулет стража','accessory',0,16,0,1],['Амулет охотника','accessory',4,8,0,2],['Талисман драконьего сердца','accessory',8,18,16,4],
    ['Печать двемеров','accessory',5,10,8,3],['Осколок древней короны','accessory',9,12,20,5],['Камень душ','accessory',0,5,28,0],['Руна ярости','accessory',12,0,0,7],['Руна защиты','accessory',0,20,0,2]
  ];
  const accRarity=['common','common','common','uncommon','uncommon','uncommon','rare','rare','rare','legendary','rare','legendary','rare','legendary','mythic'];
  v5Accessories.forEach((x,i)=>{const [name,type,dmg,hp,mp,st]=x;const r=accRarity[i];const mul=V5_RARITY[r].mul;itemDb[name]={price:Math.round(140*mul),type:type==='ring'?'accessory':'accessory',slot:type==='ring'?'ring':'amulet',rarity:r,rarityName:V5_RARITY[r].name,damageBonus:Math.round(dmg*mul),hpBonus:Math.round(hp*mul),mpBonus:Math.round(mp*mul),stBonus:Math.round(st*mul),critBonus:r==='mythic'?5:r==='legendary'?3:r==='rare'?1:0};});

  // Learnable magic: part of the collection is sold by mages/alchemists, the rest only in raids.
  const V5_SPELLS=[
    {id:'ice_spike',name:'Осколок льда',school:'Разрушение',cost:10,damage:24,kind:'buy',price:110,desc:'Быстрое ледяное заклинание.'},
    {id:'firebolt',name:'Огненная стрела',school:'Разрушение',cost:14,damage:34,kind:'buy',price:950,desc:'Уверенный огненный удар.'},
    {id:'frost_blast',name:'Морозный взрыв',school:'Разрушение',cost:20,damage:48,kind:'buy',price:1450,desc:'Сильный холодный взрыв.'},
    {id:'healing_light',name:'Свет восстановления',school:'Восстановление',cost:18,heal:40,kind:'buy',price:1200,desc:'Восстанавливает здоровье.'},
    {id:'oakflesh',name:'Дубовая плоть',school:'Изменение',cost:16,armor:14,kind:'buy',price:240,desc:'+14 защиты на один бой.'},
    {id:'chain_lightning',name:'Цепная молния',school:'Разрушение',cost:26,damage:62,kind:'raid',desc:'Редкое заклинание для глубин подземелий.'},
    {id:'vampiric_drain',name:'Вампирский мор',school:'Разрушение',cost:24,damage:46,heal:22,kind:'raid',desc:'Похищает жизнь врага.'},
    {id:'frost_prison',name:'Ледяная тюрьма',school:'Изменение',cost:28,damage:40,stun:1,kind:'raid',desc:'Есть шанс лишить врага следующего удара.'},
    {id:'soul_burn',name:'Пепел души',school:'Разрушение',cost:32,damage:78,kind:'raid',desc:'Очень мощный удар по нежити.'},
    {id:'dragon_breath',name:'Дыхание дракона',school:'Разрушение',cost:38,damage:96,kind:'raid',desc:'Крайне редкое заклинание.'},
    {id:'guardian_spirit',name:'Дух-хранитель',school:'Призыв',cost:22,armor:20,damage:18,kind:'raid',desc:'Создаёт защитного духа на бой.'},
    {id:'time_slow',name:'Замедление времени',school:'Иллюзия',cost:30,crit:18,damage:18,kind:'raid',desc:'Ускоряет героя и повышает шанс крита.'}
  ];
  const spellById=id=>V5_SPELLS.find(x=>x.id===id);
  function learnSpell(id){if(!p.magicBook.includes(id))p.magicBook.push(id);save();}
  function spellKnown(id){return p.magicBook.includes(id)}
  V5_SPELLS.filter(s=>s.kind==='buy').slice(0,2).forEach(s=>{if(!spellKnown(s.id)){} });

  // Add low-rarity city stock only. Rare+ items remain raid-only.
  const extraCityStock={
    'Вайтран':['Железный меч','Железный боевой топор','Железный щит','Кожаная броня','Железные сапоги','Кольцо силы','Охотничий лук'],
    'Ривервуд':['Охотничий лук','Железный кинжал','Кожаный лук','Кожаные сапоги','Кольцо выносливости'],
    'Рифтен':['Стальной кинжал','Стальной лук','Стальной шлем','Кожаная броня','Кольцо тени'],
    'Виндхельм':['Стальной меч','Стальной боевой топор','Стальной щит','Стальная броня','Стальные сапоги'],
    'Солитьюд':['Стальной меч','Стальная булава','Стальной щит','Стальной шлем','Амулет воина'],
    'Фолкрит':['Охотничий лук','Железная булава','Кожаная броня','Кожаные сапоги','Кольцо охотника'],
    'Морфал':['Железный кинжал','Стальной кинжал','Стальной щит','Стальные сапоги','Кольцо маны'],
    'Данстар':['Стальной боевой топор','Стальной меч','Стальной щит','Стальной шлем','Амулет стража']
  };
  Object.keys(extraCityStock).forEach(city=>{CITY_SHOP_STOCK[city]=Array.from(new Set([...(CITY_SHOP_STOCK[city]||[]),...extraCityStock[city]])).filter(n=>['common','uncommon',undefined].includes(itemDb[n]?.rarity));});

  // Make sure generated old saves keep their gear and books.
  function v5EnsureInventory(){
    p.inv=p.inv||[];p.equipment=p.equipment||{weapon:null,shield:null,helmet:null,armor:null,boots:null,amulet:null,ring1:null,ring2:null};
    if(!p.equipment.weapon && p.inv.some(x=>x[0]==='Железный меч')) p.equipment.weapon='Железный меч';
    if(!p.equipment.shield && p.inv.some(x=>x[0]==='Железный щит')) p.equipment.shield='Железный щит';
  }
  v5EnsureInventory();

  // Equipment slots above the backpack, with colored rarity names.
  window.renderInv = function(){
    v5EnsureInventory();
    const slots=[['weapon','⚔️ Оружие'],['shield','🛡️ Щит'],['helmet','⛑️ Шлем'],['armor','🧥 Броня'],['boots','🥾 Сапоги'],['amulet','💠 Амулет'],['ring1','💍 Кольцо 1'],['ring2','💍 Кольцо 2']];
    const eq=slots.map(([slot,label])=>{const item=p.equipment[slot];const d=item?(itemDb[item]||p.generatedItems?.[item]||{}):{};return `<div class="item" style="background:linear-gradient(90deg,#0c1a20,#091218);border-color:#4b5e5f"><span><b>${label}</b><small style="display:block;margin-top:4px">${item?esc(item):'<span class="muted">Пусто</span>'}${item?` • ${v5RarityLabel(d)}${d.damage?' • ⚔️ '+d.damage:''}${d.armor?' • 🛡️ '+d.armor:''}${d.hpBonus?' • ❤️ +'+d.hpBonus:''}${d.mpBonus?' • 🔷 +'+d.mpBonus:''}${d.stBonus?' • 🟢 '+(d.stBonus>0?'+':'')+d.stBonus:''}`:''}</small></span>${item?`<button class="btn small" onclick="unequipItem('${slot}')">Снять</button>`:'<span class="pill">—</span>'}</div>`}).join('');
    const rows=(p.inv||[]).map(x=>{const db=itemDb[x[0]]||p.generatedItems?.[x[0]]||{};const slot=['Меч','Топор','Булава','Кинжал','Лук'].includes(db.slot)?'weapon':db.slot==='Щит'?'shield':db.slot==='Шлем'?'helmet':db.slot==='Броня'?'armor':db.slot==='Сапоги'?'boots':db.slot==='Перчатки'?'amulet':db.type==='accessory'?(db.slot==='ring'?'ring1':'amulet'):null;return `<div class="item"><span><b>${esc(x[0])}</b><small style="display:block;margin-top:4px">${v5RarityLabel(db)}${db.damage?' • ⚔️ Урон '+db.damage:''}${db.armor?' • 🛡️ Броня '+db.armor:''}${db.hpBonus?' • ❤️ +'+db.hpBonus+' HP':''}${db.mpBonus?' • 🔷 +'+db.mpBonus+' маны':''}${db.stBonus?' • 🟢 '+(db.stBonus>0?'+':'')+db.stBonus+' выносл.':''}${db.damageBonus?' • ⚔️ +'+db.damageBonus+' атаки':''}</small></span><span style="display:flex;gap:6px;align-items:center"><span class="pill">×${x[1]}</span>${slot?`<button class="btn small cyan" onclick="equipItem('${encodeURIComponent(x[0])}','${slot}')">Экипировать</button>`:''}</span></div>`}).join('');
    main.innerHTML=`<section class="hero"><div class="title">🎒 ИНВЕНТАРЬ</div><div class="subtitle">Экипировка сначала • предметы ниже</div><div class="smallnote">Снаряжение напрямую меняет ⚔️ атаку, 🛡️ защиту, ❤️ здоровье, 🔷 ману и 🟢 выносливость.</div></section><section class="card" style="margin-top:12px"><h3 style="font-size:24px">⚔️ ЭКИПИРОВКА</h3>${eq}</section><section class="card" style="margin-top:12px"><h3>📦 ВЕЩИ И ДОБЫЧА</h3>${rows||'<div class="muted">Рюкзак пуст.</div>'}<div class="item"><span>💰 Золото</span><span class="pill">${p.gold}</span></div></section>`;
  };

  // Magic book / shopping / raid-cast UI.
  window.renderMagic=function(){
    const known=V5_SPELLS.filter(s=>spellKnown(s.id));
    const available=V5_SPELLS.filter(s=>s.kind==='buy'&&!spellKnown(s.id));
    const loot=V5_SPELLS.filter(s=>s.kind==='raid'&&!spellKnown(s.id));
    const knownRows=known.map(s=>`<div class="item"><span><b>${esc(s.name)}</b><small class="muted" style="display:block">${esc(s.school)} • ${s.cost} маны • ${s.damage?'⚔️ '+s.damage+' урона':''}${s.heal?' • ❤️ +'+s.heal:''}${s.armor?' • 🛡️ +'+s.armor:''}</small><small>${esc(s.desc)}</small></span><button class="btn small ${p.magicEquipped===s.id?'cyan':''}" onclick="p.magicEquipped='${s.id}';save();renderMagic()">${p.magicEquipped===s.id?'Выбрано':'Выбрать'}</button></div>`).join('');
    const buyRows=available.map(s=>`<div class="item"><span><b>${esc(s.name)}</b><small class="muted" style="display:block">${esc(s.school)} • ${s.cost} маны</small></span><button class="pill action-pill" onclick="buySpell('${s.id}')">Купить • ${s.price} 🪙</button></div>`).join('');
    const raidRows=loot.map(s=>`<div class="item"><span><b>${esc(s.name)}</b><small class="muted" style="display:block">Рейдовая магия • ${s.cost} маны</small></span><span class="pill">Только рейд</span></div>`).join('')||'<div class="muted">Все рейдовые заклинания уже найдены.</div>';
    main.innerHTML=`<section class="hero"><div class="title">🔮 МАГИЯ</div><div class="subtitle">КНИГА ЗАКЛИНАНИЙ • В БОЮ</div><div class="smallnote">Выбери заклинание — затем используй его прямо во время рейда.</div></section><section class="card" style="margin-top:12px"><h3>📖 Изученные</h3>${knownRows||'<div class="muted">Пока нет заклинаний. Первые можно купить у магов.</div>'}</section><section class="card" style="margin-top:12px"><h3>🛒 Купить</h3>${buyRows||'<div class="muted">Нечего изучать в магазинах.</div>'}</section><section class="card" style="margin-top:12px"><h3>⚔️ Найти в рейдах</h3>${raidRows}</section>`;
  };
  window.buySpell=function(id){const s=spellById(id);if(!s)return;if(p.gold<s.price){showToast('Недостаточно золота','Нужно '+s.price+' золота.','bad','💰',1800);return}p.gold-=s.price;learnSpell(id);showToast('Заклинание изучено',s.name,'good','🔮',1800);renderMagic()};

  function learnRaidSpell(){
    const candidates=V5_SPELLS.filter(s=>s.kind==='raid'&&!spellKnown(s.id));
    if(!candidates.length)return null;
    const s=candidates[Math.floor(Math.random()*candidates.length)];learnSpell(s.id);return s;
  }
  // Add spell drops to an otherwise-empty loot event, keeping economy stingy.
  const origRaidEventReward=window.raidEventReward;
  window.raidEventReward=function(chance=.28){
    if(Math.random()<Math.min(.04,chance*.12)){
      const s=learnRaidSpell(); if(s){return {item:`🔮 ${s.name}`,rarity:{icon:'✨',name:'Рейдовая магия'},spell:true};}
    }
    return origRaidEventReward(chance);
  };

  window.raidCastSpell=function(id){
    const a=p.activeRaid;if(!a)return;const s=spellById(id);if(!s||!spellKnown(id))return;
    if((p.mp||0)<s.cost){showToast('Недостаточно маны',`Нужно ${s.cost} маны.`,'warn','🔷',1600);return}
    p.mp-=s.cost;
    let dmg=Math.round(s.damage||0);
    let note=`🔮 ${s.name}: `;
    if(dmg){
      dmg+=Math.floor((p.skills?.['Магия разрушения']||0)*.18);
      a.enemyHp=Math.max(0,a.enemyHp-dmg);note+=`-${dmg} HP`;
    }
    if(s.heal){a.heroHp=Math.min(a.maxHp,a.heroHp+s.heal);note+=` • ❤️ +${s.heal}`;}
    if(s.armor){a.temporaryArmor=Number(a.temporaryArmor||0)+s.armor;note+=` • 🛡️ +${s.armor}`;}
    if(s.crit){a.magicCrit=(a.magicCrit||0)+s.crit;note+=` • ⚡ шанс крита +${s.crit}%`;}
    if(s.stun&&Math.random()<.45){a.enemySkip=true;note+=' • ❄️ враг оглушён';}
    raidLog(note);skill('Магия разрушения',2);
    if(a.enemyHp<=0){raidLog(a.stage===10?'👑 Магия уничтожила босса!':'☠️ Магия повергла врага!');if(a.stage===10)return raidFinish(true);a.stage++;a.enemy='';a.enemyHp=0;raidNextEvent();save();showRaidStage();return;}
    if(!a.enemySkip){let edmg=(a.stage===10?26:10)+Math.floor(Math.random()*(a.stage===10?18:12));edmg=Math.max(1,edmg-Math.floor((raidPlayerArmor()+Number(a.temporaryArmor||0))*.22));raidApplyDamage(edmg,`${a.enemy} отвечает`);}else{a.enemySkip=false;raidLog('❄️ Враг пропускает удар.')}
    if(a.heroHp<=0)return raidFinish(false);save();showRaidStage();
  };

  const origRenderRaidCombat=window.renderRaidCombat||renderRaidCombat;
  window.renderRaidCombat=function(a){
    let html=origRenderRaidCombat(a);
    const known=V5_SPELLS.filter(s=>spellKnown(s.id));
    if(!known.length)return html;
    const spellButtons=known.slice(0,4).map(s=>`<button type="button" class="raid-choice" style="min-height:64px" onclick="window.raidCastSpell('${s.id}')"><b>🔮 ${esc(s.name)}</b><small>${s.cost} маны • ${s.damage?'⚔️ '+s.damage+' урона':''}${s.heal?' • ❤️ '+s.heal:''}</small></button>`).join('');
    const idx=html.indexOf('</div><button type="button" class="raid-leave-btn"');
    if(idx>0) html=html.slice(0,idx)+`<div style="margin-top:10px"><div class="smallnote" style="margin-bottom:6px">🔮 МАГИЯ • Мана ${Math.max(0,p.mp||0)}/${heroMaxMp()}</div><div class="raid-event-choices">${spellButtons}</div></div>`+html.slice(idx);
    if((p.companions||[]).length){
      const cname=p.companions[0];const ally=v5CompanionStats(cname);const marker=`<div class="raid-hero-mini" style="margin-top:10px;border-color:#48635e"><div><b>🤝 ${esc(cname)}</b><small>Спутник • ⚔️ ${ally.attack} атаки • 🛡️ ${ally.defense} защиты</small></div><div class="raid-heart">❤️ ${ally.hp}</div></div>`;
      html=html.replace(/<div class="raid-actions">/,marker+'<div class="raid-actions">');
    }
    return html;
  };

  function v5CompanionStats(name){
    const defs={
      'Фаэндаль':{attack:22,defense:10,hp:85,crit:10},'Бриньольф':{attack:26,defense:11,hp:90,crit:12},'Лами':{attack:16,defense:8,hp:72,crit:6},'Кузнец Орит':{attack:24,defense:16,hp:105,crit:5}
    };
    const n=(p.knownPeople||[]).find(x=>x.name===name);const d=defs[name]||{attack:16,defense:9,hp:80,crit:6};const rel=Math.floor((n?.relation||60)/25);return {attack:d.attack+rel+Math.floor((p.level||1)*.8),defense:d.defense+Math.floor((p.level||1)*.5),hp:d.hp+Math.floor((p.level||1)*4),crit:d.crit};
  }
  window.v5CompanionStats=v5CompanionStats;

  // Companion gets a real strike during raid combat if alive and present.
  const oldRaidAction=window.raidAction;
  window.raidAction=function(type){
    const beforeEnemy=p.activeRaid?.enemyHp||0;
    oldRaidAction(type);
    const a=p.activeRaid;if(!a||a.heroHp<=0||a.enemyHp<=0)return;
    if((type==='attack'||type==='power')&&(p.companions||[]).length){
      const cname=p.companions[0];const ally=v5CompanionStats(cname);let dmg=ally.attack+Math.floor(Math.random()*7);if(Math.random()<ally.crit/100)dmg=Math.round(dmg*1.7);
      a.enemyHp=Math.max(0,a.enemyHp-dmg);raidLog(`🤝 ${cname} атакует: -${dmg} HP`);skill('Одноручное оружие',1);
      if(a.enemyHp<=0){raidLog(a.stage===10?'🤝 Спутник добил босса!':'🤝 Спутник поверг врага!');if(a.stage===10)return raidFinish(true);a.stage++;a.enemy='';a.enemyHp=0;raidNextEvent();save();showRaidStage();}
      else {save();showRaidStage();}
    }
  };

  // Companion screen — concise and explicit about raid support.
  window.renderCompanions=function(){
    const people=(p.knownPeople||[]).filter(n=>(p.companions||[]).includes(n.name));
    const rows=people.map(n=>{const a=v5CompanionStats(n.name);return `<div class="npc-card"><div style="display:flex;justify-content:space-between;gap:10px"><div><strong>🤝 ${esc(n.name)}</strong><div class="muted">${esc(n.role||'Спутник')} • Отношения ${n.relation||0}/100</div></div><span class="pill">Активен</span></div><div class="city-status" style="margin-top:8px"><div class="pillbox"><b>⚔️ ${a.attack}</b>Атака</div><div class="pillbox"><b>🛡️ ${a.defense}</b>Защита</div><div class="pillbox"><b>❤️ ${a.hp}</b>HP</div><div class="pillbox"><b>⚡ ${a.crit}%</b>Крит</div></div><div class="smallnote" style="margin-top:8px">В рейде атакует после твоего удара и может добить врага.</div></div>`}).join('')||'<div class="muted">Спутников пока нет. Познакомься с людьми, подружись и пригласи путешествовать вместе.</div>';
    main.innerHTML=`<section class="hero"><div class="title">🤝 СПУТНИКИ</div><div class="subtitle">ОТРЯД • ПОДЗЕМЕЛЬЯ • СОВМЕСТНЫЙ БОЙ</div></section><section class="card" style="margin-top:12px"><h3>Твой отряд</h3>${rows}</section><section class="card" style="margin-top:12px"><h3>Как это работает</h3><div class="muted">Спутник участвует в рейде, наносит отдельный удар, имеет собственные атаку, защиту и шанс крита.</div></section>`;
  };

  // Seed a couple of cheap spells for new characters with magic playstyles only.
  if(p.characterCreated && (p.combatStyle==='Магия' || (p.skills?.['Магия разрушения']||0)>=5) && !p.magicBook.length){p.magicBook.push('ice_spike');}
})();

document.addEventListener('click',function(e){
  const b=e.target.closest && e.target.closest('.raid-choice[data-raid-action]');
  if(!b)return;
  e.preventDefault();
  e.stopPropagation();
  if(typeof window.__nordRaidTap==='function')window.__nordRaidTap(b);
},false);

document.addEventListener('click',function(e){
  const menuBtn=e.target.closest('.main-menu-btn[data-menu-action]');
  if(menuBtn){
    // Inline handlers above are the primary path on Android WebView; this is a fallback only.
    e.preventDefault();
    e.stopPropagation();
    const action=menuBtn.dataset.menuAction;
    if(action==='new') return startNewGameFromMenu();
    if(action==='load') return loadGameFromMenu();
    if(action==='settings') return showScreen('settings');
    if(action==='about') return renderAboutGame();
    if(action==='exit') return confirmExitGame();
  }
},false);

document.addEventListener('click',function(e){const n=e.target.closest('.nav');if(n&&document.body.classList.contains('creating')){e.preventDefault();e.stopPropagation();return;}if(n&&n.dataset.screen){e.preventDefault();e.stopPropagation();showScreen(n.dataset.screen);}},true);
showScreen('mainmenu');

try{window.updateMusicForScreen('mainmenu');window.updateAmbientForScreen('mainmenu');}catch(e){}

