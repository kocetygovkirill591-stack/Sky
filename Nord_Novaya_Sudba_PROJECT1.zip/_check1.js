
(function(){
  var start=Date.now(), total=8200, timer=null, done=false;
  var screen=document.getElementById('bootScreen'), bar=document.getElementById('bootProgress'), pct=document.getElementById('bootPercent'), msg=document.getElementById('bootMessage'), scene=document.getElementById('bootScene');
  var scenes=['Северные горы','Ночной Скайрим','Туманный лес','Дорога на Вайтран'];
  var messages=['Мир просыпается...','Загружаются города и дороги...','Судьбы жителей переплетаются...','Гильдии готовят новые дела...','Жители выходят на улицы...','Последние приготовления...'];
  if(scene) scene.textContent=scenes[Math.floor(Math.random()*scenes.length)];
  var loadingAudio=null;
  try{ loadingAudio=new Audio('music/loading_nord.ogg'); loadingAudio.preload='auto'; loadingAudio.loop=true; loadingAudio.volume=.42; try{window.stopWorldAmbient&&window.stopWorldAmbient();}catch(e){} var ap=loadingAudio.play(); if(ap&&ap.catch)ap.catch(function(){}); window.__nordLoadingAudio=loadingAudio; }catch(e){}
  function finish(){
    if(done)return; done=true; if(timer)clearInterval(timer);
    if(bar)bar.style.width='100%'; if(pct)pct.textContent='100%'; if(msg)msg.textContent='Добро пожаловать в Скайрим';
    if(screen){screen.classList.add('ready');setTimeout(function(){screen.classList.add('hide');document.body.classList.remove('booting');setTimeout(function(){if(screen&&screen.parentNode)screen.parentNode.removeChild(screen);},950);},600);}
    try{if(window.__nordLoadingAudio){window.__nordLoadingAudio.pause();window.__nordLoadingAudio=null;}}catch(e){}
    try{if(window.updateMusicForScreen)window.updateMusicForScreen(window.p&&window.p.characterCreated?'world':'create');}catch(e){}
    // Never start world ambience while the loading screen is visible.
    try{if(window.stopWorldAmbient)window.stopWorldAmbient();}catch(e){}
    setTimeout(function(){
      try{if(window.updateAmbientForScreen && !document.body.classList.contains('booting')){window.updateAmbientForScreen(window.p&&window.p.characterCreated?'world':'create');}}catch(e){}
    },1000);
  }
  function tick(){var v=Math.min(100,Math.floor((Date.now()-start)/total*100));if(bar)bar.style.width=v+'%';if(pct)pct.textContent=v+'%';if(msg)msg.textContent=messages[Math.min(messages.length-1,Math.floor(v/18))];if(v>=100)finish();}
  tick(); timer=setInterval(tick,80); setTimeout(finish,8600);
})();
