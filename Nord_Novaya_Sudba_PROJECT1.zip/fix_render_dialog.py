from pathlib import Path
files=[Path('/mnt/data/work_nord')/n for n in ['game.js','main.js','index_script.js','script_1.js','_final_inline_1.js']]
new_render=r'''function renderDialog(){
 const n=p.dialogNpc||'Житель';const d=npcDb[n]||{role:'Житель',about:'Местный житель.',rumors:[],quests:[]};
 let person=(p.knownPeople||[]).find(v=>v.name===n);if(!person){person={name:n,relation:0,romance:0,friend:false,memory:[],metCount:1,city:p.loc};}ensureNpcMemory(person);
 const mem=(person.memory||[]).slice(-3).map(m=>`<div class="item"><span>🧠 ${esc(m.text)}</span><span class="pill">День ${m.day}</span></div>`).join('')||'<div class="muted">Пока ничего важного не запомнено.</div>';
 const q=(d.quests||[]).map(x=>`<div class="item"><span>📜 ${esc(x)}</span><button class="pill" onclick="npcQuest(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">Взять</button></div>`).join('')||'<div class="muted">У этого NPC сейчас нет обычных поручений.</div>';
 const rumors=(d.rumors||[]).slice(0,4).map(x=>`<div class="item"><span>👂 ${esc(x)}</span></div>`).join('')||'<div class="muted">Слухов пока нет.</div>';
 let actions=[`<button class="btn cyan" onclick="npcTalk(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">💬 Поговорить</button>`,`<button class="btn" onclick="npcRumor(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">👂 Спросить слухи</button>`];
 if((person.relation||0)>=20)actions.push(`<button class="btn" onclick="npcRelationshipAction(decodeURIComponent('${encodeURIComponent(n)}'),'walk');renderDialog()">🚶 Прогуляться вместе</button>`);
 if((person.relation||0)>=30)actions.push(`<button class="btn" onclick="npcRelationshipAction(decodeURIComponent('${encodeURIComponent(n)}'),'help');renderDialog()">🤝 Предложить помощь</button>`);
 if((person.relation||0)>=25)actions.push(`<button class="btn" onclick="npcRelationshipAction(decodeURIComponent('${encodeURIComponent(n)}'),'gift');renderDialog()">🎁 Сделать подарок • 20 золота</button>`);
 if(d.vendor)actions.push(`<button class="btn" onclick="tradeWithNpc(decodeURIComponent('${encodeURIComponent(n)}'))">🛒 Торговать</button>`);
 if(d.majorQuestGiver)actions.push(`<button class="btn blue" onclick="npcMajorQuest(decodeURIComponent('${encodeURIComponent(n)}'))">⚜️ Важное поручение правителя</button>`);
 actions.push(`<button class="btn" onclick="npcQuest(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">📜 Спросить о работе</button>`);
 actions.push(`<button class="btn red" onclick="p.dialogNpc=null;p.dialogMsg='';showScreen('world')">↩️ Попрощаться</button>`);
 main.innerHTML=`<section class="hero"><div class="title">РАЗГОВОР</div><div class="subtitle">${esc(n)} • ${esc(d.role||'Житель')}</div></section><section class="card" style="margin-top:12px"><div class="entity"><div class="npc-portrait"><div style="width:100%;height:100%;display:grid;place-items:center;font-size:44px">${d.leader?'⚜️':d.companion?'🤝':d.vendor?'🛒':'👤'}</div></div><div><h3 style="margin:0">${esc(n)}</h3><div class="muted">${esc(d.about||'')}</div>${d.vendor?'<span class="vendorTag" style="margin-top:6px">Торговец</span>':''}${d.majorQuestGiver?'<span class="vendorTag" style="margin-top:6px;margin-left:6px">Правитель</span>':''}</div></div><div class="tavern-statline" style="margin-top:10px"><span class="tavern-chip">🤝 Отношения ${person.relation||0}/100</span><span class="tavern-chip romance">❤️ Романтика ${person.romance||0}/100</span>${person.friend?'<span class="tavern-chip friend">🤝 Друг</span>':''}</div><div class="dialogBox notice" style="margin-top:12px">${esc(p.dialogMsg||npcDynamicLine(person))}</div><div class="dialog-actions" style="margin-top:12px">${actions.join('')}</div></section><section class="card" style="margin-top:12px"><h3>🧠 Память NPC</h3>${mem}</section><section class="card" style="margin-top:12px"><h3>👂 Слухи</h3>${rumors}</section><section class="card" style="margin-top:12px"><h3>📜 Обычные поручения</h3>${q}</section><button class="btn" style="margin-top:12px" onclick="showScreen('world')">↩️ Вернуться в город</button>`;
}
'''
for f in files:
    text=f.read_text(encoding='utf-8')
    a=text.find('function renderDialog(){')
    b=text.find('function showScreen(s){',a)
    if a<0 or b<0: raise RuntimeError(f'cannot find markers in {f}')
    text=text[:a]+new_render+text[b:]
    f.write_text(text,encoding='utf-8')
print('renderDialog replaced')
