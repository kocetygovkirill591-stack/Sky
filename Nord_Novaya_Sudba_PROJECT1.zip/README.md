# NORD — Новая судьба

Версия с загрузочным экраном и оригинальной северной музыкальной системой.

Музыка:
- 8-минутная тема загрузки;
- городская тема;
- таверна;
- путешествие/карта;
- бой;
- ночная тема.

Музыка переключается по ситуации и плавно затухает/входит. Оригинальные треки созданы для проекта и не используют музыку Skyrim.
## Audio update
- Loading progress bar uses explicit responsive width and stays centered on Android WebView.
- World ambience is one-shot per location/screen entry; it no longer loops underneath music.

## World Engine V1

This build adds the first persistent simulation layer for the open world. Time advancement now drives hourly NPC schedules, city security/economy/morale/activity, caravan movement, world news, and city-wide random events. State is saved inside the existing local save under `worldEngine` so current saves can migrate without starting over.

Test this stage before adding the next world-system layer.

## Audio settings
- Music and world sounds have independent on/off toggles in Settings.
- Location ambience plays once on entering a screen and hard-stops after a short clip; it never loops underneath background music.


Audio update: unique one-shot Tavern/Market/Arena ambience and visual button press feedback added.

## Button press feedback V3
- City actions and all standard menu buttons use the same neutral base style.
- Highlight appears only on a real press.
- Pointer movement over 6px cancels the highlight immediately, so vertical scrolling no longer looks like pressing buttons.
- Navigation/selection state remains separate from transient press feedback.
