# NORD — Новая судьба

Версия с загрузочным экраном и оригинальной северной музыкальной системой.

Музыка:
- 8-минутная тема загрузки;
- городская тема;
- таверна;
- путешествие/карта;
- бой;
- ночная тема.

Музыка переключается по ситуации и плавно затухает/входит. Оригинальные треки созданы для проекта и не используют музыку Skyrim.
## Audio update
- Loading progress bar uses explicit responsive width and stays centered on Android WebView.
- World ambience is one-shot per location/screen entry; it no longer loops underneath music.
