
const KEY='nord_rpg_save_v5';
const OLD_KEY='nord_rpg_save_v2';
const races=['Норд','Имперец','Эльф','Орк','Каджит'];
const heroPortraits={
  'Норд':['nord_1','nord_2','nord_3'],
  'Имперец':['imperial_1','imperial_2','imperial_3'],
  'Эльф':['elf_1','elf_2','elf_3'],
  'Орк':['orc_1','orc_2','orc_3'],
  'Каджит':['khajiit_1','khajiit_2','khajiit_3']
};
const attrDefs=[['Сила','💪'],['Ловкость','🏹'],['Выносливость','❤️'],['Интеллект','📖'],['Воля','🔷'],['Харизма','💛']];
const raceBonuses={'Норд':{Сила:2,Выносливость:1},'Имперец':{Харизма:2,Воля:1},'Эльф':{Интеллект:2,Ловкость:1},'Орк':{Сила:2,Выносливость:1},'Каджит':{Ловкость:2,Харизма:1}};
const originOptions={
'Северные земли':{icon:'🏔️',desc:'Суровый край. Знаешь холод и северные дороги.',bonus:{Выносливость:1},skills:{'Одноручное оружие':2}},
'Город':{icon:'🏙️',desc:'Вырос среди торговцев, стражи и городской жизни.',bonus:{Харизма:1},skills:{'Красноречие':3}},
'Лесная деревня':{icon:'🌲',desc:'Охота, следопытство и жизнь рядом с природой.',bonus:{Ловкость:1},skills:{'Стрельба':3}},
'Шахтёрское поселение':{icon:'⛏️',desc:'С детства знаешь руду, камень и тяжёлый труд.',bonus:{Сила:1},skills:{'Алхимия':1,'Тяжёлая броня':2}},
'Дворянский дом':{icon:'🏰',desc:'Обучение манерам, истории и придворным правилам.',bonus:{Харизма:1,Интеллект:1},skills:{'Красноречие':2}},
'Военный лагерь':{icon:'⚔️',desc:'Жизнь среди солдат научила дисциплине и строю.',bonus:{Воля:1},skills:{'Блокирование':2,'Одноручное оружие':1}}
};
const pastOptions={
'Воин':{icon:'🛡️',desc:'Бывший солдат. Знаешь цену дисциплине.',skills:{'Одноручное оружие':5,'Блокирование':3}},
'Охотник':{icon:'🐾',desc:'Следопыт и охотник, привыкший выживать в лесу.',skills:{'Стрельба':6,'Скрытность':2}},
'Ученик мага':{icon:'📜',desc:'Учился у наставника, но ещё не раскрыл весь потенциал.',skills:{'Магия разрушения':6}},
'Вор':{icon:'🗝️',desc:'Знаешь замки, карманы и тёмные улицы.',skills:{'Взлом':4,'Скрытность':4}},
'Кузнец':{icon:'🔨',desc:'Работа с металлом научила терпению и силе.',skills:{'Тяжёлая броня':3,'Алхимия':3}},
'Купец':{icon:'💰',desc:'Знаешь цены, людей и силу хорошей сделки.',skills:{'Красноречие':6}},
'Бродяга':{icon:'🧳',desc:'Странствовал по северным дорогам и выживал как мог.',skills:{'Скрытность':2,'Красноречие':2,'Стрельба':2}}
};
const personalityOptions={'Воин':{icon:'⚔️',desc:'Прямолинейный и смелый.',bonus:{Сила:1}},'Мудрец':{icon:'🦉',desc:'Спокойный и наблюдательный.',bonus:{Интеллект:1}},'Изгой':{icon:'🌑',desc:'Привык полагаться только на себя.',bonus:{Воля:1}},'Добрый':{icon:'🤝',desc:'Легче завоёвывает доверие.',bonus:{Харизма:1}},'Хитрый':{icon:'🐍',desc:'Любит обходные пути.',bonus:{Ловкость:1}},'Честь':{icon:'🛡️',desc:'Слово важнее золота.',bonus:{Воля:1}}};
const signs={'Воин':{icon:'⚔️',desc:'Сила и стойкость.',bonus:{Выносливость:2}},'Маг':{icon:'🔮',desc:'Чутьё к магии.',bonus:{Интеллект:2}},'Вор':{icon:'🗝️',desc:'Тень и ловкость.',bonus:{Ловкость:2}},'Любовник':{icon:'❤️',desc:'Легче находишь общий язык.',bonus:{Харизма:2}},'Тень':{icon:'🌑',desc:'Лучше действуешь незаметно.',bonus:{Ловкость:1,Воля:1}},'Лорд':{icon:'👑',desc:'Влияние и уверенность.',bonus:{Харизма:1,Воля:1}},'Конь':{icon:'🐎',desc:'Выносливость в путешествиях.',bonus:{Выносливость:2}}};
const talents={'Крепкое тело':{icon:'❤️',desc:'+10% к максимальному здоровью.'},'Быстрый ум':{icon:'🧠',desc:'+10% к получаемому опыту.'},'Тихая тень':{icon:'🌑',desc:'+10% к скрытности.'},'Меткий глаз':{icon:'🎯',desc:'+10% к урону луком.'},'Прирождённый лидер':{icon:'👑',desc:'Лучшие отношения с союзниками и торговцами.'}};
const weaknesses={'Боязнь нежити':{icon:'💀',desc:'Урон от нежити +8%.',bonus:'При первом повышении уровня получаешь +1 очко развития.'},'Слабая магия':{icon:'🔮',desc:'Максимум магии -10.',bonus:'+2 к Силе на старте.'},'Плохая выносливость':{icon:'🟢',desc:'Расход выносливости +10%.',bonus:'+2 к Интеллекту на старте.'},'Алчность':{icon:'💰',desc:'Честные решения дают меньше репутации.',bonus:'+10% найденного золота.'},'Вспыльчивость':{icon:'🔥',desc:'Некоторые диалоги могут привести к драке.',bonus:'Сильная атака +5% урона.'},'Низкое красноречие':{icon:'🗣️',desc:'Труднее убеждать людей.',bonus:'+2 к Одноручному оружию.'}};
const combatStyles={'Меч и щит':{icon:'🛡️',desc:'Надёжная защита.',skills:{'Одноручное оружие':3,'Блокирование':3},gear:[['Железный меч',1],['Железный щит',1]]},'Два оружия':{icon:'⚔️',desc:'Быстрые агрессивные атаки.',skills:{'Одноручное оружие':6},gear:[['Железный кинжал',2]]},'Лук':{icon:'🏹',desc:'Дистанционный бой.',skills:{'Стрельба':6},gear:[['Железный кинжал',1]]},'Магия':{icon:'🔮',desc:'Удар из магической школы.',skills:{'Магия разрушения':6},gear:[['Свиток магии',1]]},'Двуручное':{icon:'🪓',desc:'Мощные удары ценой скорости.',skills:{'Двуручное оружие':6},gear:[['Древнее оружие',1]]},'Скрытность':{icon:'🥷',desc:'Избегай боя и бей неожиданно.',skills:{'Скрытность':5,'Взлом':2},gear:[['Железный кинжал',1]]}};
const alignments={'Законопослушный':{icon:'⚖️',desc:'Порядок и закон.'},'Нейтральный':{icon:'🧭',desc:'Сам решаешь, что правильно.'},'Авантюрист':{icon:'☠️',desc:'Риск ради свободы и богатства.'},'Преступник':{icon:'🩸',desc:'Правила существуют для других.'}};
const cityNames=['Вайтран','Ривервуд','Рифтен','Виндхельм','Солитьюд','Фолкрит','Морфал','Данстар','Айварстед','Рорикстед','Хелген','Драконий мост','Картвастен','Шорс-Стон','Каменные холмы','Торговый тракт','Ледяной берег','Черный перевал','Высокий Хротгар','Заброшенный форт','Снежная пещера','Старые руины','Туманный лес','Озеро Хьялмарк','Красный перевал','Долина охотников'];
const world={
'Вайтран':{type:'Город',desc:'Главный торговый город равнин. Рынок, дворец ярла, таверны и кузницы.',exits:['Ривервуд','Рифтен','Фолкрит','Рорикстед'],npcs:['Ярл Балгруф','Кузнец Адрианна','Караванщик Лод'],enemy:'Бандит',quests:['Защита торгового каравана','Кража из склада'],house:500},
'Ривервуд':{type:'Деревня',desc:'Деревня у реки. Здесь можно купить припасы и услышать слухи о руинах.',exits:['Вайтран','Хелген','Туманный лес'],npcs:['Гердур','Ортор','Фаэндаль'],enemy:'Волк',quests:['Пропавшая охотница'],house:350},
'Рифтен':{type:'Город',desc:'Город каналов и торговцев. Здесь сильны воры и подпольные сделки.',exits:['Вайтран','Фолкрит','Красный перевал'],npcs:['Бриньольф','Мариса','Торговец Мадези'],enemy:'Бандит',quests:['Долг торговца','Тайный заказ'],house:700},
'Виндхельм':{type:'Город',desc:'Древний северный город у ледяного моря. Здесь процветают кузницы.',exits:['Данстар','Вайтран','Ледяной берег'],npcs:['Вунферт','Кузнец Орит','Капитан стражи'],enemy:'Бандит',quests:['Караван в снегах'],house:650},
'Солитьюд':{type:'Город',desc:'Столичный город с дворцами, гильдиями и богатыми торговцами.',exits:['Драконий мост','Морфал','Озеро Хьялмарк'],npcs:['Тит Медиус','Фальк Огненный Борода','Сейда'],enemy:'Наемник',quests:['Письмо ярлу','Защита порта'],house:1000},
'Фолкрит':{type:'Город',desc:'Лесной город. Охотники, лесорубы и следопыты знают эти земли лучше всех.',exits:['Рифтен','Вайтран','Туманный лес'],npcs:['Нари','Денгейр','Охотник Сонд'],enemy:'Волк',quests:['След зверя','Охрана тракта'],house:450},
'Морфал':{type:'Город',desc:'Туманный болотный край. Алхимики собирают здесь редкие растения.',exits:['Солитьюд','Озеро Хьялмарк','Данстар'],npcs:['Лейла','Алхимик Лами','Мастер болот'],enemy:'Ведьма',quests:['Травы болот'],house:550},
'Данстар':{type:'Город',desc:'Снежный портовый город. Мороз здесь не отпускает даже летом.',exits:['Виндхельм','Морфал','Ледяной берег'],npcs:['Скалд','Капитан Хальд','Торговец Редди'],enemy:'Скелет',quests:['Ледяная шахта'],house:500},
'Aйварстед':{type:'Деревня',desc:'Поселение у подножия Высокого Хротгара.',exits:['Вайтран','Высокий Хротгар'],npcs:['Климмек','Жена лесника'],enemy:'Волк',quests:['Письмо монахам'],house:300},
'Рорикстед':{type:'Деревня',desc:'Маленькая фермерская деревня посреди равнин.',exits:['Вайтран','Драконий мост'],npcs:['Рорик','Юрга'],enemy:'Бандит',quests:['Пропавший урожай'],house:300},
'Хелген':{type:'Руины',desc:'Пограничный город после великой катастрофы. Вокруг много разбойников.',exits:['Ривервуд','Заброшенный форт'],npcs:['Выживший солдат','Бродячий торговец'],enemy:'Разбойник',quests:['Очистить руины'],house:250},
'Драконий мост':{type:'Поселение',desc:'Мост между северными дорогами. Здесь встречаются торговцы и наемники.',exits:['Солитьюд','Рорикстед','Картвастен'],npcs:['Хозяйка трактира','Старый ветеран'],enemy:'Наемник',quests:['Охрана моста'],house:400},
'Картвастен':{type:'Шахтерский поселок',desc:'Горный поселок с рудниками и суровыми шахтерами.',exits:['Драконий мост','Каменные холмы'],npcs:['Кузнец Ральф','Шахтер Эйнар'],enemy:'Паукообразный жук',quests:['Руда для кузницы'],house:380},
'Шорс-Стон':{type:'Поселок',desc:'Оловянные шахты и кузницы. Торговцы любят это место за руду.',exits:['Рифтен','Красный перевал'],npcs:['Шахтер Халдин','Скупщик руды'],enemy:'Паукообразный жук',quests:['Пропавшая руда'],house:420},
'Каменные холмы':{type:'Дикая местность',desc:'Каменистая долина с редкими стоянками и древними курганами.',exits:['Картвастен','Шорс-Стон','Старые руины'],npcs:['Охотник-отшельник'],enemy:'Скелет',quests:['Кости в кургане'],house:0},
'Торговый тракт':{type:'Дорога',desc:'Главный путь караванов между городами.',exits:['Вайтран','Рифтен','Солитьюд'],npcs:['Купец Алдар','Наемная охрана'],enemy:'Бандит',quests:['Пропавший обоз'],house:0},
'Ледяной берег':{type:'Побережье',desc:'Ледяной берег с обломками кораблей и пиратскими тайниками.',exits:['Виндхельм','Данстар','Черный перевал'],npcs:['Пират-перебежчик'],enemy:'Пират',quests:['Карта затонувшего корабля'],house:0},
'Черный перевал':{type:'Дикая местность',desc:'Мрачный перевал. Дорога опасна ночью.',exits:['Ледяной берег','Красный перевал'],npcs:['Следопыт'],enemy:'Разбойник',quests:['Ночной патруль'],house:0},
'Высокий Хротгар':{type:'Святилище',desc:'Древний монастырь в горах. Здесь изучают голос и древние искусства.',exits:['Айварстед','Старые руины'],npcs:['Учитель Голоса','Паломник'],enemy:'Драугр',quests:['Испытание голоса'],house:0},
'Заброшенный форт':{type:'Руины',desc:'Старый военный форт, занятый преступниками.',exits:['Хелген','Туманный лес','Черный перевал'],npcs:['Заключенный','Контрабандист'],enemy:'Разбойник',quests:['Очистить форт'],house:0},
'Снежная пещера':{type:'Пещера',desc:'Лабиринт под снегом. Здесь слышен вой и стук костей.',exits:['Снежный тракт'],npcs:['Пленник'],enemy:'Драугр',quests:['Знак из глубины'],house:0},
'Старые руины':{type:'Руины',desc:'Древний комплекс с тайными дверьми, ловушками и магическими залами.',exits:['Каменные холмы','Высокий Хротгар','Заброшенный форт'],npcs:['Исследователь'],enemy:'Драугр',quests:['Сердце руин'],house:0},
'Туманный лес':{type:'Лес',desc:'Лес с туманом, редкими кострами и скрытыми тропами.',exits:['Ривервуд','Фолкрит','Заброшенный форт'],npcs:['Следопытка Элия'],enemy:'Лесной призрак',quests:['Охота в тумане'],house:0},
'Озеро Хьялмарк':{type:'Болото',desc:'Большое озеро и болота с редкими травами и тайными хижинами.',exits:['Морфал','Солитьюд'],npcs:['Алхимик','Рыбак'],enemy:'Ведьма',quests:['Черный лотос'],house:0},
'Красный перевал':{type:'Перевал',desc:'Красные скалы и опасные тропы между восточными дорогами.',exits:['Рифтен','Шорс-Стон','Черный перевал'],npcs:['Караванщик'],enemy:'Наемник',quests:['Защита каравана'],house:0},
'Долина охотников':{type:'Дикая местность',desc:'Скрытая долина с богатыми охотничьими угодьями.',exits:['Фолкрит','Каменные холмы'],npcs:['Охотник Бран'],enemy:'Медведь',quests:['Большая добыча'],house:0}
};
// Fallback alias for accidental Cyrillic typo key
world['Айварстед']=world['Aйварстед']; delete world['Aйварстед'];
const enemyDb={
'Бандит':{image:'bandit',lvl:2,hp:55,icon:'🗡️',desc:'Обычный разбойник с железным оружием.',skills:['Удар','Слабый блок'],loot:[['Золото',25],['Железный кинжал',0.45]]},
'Разбойник':{image:'bandit',lvl:3,hp:68,icon:'🏴',desc:'Опытный преступник, который умеет использовать грязные приемы.',skills:['Удар','Кровотечение'],loot:[['Золото',35],['Зелье лечения',0.35]]},
'Волк':{image:'wolf',lvl:2,hp:42,icon:'🐺',desc:'Дикий волк, быстрый и опасный в первом раунде.',skills:['Укус','Рывок'],loot:[['Золото',8],['Шкура волка',0.7]]},
'Скелет':{image:'skeleton',lvl:4,hp:72,icon:'💀',desc:'Неупокоенный воин, устойчивый к страху.',skills:['Рубящий удар','Костяной щит'],loot:[['Золото',30],['Старый кость-клинок',0.3]]},
'Драугр':{image:'skeleton',lvl:6,hp:105,icon:'🧟',desc:'Древний северный воин из кургана.',skills:['Тяжёлый удар','Боевой крик'],loot:[['Золото',60],['Древнее оружие',0.35]]},
'Ведьма':{image:'cultist',lvl:7,hp:88,icon:'🧙',desc:'Темная заклинательница болот.',skills:['Ледяной осколок','Проклятие'],loot:[['Золото',70],['Свиток магии',0.45]]},
'Наемник':{image:'knight',lvl:5,hp:82,icon:'🛡️',desc:'Бывший солдат, продающий свой меч.',skills:['Удар','Блок','Контратака'],loot:[['Золото',55],['Железный шлем',0.4]]},
'Пират':{image:'bandit',lvl:5,hp:76,icon:'⚓',desc:'Грабитель морских путей.',skills:['Кинжал','Грязный удар'],loot:[['Золото',65],['Янтарь',0.4]]},
'Паукообразный жук':{image:'goblin',lvl:3,hp:48,icon:'🕷️',desc:'Ядовитое шахтное создание.',skills:['Укус','Яд'],loot:[['Золото',12],['Ядовитый мешок',0.5]]},
'Лесной призрак':{image:'cultist',lvl:8,hp:95,icon:'👻',desc:'Бесплотный дух, которому почти не нужен воздух.',skills:['Туман','Проклятие'],loot:[['Золото',80],['Эктоплазма',0.7]]},
'Медведь':{image:'wolf',lvl:4,hp:90,icon:'🐻',desc:'Большой бурый зверь.',skills:['Рывок','Размах'],loot:[['Золото',18],['Шкура медведя',0.75]]}
};
const guilds=[
{id:'companions',name:'Соратники',icon:'⚔️',desc:'Воинская гильдия. Испытания, тренировки и охота на чудовищ.',trial:'Победи в испытательном поединке и докажи, что умеешь сражаться.',mission:'Охота на опасного зверя'},
{id:'mages',name:'Коллегия магов',icon:'🔮',desc:'Изучение школ магии и древних заклинаний.',trial:'Покажи контроль над магией и выбери верные заклинания.',mission:'Исследовать магический источник'},
{id:'thieves',name:'Гильдия воров',icon:'🗝️',desc:'Кражи, взломы, тайные сделки и черный рынок.',trial:'Пройди испытание на скрытность, ловкость и взлом.',mission:'Добыть редкий товар без тревоги'},
{id:'dark',name:'Тёмное братство',icon:'☠️',desc:'Опасная сеть наемных убийц.',trial:'Докажи хладнокровие и умение работать в тени.',mission:'Тайный ночной заказ'},
{id:'guards',name:'Стража',icon:'🛡️',desc:'Порядок, патрули и охота на преступников.',trial:'Докажи знание закона и умение защищать граждан.',mission:'Патруль и задержание преступника'}
];
const guildTrials={
companions:{questions:[['Что важнее перед поединком?',['Подготовка и выдержка','Бежать от противника','Выбросить оружие'],0],['Противник поднял щит. Что делать?',['Бездумно бить в щит','Сменить тактику и выждать момент','Сдаться'],1],['Твой союзник ранен.',['Бросить его','Помочь и прикрыть','Забрать его оружие'],1]]},
mages:{questions:[['Как экономить магию в долгом походе?',['Заклинать без остановки','Использовать подходящее заклинание по ситуации','Никогда не использовать магию'],1],['Что относится к разрушению?',['Лечащее заклинание','Огненный разряд','Открытие замка'],1],['У тебя мало магии в бою.',['Игнорировать запас','Использовать экономные заклинания и восстановление','Тратить всё сразу'],1]]},
thieves:{questions:[['Стража близко.',['Бежать по главной улице','Спрятаться и переждать','Кричать о краже'],1],['Дверь заперта.',['Взломать тихо','Выбить дверь','Позвать стражу'],0],['Товар лучше взять без шума.',['Создать переполох','Осторожно украсть и скрыться','Спросить у всех вокруг'],1]]},
dark:{questions:[['Цель одна и охрана рядом.',['Поднять шум','Наблюдать и выбрать безопасный момент','Идти напролом'],1],['Лучшее оружие убийцы?',['Терпение и тень','Громкий колокол','Факел в обеих руках'],0],['После заказа важно…',['Оставить следы','Исчезнуть и не привлекать внимание','Рассказать всем'],1]]},
guards:{questions:[['Что делать с нарушителем, который сдался?',['Наказать без суда','Задержать по закону','Отпустить за взятку'],1],['Гражданин просит помощи.',['Проигнорировать','Уточнить угрозу и защитить его','Взять золото'],1],['Стража должна прежде всего…',['Поддерживать порядок','Собирать налоги для себя','Избегать проблем'],0]]}
};
const guildRanks={
companions:['Новобранец','Рекрут','Воин','Щитоносец','Хранитель Соратников'],
mages:['Ученик','Адепт','Эксперт','Мастер','Архимаг'],
thieves:['Новичок','Подмастерье','Опытный вор','Теневой мастер','Мастер гильдии'],
dark:['Посвящённый','Нож','Клинок','Тень','Слушатель'],
guards:['Новобранец','Стражник','Старший стражник','Капитан','Командир стражи']
};
const guildUnlocks={
companions:['Доступ в казарму и тренировкам','Тренер: +2 к боевым навыкам','Можно нанимать боевых спутников','Право выдавать приказы в гильдии','Доступ к рангу Хранителя и уникальному оружию'],
mages:['Доступ к залам Коллегии','Тренировка магии со скидкой','Доступ к редким заклинаниям','Доступ к зачарованию и магическим артефактам','Право мастера Коллегии и уникальные заклинания'],
thieves:['Доступ к тайным контактам','Скидка у воров и рост взлома','Доступ к скупщикам и черному рынку','Можно снижать розыск через контакты','Право мастера и секретное убежище'],
dark:['Доступ к скрытым заданиям','Зелья и яды по сниженной цене','Доступ к уникальным контрактам','Скрытое убежище и специальные награды','Право Слушателя и элитные контракты'],
guards:['Доступ к казармам','Скидки на экипировку стражи','Право вести патрули','Снижение розыска и влияние на штрафы','Право Командира и особые полномочия']
};
const npcDb={
'Ярл Балгруф':{role:'Ярл',about:'Правитель Вайтрана.',quests:['Защита торгового каравана','Странные огни у башни'],rumors:['Вокруг Вайтрана замечены драконы.','Стража ищет пропавший караван.']},
'Бриньольф':{role:'Вор',about:'Связной подполья Рифтена.',quests:['Тайный заказ','Долг торговца'],rumors:['Внизу под рынком идет тайная торговля.','В Рифтене кто-то скупает редкие зелья.']},
'Фаэндаль':{role:'Лучник',about:'Может стать спутником.',companion:true,quests:['Пропавший следопыт'],rumors:['В лесу появился крупный медведь.']},
'Кузнец Адрианна':{role:'Кузнец',about:'Продает оружие, броню и ремонтирует снаряжение.',vendor:true,stock:['Железный меч','Железный щит','Железный кинжал','Железный шлем'],rumors:['Вчера привезли партию железной руды.']},
'Алхимик Лами':{role:'Алхимик',about:'Составляет зелья из редких трав.',vendor:true,stock:['Зелье лечения','Свиток магии'],rumors:['На болотах цветет редкий черный лотос.'],quests:['Травы болот']},
'Торговец Мадези':{role:'Торговец',about:'Покупает добычу и продает полезные вещи.',vendor:true,stock:['Зелье лечения','Свиток магии','Железный кинжал','Янтарь'],rumors:['К югу идет большой караван.']},
'Караванщик Лод':{role:'Караванщик',about:'Возит товары между городами.',vendor:true,stock:['Зелье лечения','Железный меч','Янтарь'],rumors:['На дороге орудуют бандиты.'],quests:['Защита торгового каравана']},
'Гердур':{role:'Житель',about:'Знает новости Ривервуда.',rumors:['В старых руинах слышали стук костей.'],quests:['Пропавшая охотница']},
'Ортор':{role:'Лесоруб',about:'Работает у реки.',rumors:['Следы волков ведут к северному лесу.']},
'Вунферт':{role:'Придворный маг',about:'Исследует древнюю магию.',rumors:['В курганах пробуждаются мертвые.'],quests:['Свиток из кургана']},
'Кузнец Орит':{role:'Кузнец',about:'Кует северное оружие.',vendor:true,stock:['Железный меч','Железный щит','Железный шлем'],rumors:['Нужна новая руда из шахты.']},
'Капитан стражи':{role:'Стражник',about:'Следит за порядком в городе.',rumors:['За некоторыми путниками давно следят.'],quests:['Ночной патруль']},
'Алхимик':{role:'Алхимик',about:'Скупает травы и ингредиенты.',vendor:true,stock:['Зелье лечения','Свиток магии'],rumors:['В болоте есть редкие растения.']},
'Рыбак':{role:'Рыбак',about:'Живет у воды.',rumors:['На берегу видели свет ночью.']},
'Учитель Голоса':{role:'Учитель',about:'Знает древние техники дыхания.',rumors:['Голос может изменить исход боя.'],quests:['Испытание голоса']}};
const itemDb={
'Железный меч':{price:60,damage:12,type:'weapon'},'Железный щит':{price:45,armor:10,type:'armor'},'Железный кинжал':{price:35,damage:8,type:'weapon'},'Железный шлем':{price:55,armor:8,type:'armor'},'Зелье лечения':{price:30,heal:45,type:'potion'},'Янтарь':{price:80,type:'loot'},'Эктоплазма':{price:65,type:'loot'},'Шкура волка':{price:25,type:'loot'},'Шкура медведя':{price:45,type:'loot'},'Ядовитый мешок':{price:40,type:'loot'},'Свиток магии':{price:90,type:'magic'},'Древнее оружие':{price:140,damage:18,type:'weapon'},'Старый кость-клинок':{price:70,damage:14,type:'weapon'}};
const skillTrees={
'⚔️ Воин':[
{id:'onehand',name:'Мастер клинка',desc:'+8% урона одноручным оружием',req:0,cost:1,skill:'Одноручное оружие'},
{id:'blockmaster',name:'Железный щит',desc:'+10% эффективности блока',req:1,cost:1,skill:'Блокирование'},
{id:'heavy',name:'Тяжёлая поступь',desc:'+10 максимальной выносливости',req:2,cost:1,skill:'Тяжёлая броня'},
{id:'berserk',name:'Ярость воина',desc:'Сильная атака наносит ещё +15% урона',req:3,cost:2,skill:'Одноручное оружие'}],
'🔮 Маг':[
{id:'spark',name:'Искра',desc:'Заклинания наносят +8% урона',req:0,cost:1,skill:'Магия разрушения'},
{id:'mana',name:'Поток маны',desc:'+10 максимальной магии',req:1,cost:1,skill:'Магия разрушения'},
{id:'focus',name:'Магический фокус',desc:'Заклинания стоят на 2 маны меньше',req:2,cost:1,skill:'Магия разрушения'},
{id:'archmage',name:'Архимаг',desc:'Открывает сильное заклинание',req:3,cost:2,skill:'Магия разрушения'}],
'🗝️ Вор':[
{id:'shadow',name:'Тихий шаг',desc:'+10% к скрытности',req:0,cost:1,skill:'Скрытность'},
{id:'lock',name:'Умелые пальцы',desc:'+10% к взлому',req:1,cost:1,skill:'Взлом'},
{id:'speech',name:'Серебряный язык',desc:'Торговля выгоднее на 8%',req:2,cost:1,skill:'Красноречие'},
{id:'assassin',name:'Удар из тени',desc:'Первая атака из засады наносит двойной урон',req:3,cost:2,skill:'Скрытность'}],
'🏹 Охотник':[
{id:'aim',name:'Меткий глаз',desc:'+10% урона луком',req:0,cost:1,skill:'Стрельба'},
{id:'tracker',name:'Следопыт',desc:'Чаще находишь добычу и случайные события',req:1,cost:1,skill:'Стрельба'},
{id:'hunter',name:'Охотник',desc:'+15% награды за животных',req:2,cost:1,skill:'Стрельба'},
{id:'deadeye',name:'Смертельный выстрел',desc:'Шанс критического выстрела 20%',req:3,cost:2,skill:'Стрельба'}],
'🔨 Ремесло':[
{id:'smith',name:'Кузнец',desc:'Открывает улучшение оружия',req:0,cost:1,skill:'Алхимия'},
{id:'alch',name:'Зельевар',desc:'Зелья восстанавливают на 25% больше',req:1,cost:1,skill:'Алхимия'},
{id:'enchant',name:'Зачарователь',desc:'Открывает магические улучшения предметов',req:2,cost:1,skill:'Алхимия'},
{id:'mastercraft',name:'Мастер ремесла',desc:'Продажа созданных предметов приносит больше золота',req:3,cost:2,skill:'Алхимия'}],
'🌲 Выживание':[
{id:'survive',name:'Живучесть',desc:'+15 максимального здоровья',req:0,cost:1,skill:'Тяжёлая броня'},
{id:'camp',name:'Лагерь',desc:'Отдых вне города восстанавливает силы',req:1,cost:1,skill:'Скрытность'},
{id:'herbs',name:'Травник',desc:'Чаще находишь зелья',req:2,cost:1,skill:'Алхимия'},
{id:'wanderer',name:'Странник',desc:'Путешествия тратят меньше выносливости',req:3,cost:2,skill:'Стрельба'}]
};
function treeUnlocked(id){return p.abilities.includes(id)}
function spendSkillPoint(treeId,nodeId){const tree=skillTrees[treeId]||[];const idx=tree.findIndex(n=>n.id===nodeId);const node=tree[idx];if(!node)return;if(treeUnlocked(node.id)){addLog('Эта способность уже изучена.','bad');renderProfile();return}if(p.skillPoints<node.cost){addLog('Недостаточно очков развития.','bad');renderProfile();return}if(idx>0 && !treeUnlocked(tree[idx-1].id)){addLog('Сначала изучи предыдущий узел ветки.','bad');renderProfile();return}p.skillPoints-=node.cost;p.abilities.push(node.id);p.skills[node.skill]=Math.min(100,(p.skills[node.skill]||0)+5);addLog(`✨ Изучено умение: ${node.name}.`,'good');save();renderProfile()}
function renderProfile(){const maxHp=heroMaxHp();const maxMp=heroMaxMp();const stats=Object.entries(p.skills).map(([k,v])=>`<div class="item"><span>${esc(k)}</span><span class="pill">${v}/100</span></div>`).join('');const trees=Object.entries(skillTrees).map(([name,nodes])=>`<section class="card" style="margin-top:12px"><h3>${name}</h3><div class="skilltree">${nodes.map((n,i)=>{const ok=treeUnlocked(n.id),can=i===0||treeUnlocked(nodes[i-1].id);return `<div class="skillnode ${ok?'learned':''} ${!ok&&!can?'locked':''}"><div class="skillnodeTop"><strong>${ok?'✓ ':''}${esc(n.name)}</strong><span class="pill">${n.cost} оч.</span></div><div class="muted">${esc(n.desc)}</div><div class="smallnote">Требование: ${i===0?'нет':esc(nodes[i-1].name)}</div>${ok?'<div class="skillLearned">ИЗУЧЕНО</div>':`<button class="btn small ${can?'cyan':''}" ${can?'':'disabled'} onclick="spendSkillPoint('${esc(name)}','${n.id}')">${can?'Изучить':'🔒 Заблокировано'}</button>`}</div>`}).join('')}</div></section>`).join('');main.innerHTML=`<section class="hero"><div class="title">ПРОФИЛЬ ГЕРОЯ</div><div class="subtitle">УРОВЕНЬ ${p.level} • ${esc(p.race)} • ${esc(p.trait)}</div><div class="profileHead"><div class="profileAvatar" style="overflow:hidden"><img src="heroes/${esc(p.heroPortrait||((heroPortraits[p.race]||['nord_1'])[0]))}.jpg" alt="Герой" style="width:100%;height:100%;object-fit:cover"></div><div><h3 style="margin:0">${esc(p.name||'Безымянный')}</h3><div class="muted">${esc(p.sign)} • ${p.age} лет</div><div class="notice" style="margin-top:8px">✨ Очки развития: <b>${p.skillPoints||0}</b></div></div></div></section><section class="card" style="margin-top:12px"><h3>Характеристики</h3>${stats}</section><section class="hero" style="margin-top:12px"><h3 style="margin:0 0 6px;color:#dfc58b">Ветки развития</h3><div class="muted">После каждого уровня ты получаешь 3 очка. Изучай узлы по порядку: следующий открывается только после предыдущего.</div></section>${trees}`}
function fresh(){return {name:'',race:'Норд',gender:'Мужской',age:25,trait:'Воин',sign:'Воин',origin:'Северные земли',past:'Воин',talent:'Крепкое тело',weakness:'Боязнь нежити',combatStyle:'Меч и щит',alignment:'Нейтральный',heroPortrait:'nord_1',attrPoints:{},attributes:{},characterCreated:false,baseSkillsApplied:false,level:1,xp:0,skillPoints:0,abilities:[],gold:100,hp:100,mp:50,st:100,loc:'Вайтран',skills:{'Одноручное оружие':20,'Блокирование':15,'Тяжёлая броня':15,'Скрытность':10,'Красноречие':10,'Стрельба':0,'Магия разрушения':0,'Взлом':0,'Алхимия':0,'Двуручное оружие':0},inv:[['Железный меч',1],['Железный щит',1],['Зелье лечения',2]],quests:{done:[],active:[]},crime:0,heat:0,guild:{companions:0,mages:0,thieves:0,dark:0,guards:0},guildRep:{companions:0,mages:0,thieves:0,dark:0,guards:0},guildTrial:null,ownedHouses:[],companions:[],log:['Ты прибываешь в Вайтран. Твоя история начинается.'],history:[],battle:null,dialogNpc:null,tradeNpc:null,dialogMsg:'',inspection:null};}
let p=JSON.parse(localStorage.getItem(KEY)||localStorage.getItem(OLD_KEY)||'null')||fresh();
if(p.skillPoints===undefined) p.skillPoints=0;
if(!Array.isArray(p.abilities)) p.abilities=[];
if(!p.guild) p.guild=fresh().guild;
if(!p.guildRep) p.guildRep={companions:0,mages:0,thieves:0,dark:0,guards:0};
if(p.guildTrial===undefined) p.guildTrial=null;
if(p.dialogMsg===undefined) p.dialogMsg='';
if(p.inspection===undefined) p.inspection=null;
if(p.attrPoints===undefined) p.attrPoints={};
if(!p.origin) p.origin='Северные земли';
if(!p.past) p.past='Воин';
if(!p.talent) p.talent='Крепкое тело';
if(!p.weakness) p.weakness='Боязнь нежити';
if(!p.combatStyle) p.combatStyle='Меч и щит';
if(!p.alignment) p.alignment='Нейтральный';
if(!p.heroPortrait) p.heroPortrait=(heroPortraits[p.race]||['nord_1'])[0];
if(!p.attributes) p.attributes={};
if(p.characterCreated===undefined) p.characterCreated=Boolean(p.name);
if(p.baseSkillsApplied===undefined) p.baseSkillsApplied=Boolean(p.name);
function save(){localStorage.setItem(KEY,JSON.stringify(p))}
function esc(s){return String(s).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]))}
function addLog(t,cls=''){p.log.unshift(t);p.log=p.log.slice(0,120);p.history.unshift({t,cls});p.history=p.history.slice(0,120);save()}
function xpNeed(){return 100+p.level*40}
function heroMaxHp(){let base=100+p.level*10+(p.attributes?.Выносливость||5)*2+(p.abilities.includes('survive')?15:0);if(p.talent==='Крепкое тело')base=Math.round(base*1.1);return base}
function heroMaxMp(){let base=50+(p.attributes?.Интеллект||5)*2+(p.attributes?.Воля||5);if(p.weakness==='Слабая магия')base-=10;if(p.abilities.includes('mana'))base+=10;return Math.max(20,base)}
function heroMaxSt(){let base=100+(p.attributes?.Выносливость||5)*2;if(p.weakness==='Плохая выносливость')base-=10;return Math.max(60,base)}
function gainXp(n){if(p.talent==='Быстрый ум')n=Math.ceil(n*1.1);p.xp+=n;while(p.xp>=xpNeed()){p.xp-=xpNeed();p.level++;p.skillPoints=(p.skillPoints||0)+3;p.hp=Math.min(heroMaxHp(),p.hp+10);p.mp=Math.min(heroMaxMp(),p.mp+5);p.st=Math.min(heroMaxSt(),p.st+5);addLog(`✨ Новый уровень! Теперь ты ${p.level}-го уровня. Получено 3 очка развития.`,'good')}}
function skill(name,delta){p.skills[name]=Math.min(100,(p.skills[name]||0)+delta);gainXp(Math.max(1,delta)*3)}
function addItem(name,n=1){let x=p.inv.find(v=>v[0]===name);if(x)x[1]+=n;else p.inv.push([name,n])}
function removeItem(name,n=1){let i=p.inv.findIndex(v=>v[0]===name);if(i<0)return false;if(p.inv[i][1]<n)return false;p.inv[i][1]-=n;if(p.inv[i][1]<=0)p.inv.splice(i,1);return true}
function travel(dest){if(!world[dest])return;p.loc=dest;p.st=Math.max(0,p.st-6);addLog(`🚶 Ты отправляешься в ${dest}.`,'info');randomEvent();renderWorld()}
function randomEvent(){let d=world[p.loc];if(!d)return;addLog(d.desc);if(Math.random()<.35){let gold=10+Math.floor(Math.random()*35);p.gold+=gold;gainXp(8);addLog(`Ты находишь ${gold} золотых.`,'good')}}
function inspectLocation(){const d=world[p.loc];if(!d)return;const people=d.npcs?.length||0;const vendors=d.npcs?.filter(n=>npcDb[n]?.vendor).length||0;const guards=d.npcs?.filter(n=>(npcDb[n]?.role||'').toLowerCase().includes('страж')).length||0;const placeTypes=['старую дорогу','скрытую тропу','следы костра','заброшенную постройку','следы недавнего боя','тайник торговцев'];const found=placeTypes[Math.floor(Math.random()*placeTypes.length)];p.inspection={text:`В ${p.loc} ты осматриваешься внимательнее. ${d.desc} Ты замечаешь ${found}.`,people,vendors,guards,places:2+Math.floor(Math.random()*3),time:['утро','день','вечер','ночь'][Math.floor(Math.random()*4)]};p.st=Math.max(0,p.st-2);addLog(`🔎 Ты осматриваешься в ${p.loc}.`,'info');save();renderWorld()}
function enemyIcon(enemy){const tones={'Бандит':'#8b4f55','Разбойник':'#7b4650','Волк':'#6d7e81','Скелет':'#b8b09c','Драугр':'#557c78','Ведьма':'#69557d','Наемник':'#576a7b','Пират':'#806548','Паукообразный жук':'#6e5a45','Лесной призрак':'#5c88a3','Медведь':'#765844'};const image=enemy.image||'bandit';return `<div class="portrait" style="border-color:${tones[enemy.name]||'#4f6870'}"><img src="enemies/${image}.jpg" alt="${esc(enemy.name)}" loading="lazy" style="width:100%;height:100%;object-fit:cover"></div>`}
function startBattle(enemyName){const e=enemyDb[enemyName]||enemyDb['Бандит'];p.battle={enemy:enemyName,hp:e.hp,maxHp:e.hp,round:1,poison:0,playerBlock:0,status:'В бою'};addLog(`⚔️ На тебя нападает ${enemyName}!`,'bad');showScreen('combat')}
function battleEnemy(){let e=enemyDb[p.battle.enemy]||enemyDb['Бандит']; return {...e,name:p.battle.enemy}}
function enemyTurn(){let e=battleEnemy();let dmg=4+Math.floor(Math.random()*7)+Math.floor(e.lvl/2);if(p.battle.enemy==='Волк')dmg+=2;if(p.battle.playerBlock){dmg=Math.max(0,Math.floor(dmg*(1-p.battle.playerBlock)));p.battle.playerBlock=0;addLog(`🛡️ Ты блокируешь часть удара: получаешь ${dmg} урона.`,'info')}else addLog(`${e.icon} ${p.battle.enemy} наносит тебе ${dmg} урона.`,'bad');p.hp-=dmg;if(Math.random()<.18){p.battle.poison=2;addLog('☠️ Тебя отравили.')}if(p.battle.poison>0){p.hp-=4;p.battle.poison--;addLog('Яд наносит 4 дополнительного урона.','bad')}}
function finishWin(){let e=battleEnemy();let gold=20+e.lvl*8+Math.floor(Math.random()*25);p.gold+=gold;gainXp(25+e.lvl*9);skill(e.type==='animal'?'Стрельба':'Одноручное оружие',1);e.loot.forEach(([name,ch])=>{if(Math.random()<ch && name!=='Золото')addItem(name)});addLog(`🏆 Победа! ${p.battle.enemy} повержен. Ты получаешь ${gold} золота.`,'good');p.battle=null;save();showScreen('world')}
function combatAction(kind){if(!p.battle)return;let e=battleEnemy();let damage=0;
if(kind==='attack'){p.battle.status='Ты атакуешь противника.';damage=9+Math.floor(Math.random()*7)+Math.floor(p.skills['Одноручное оружие']/8)+Math.floor((p.attributes?.Сила||5)/2);if(p.weakness==='Вспыльчивость')damage=Math.ceil(damage*1.05);p.battle.hp-=damage;skill('Одноручное оружие',1);p.st=Math.max(0,p.st-5);addLog(`⚔️ Ты наносишь ${damage} урона.`,'info')}
if(kind==='heavy'){p.battle.status='Ты готовишь мощный удар.';if(p.st<18){addLog('Не хватает выносливости.','bad');return}damage=16+Math.floor(Math.random()*10)+Math.floor(p.skills['Одноручное оружие']/7)+Math.floor((p.attributes?.Сила||5)/2);if(p.weakness==='Вспыльчивость')damage=Math.ceil(damage*1.05);p.battle.hp-=damage;p.st-=18;skill('Одноручное оружие',2);addLog(`💥 Сильный удар наносит ${damage} урона!`,'good')}
if(kind==='block'){p.battle.status='Ты готов блокировать следующий удар.';p.battle.playerBlock=.65;p.st=Math.max(0,p.st-4);skill('Блокирование',1);addLog('🛡️ Ты готовишься блокировать следующий удар.','info')}
if(kind==='spell'){p.battle.status='Ты используешь магию разрушения.';if(p.mp<15){addLog('Недостаточно магии.','bad');return}damage=18+Math.floor(Math.random()*9)+Math.floor(p.skills['Магия разрушения']/8);p.mp-=15;skill('Магия разрушения',1);p.battle.hp-=damage;addLog(`🔮 Заклинание разрушения наносит ${damage} урона.`,'good')}
if(kind==='potion'){p.battle.status='Ты восстанавливаешь здоровье зельем.';if(!removeItem('Зелье лечения')){addLog('Нет зелья лечения.','bad');return}p.hp=Math.min(heroMaxHp(),p.hp+45);addLog('🧪 Ты выпиваешь зелье лечения.','good')}
if(kind==='flee'){p.battle.status='Ты пытаешься отступить.';if(Math.random()<.55){addLog('🏃 Ты успешно отступаешь.','info');p.battle=null;showScreen('world');return}else addLog('❌ Отступить не удалось!','bad')}
if(p.battle.hp<=0){finishWin();return}
enemyTurn();p.battle.round++;p.battle.status=`Противник отвечает. Раунд ${p.battle.round}.`;if(p.hp<=0){p.hp=Math.max(35,Math.floor(heroMaxHp()*.45));p.loc='Вайтран';addLog(`☠️ Ты проиграл битву с ${p.battle.enemy} и очнулся у лекаря.`,'bad');p.battle=null;showScreen('world');return}save();renderCombat()}
function questForCity(){let d=world[p.loc];let q=d.quests[Math.floor(Math.random()*d.quests.length)]||'Случайное поручение';if(p.quests.active.includes(q)){addLog('У тебя уже есть это задание.');return}p.quests.active.push(q);addLog(`📜 Получено задание: «${q}».`,'good');renderQuests()}
function completeQuest(q){if(!p.quests.active.includes(q))return;let reward=40+Math.floor(Math.random()*80);p.quests.active=p.quests.active.filter(x=>x!==q);p.quests.done.push(q);p.gold+=reward;gainXp(35);addLog(`✅ Задание «${q}» выполнено. Награда: ${reward} золота.`,'good');renderQuests()}
function commitCrime(){p.crime++;p.heat+=2;p.gold+=50;skill('Скрытность',1);addLog('🗝️ Ты совершаешь мелкую кражу и получаешь 50 золота. Репутация ухудшается.','bad');if(p.heat>=6)addLog('🚨 Стража начинает тебя разыскивать!','bad');save()}
function payFine(){let fine=30+p.heat*20;if(p.gold<fine){addLog(`Недостаточно золота для штрафа (${fine}).`,'bad');return}p.gold-=fine;p.heat=0;p.crime=Math.max(0,p.crime-1);addLog(`⚖️ Ты уплатил штраф ${fine} золота. Розыск снят.`,'good');save();renderGuilds()}
function guildRank(id){return Number(p.guild[id]||0)}
function guildRepNeeded(rank){return rank<=0?3:rank*5+3}
function startGuildTrial(id){if(guildRank(id)>0){addLog(`🏰 Ты уже состоишь в гильдии «${guilds.find(g=>g.id===id).name}».`);renderGuilds();return}p.guildTrial={id,question:0,score:0};showScreen('guildTrial')}
function answerGuildTrial(choice){const t=p.guildTrial;if(!t)return;const pack=guildTrials[t.id];const q=pack.questions[t.question];if(choice===q[2]){t.score++;addLog(`✅ Испытание: верный ответ.`,'good')}else addLog(`❌ Испытание: ошибка. Нужно было действовать иначе.`,'bad');t.question++;if(t.question>=pack.questions.length){const g=guilds.find(x=>x.id===t.id);if(t.score>=2){p.guild[t.id]=1;p.guildRep[t.id]=0;addLog(`🏰 Испытание пройдено! Ты принят в гильдию «${g.name}» как «${guildRanks[t.id][0]}».`,'good')}else addLog(`❌ Ты провалил испытание гильдии «${g.name}». Нужно набрать минимум 2 из 3.`,'bad');p.guildTrial=null;save();showScreen('guilds');return}save();renderGuildTrial()}
function guildMission(id){if(guildRank(id)<=0){startGuildTrial(id);return}const g=guilds.find(x=>x.id===id);const reward=2+guildRank(id);p.guildRep[id]=(p.guildRep[id]||0)+reward;gainXp(12);addLog(`🏰 Выполнено гильдейское поручение: «${g.mission}». Репутация в гильдии +${reward}.`,'good');checkGuildPromotion(id);save();renderGuilds()}
function checkGuildPromotion(id){let r=guildRank(id),rep=p.guildRep[id]||0;if(r<=0)return;const need=guildRepNeeded(r);if(r<5&&rep>=need){p.guildRep[id]=rep-need;p.guild[id]=r+1;const rankName=guildRanks[id][r];addLog(`⭐ Повышение в гильдии «${guilds.find(g=>g.id===id).name}»! Новый ранг: «${rankName}». Открыто: ${guildUnlocks[id][r]}.`,'good')}}
function renderGuildTrial(){const t=p.guildTrial;if(!t){showScreen('guilds');return}const g=guilds.find(x=>x.id===t.id),q=guildTrials[t.id].questions[t.question],n=t.question+1;main.innerHTML=`<section class="hero"><div class="title">ИСПЫТАНИЕ ГИЛЬДИИ</div><div class="subtitle">${g.icon} ${esc(g.name)} • ШАГ ${n}/3</div><p style="line-height:1.55;color:#c7d3cf">${esc(g.trial)}</p></section><section class="card" style="margin-top:12px"><h3>${esc(q[0])}</h3>${q[1].map((a,i)=>`<button class="choice" onclick="answerGuildTrial(${i})">${i+1}. ${esc(a)}</button>`).join('')}<div class="notice" style="margin-top:12px">Правильных ответов: ${t.score}/3. Нужно минимум 2.</div></section><button class="btn" style="margin-top:12px" onclick="p.guildTrial=null;save();showScreen('guilds')">↩️ Отказаться от испытания</button>`}
function buyHouse(){let d=world[p.loc];if(!d.house){addLog('В этом месте нет подходящих домов.');return}if(p.ownedHouses.includes(p.loc)){addLog('Дом уже принадлежит тебе.');return}if(p.gold<d.house){addLog(`Не хватает ${d.house-p.gold} золота.`,'bad');return}p.gold-=d.house;p.ownedHouses.push(p.loc);addLog(`🏠 Ты покупаешь дом в ${p.loc} за ${d.house} золота.`,'good');save();renderWorld()}
function recruitNpc(name){if(p.companions.includes(name)){addLog('Этот спутник уже с тобой.');return}p.companions.push(name);addLog(`🤝 ${name} становится твоим спутником.`,'good');save();renderCompanions()}
function tradeBuy(item){let d=itemDb[item];if(!d)return;let price=d.price;if(p.gold<price){addLog('Недостаточно золота.','bad');return}p.gold-=price;addItem(item);addLog(`🛒 Ты покупаешь ${item} за ${price} золота.`,'good');save();renderTrade()}
function tradeSell(item){let d=itemDb[item];if(!d||!removeItem(item)){addLog('Этого предмета нет в инвентаре.');return}let price=Math.floor(d.price*.55);p.gold+=price;addLog(`💰 Ты продаешь ${item} за ${price} золота.`,'good');save();renderTrade()}
function castMagic(){if(p.mp<12){addLog('Недостаточно магии.','bad');return}p.mp-=12;skill('Магия разрушения',1);addLog('🔮 Ты тренируешь магию разрушения и создаешь искры льда.','good');save();renderMagic()}
function npcAction(n){p.dialogNpc=n;p.tradeNpc=null;p.dialogMsg='';showScreen('dialog')}
function npcTalk(n){const d=npcDb[n]||{about:'У этого человека пока нет подробной истории.'};p.dialogMsg=`${n}: ${d.about||'Человек внимательно смотрит на тебя.'}`;addLog(`💬 ${p.dialogMsg}`,'info');save()}
function npcRumor(n){const d=npcDb[n]||{};const r=(d.rumors&&d.rumors.length?d.rumors:['Ничего нового. Город живет своей жизнью.'])[Math.floor(Math.random()*(d.rumors?.length||1))];p.dialogMsg=`${n} делится слухом: «${r}»`;addLog(`👂 ${p.dialogMsg}`,'info');save()}
function npcQuest(n){const d=npcDb[n]||{};const pool=d.quests||[];if(!pool.length){p.dialogMsg=`${n}: Сейчас у меня нет работы для тебя.`;addLog(p.dialogMsg);save();return}const q=pool.find(q=>!p.quests.active.includes(q))||pool[0];if(p.quests.active.includes(q)){p.dialogMsg=`${n}: Ты уже взял задание «${q}».`;addLog(p.dialogMsg);save();return}p.quests.active.push(q);p.dialogMsg=`${n} поручает тебе: «${q}». Задание добавлено в журнал.`;addLog(`📜 ${p.dialogMsg}`,'good');save()}
function npcKey(n){return encodeURIComponent(String(n))}
function tradeWithNpc(n){if(!npcDb[n]?.vendor){addLog(`${n} ничего не продает.`);return}p.tradeNpc=n;showScreen('trade')}
function renderDialog(){const n=p.dialogNpc||'Житель';const d=npcDb[n]||{role:'Житель',about:'Местный житель.',rumors:[],quests:[]};const q=(d.quests||[]).map(x=>`<div class="item"><span>📜 ${esc(x)}</span><button class="pill" onclick="npcQuest(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">Взять</button></div>`).join('')||'<div class="muted">У этого NPC сейчас нет поручений.</div>';const rumors=(d.rumors||[]).slice(0,4).map(x=>`<div class="item"><span>👂 ${esc(x)}</span></div>`).join('')||'<div class="muted">Слухов пока нет.</div>';main.innerHTML=`<section class="hero"><div class="title">РАЗГОВОР</div><div class="subtitle">${esc(n)} • ${esc(d.role||'Житель')}</div></section><section class="card" style="margin-top:12px"><div class="entity"><div class="npc-portrait"><div style="width:100%;height:100%;display:grid;place-items:center;font-size:44px">${d.companion?'🤝':d.vendor?'🛒':'👤'}</div></div><div><h3 style="margin:0">${esc(n)}</h3><div class="muted">${esc(d.about||'')}</div>${d.vendor?'<span class="vendorTag" style="margin-top:6px">Торговец</span>':''}</div></div><div class="dialogBox notice" style="margin-top:12px">${esc(p.dialogMsg||'«Добрый день. Чем могу помочь?»')}</div><div class="dialog-actions" style="margin-top:12px"><button class="btn cyan" onclick="npcTalk(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">💬 Поговорить</button><button class="btn" onclick="npcRumor(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">👂 Спросить слухи</button>${d.vendor?`<button class="btn" onclick="tradeWithNpc(decodeURIComponent('${encodeURIComponent(n)}'))">🛒 Торговать</button>`:''}<button class="btn" onclick="npcQuest(decodeURIComponent('${encodeURIComponent(n)}'));renderDialog()">📜 Спросить о работе</button><button class="btn red" onclick="p.dialogNpc=null;p.dialogMsg='';showScreen('world')">↩️ Попрощаться</button></div></section><section class="card" style="margin-top:12px"><h3>Слухи</h3>${rumors}</section><section class="card" style="margin-top:12px"><h3>Доступные задания</h3>${q}</section><button class="btn" style="margin-top:12px" onclick="showScreen('world')">↩️ Вернуться в город</button>`}
let creatorTab=1;
function setCreatorTab(n){creatorTab=n;showCreate()}
function selectRace(r){p.race=r;if(!(heroPortraits[r]||[]).includes(p.heroPortrait))p.heroPortrait=heroPortraits[r][0];showCreate()}
function selectPortrait(k){p.heroPortrait=k;showCreate()}
function creatorOrigin(){return originOptions[p.origin||'Северные земли']||originOptions['Северные земли']}
function creatorPast(){return pastOptions[p.past||'Воин']||pastOptions['Воин']}
function creatorPersonality(){return personalityOptions[p.trait||'Воин']||personalityOptions['Воин']}
function creatorSign(){return signs[p.sign||'Воин']||signs['Воин']}
function creatorTalent(){return talents[p.talent||'Крепкое тело']||talents['Крепкое тело']}
function creatorWeakness(){return weaknesses[p.weakness||'Боязнь нежити']||weaknesses['Боязнь нежити']}
function creatorStyle(){return combatStyles[p.combatStyle||'Меч и щит']||combatStyles['Меч и щит']}
function creatorAlignment(){return alignments[p.alignment||'Нейтральный']||alignments['Нейтральный']}
function allocPointsTotal(){return Object.values(p.attrPoints||{}).reduce((a,b)=>a+b,0)}
function attrBase(k){return 5+(raceBonuses[p.race]?.[k]||0)+(creatorOrigin().bonus[k]||0)+(creatorPersonality().bonus[k]||0)+(creatorSign().bonus[k]||0)}
function attrValue(k){return attrBase(k)+(p.attrPoints?.[k]||0)}
function changeAttr(k,d){p.attrPoints=p.attrPoints||{};let cur=p.attrPoints[k]||0;let total=allocPointsTotal();if(d>0&&(cur>=10||total>=10))return;if(d<0&&cur<=0)return;p.attrPoints[k]=cur+d;showCreate()}
function applyCreation(){
  p.name=(document.getElementById('nm')?.value||p.name||'Безымянный').trim()||'Безымянный';
  p.attributes={};attrDefs.forEach(([k])=>p.attributes[k]=attrValue(k));
  p.origin=p.origin||'Северные земли';p.past=p.past||'Воин';p.trait=p.trait||'Воин';p.sign=p.sign||'Воин';p.talent=p.talent||'Крепкое тело';p.weakness=p.weakness||'Боязнь нежити';p.combatStyle=p.combatStyle||'Меч и щит';p.alignment=p.alignment||'Нейтральный';p.heroPortrait=p.heroPortrait||heroPortraits[p.race][0];
  if(!p.baseSkillsApplied){
    for(const src of [creatorOrigin().skills,creatorPast().skills,creatorStyle().skills]) for(const [k,v] of Object.entries(src||{})) p.skills[k]=(p.skills[k]||0)+v;
    p.baseSkillsApplied=true;
  }
  if(!p.characterCreated){
    creatorStyle().gear.forEach(x=>addItem(x[0],x[1]));addItem('Зелье лечения',2);p.characterCreated=true;
  }
  save();addLog('⚔️ Ты создал героя и выбрал свою судьбу.','good');showScreen('world')
}
function optionButtons(obj,current,field){return Object.keys(obj).map(k=>{const x=obj[k];return `<button class="miniChoice ${current===k?'active':''}" onclick="p.${field}=${JSON.stringify(k)};showCreate()"><span class="ic">${x.icon}</span>${esc(k)}</button>`}).join('')}
function showCreate(){
  p.attrPoints=p.attrPoints||{};p.origin=p.origin||'Северные земли';p.past=p.past||'Воин';p.trait=p.trait||'Воин';p.sign=p.sign||'Воин';p.talent=p.talent||'Крепкое тело';p.weakness=p.weakness||'Боязнь нежити';p.combatStyle=p.combatStyle||'Меч и щит';p.alignment=p.alignment||'Нейтральный';p.heroPortrait=p.heroPortrait||heroPortraits[p.race][0];
  const raceIcons={'Норд':'🏔️','Имперец':'🦅','Эльф':'🌿','Орк':'🔴','Каджит':'🐈'};
  const raceBtns=races.map(r=>`<button class="miniChoice ${p.race===r?'active':''}" onclick="selectRace(${JSON.stringify(r)})"><span class="ic">${raceIcons[r]}</span>${r}</button>`).join('');
  const portraits=(heroPortraits[p.race]||[]).map((k,i)=>`<button class="portraitChoice ${p.heroPortrait===k?'active':''}" onclick="selectPortrait('${k}')"><img src="heroes/${k}.jpg" alt="Иконка героя ${i+1}"></button>`).join('');
  const attrs=attrDefs.map(([k,ic])=>`<div class="attrRow"><span>${ic}</span><span>${k}</span><button class="minusBtn" onclick="changeAttr(${JSON.stringify(k)},-1)">−</button><span class="attrVal">${attrValue(k)}</span><button class="plusBtn" onclick="changeAttr(${JSON.stringify(k)},1)">+</button></div>`).join('');
  const tabs=['Внешность','Происхождение','Развитие','Итог'];
  let content='';
  if(creatorTab===1){
    content=`<div class="creatorGrid"><section class="card"><h3>Внешность</h3><div class="label">Раса</div><div class="choiceGrid">${raceBtns}</div><div class="label">Иконка героя • ${esc(p.race)}</div><div class="portraitGrid">${portraits}</div><div class="label">Имя</div><input id="nm" class="input" value="${esc(p.name)}" oninput="p.name=this.value" placeholder="Имя героя"><div class="label">Пол</div><div class="grid grid2"><button class="btn ${p.gender==='Мужской'?'cyan':''}" onclick="p.gender='Мужской';showCreate()">♂ Мужской</button><button class="btn ${p.gender==='Женский'?'cyan':''}" onclick="p.gender='Женский';showCreate()">♀ Женский</button></div><div class="label">Возраст: ${p.age}</div><input type="range" min="16" max="60" value="${p.age}" onchange="p.age=+this.value;showCreate()" style="width:100%"></section><section class="card"><h3>Характер</h3><div class="choiceGrid">${optionButtons(personalityOptions,p.trait,'trait')}</div><div class="smallnote" style="margin:6px 0 10px">${esc(creatorPersonality().desc)}</div><h3>Знак рождения</h3><div class="choiceGrid">${optionButtons(signs,p.sign,'sign')}</div><div class="smallnote" style="margin-top:6px">${esc(creatorSign().desc)}</div></section></div>`;
  } else if(creatorTab===2){
    content=`<div class="creatorGrid"><section class="card"><h3>Происхождение</h3><div class="choiceGrid">${optionButtons(originOptions,p.origin,'origin')}</div><div class="smallnote" style="margin-top:6px">${esc(creatorOrigin().desc)}</div><h3 style="margin-top:14px">Прошлое</h3><div class="choiceGrid">${optionButtons(pastOptions,p.past,'past')}</div><div class="smallnote" style="margin-top:6px">${esc(creatorPast().desc)}</div></section><section class="card"><h3>Талант</h3><div class="choiceGrid">${optionButtons(talents,p.talent,'talent')}</div><div class="notice" style="margin-top:7px">${esc(creatorTalent().desc)}</div><h3 style="margin-top:14px">Слабость</h3><div class="choiceGrid">${optionButtons(weaknesses,p.weakness,'weakness')}</div><div class="notice" style="margin-top:7px">${esc(creatorWeakness().desc)} ${esc(creatorWeakness().bonus)}</div></section></div>`;
  } else if(creatorTab===3){
    content=`<section class="card"><h3>Характеристики <span class="pill" style="float:right">${allocPointsTotal()}/10 очков</span></h3>${attrs}<div class="smallnote" style="margin-top:8px">База зависит от расы, происхождения, характера и знака рождения.</div></section><div class="creatorGrid" style="margin-top:10px"><section class="card"><h3>Стиль боя</h3><div class="choiceGrid">${optionButtons(combatStyles,p.combatStyle,'combatStyle')}</div><div class="smallnote">${esc(creatorStyle().desc)}</div></section><section class="card"><h3>Мировоззрение</h3><div class="choiceGrid">${optionButtons(alignments,p.alignment,'alignment')}</div><div class="smallnote">${esc(creatorAlignment().desc)}</div></section></div>`;
  } else {
    const summary=`<div class="summaryList"><div class="summaryItem"><b>Раса / пол</b>${esc(p.race)} • ${esc(p.gender)}</div><div class="summaryItem"><b>Возраст</b>${p.age}</div><div class="summaryItem"><b>Происхождение</b>${esc(p.origin)}</div><div class="summaryItem"><b>Прошлое</b>${esc(p.past)}</div><div class="summaryItem"><b>Характер / знак</b>${esc(p.trait)} • ${esc(p.sign)}</div><div class="summaryItem"><b>Талант</b>${esc(p.talent)}</div><div class="summaryItem"><b>Слабость</b>${esc(p.weakness)}</div><div class="summaryItem"><b>Стиль боя</b>${esc(p.combatStyle)}</div><div class="summaryItem"><b>Путь</b>${esc(p.alignment)}</div><div class="summaryItem"><b>Очки</b>${allocPointsTotal()}/10</div></div>`;
    content=`<section class="card"><div class="creatorSummary"><div class="portraitPreview"><img src="heroes/${esc(p.heroPortrait)}.jpg" alt="Герой"></div><div><h3 style="margin:0 0 5px">${esc(p.name||'Безымянный')}</h3><div class="smallnote">${esc(p.race)} • ${esc(p.combatStyle)} • ${esc(p.alignment)}</div><div class="notice" style="margin-top:8px">${esc(creatorTalent().desc)} ${esc(creatorWeakness().bonus)}</div></div></div><div class="summaryList" style="margin-top:12px">${summary}</div><div class="card" style="margin-top:10px"><h3>Стартовые характеристики</h3>${attrDefs.map(([k,ic])=>`<div class="item"><span>${ic} ${k}</span><span class="pill">${attrValue(k)}</span></div>`).join('')}</div><button class="btn cyan" style="margin-top:12px" onclick="applyCreation()">⚔️ НАЧАТЬ ПУТЬ</button></section>`;
  }
  main.innerHTML=`<section class="hero"><div class="title">СОЗДАНИЕ ГЕРОЯ</div><div class="subtitle">ШАГ ${creatorTab}/4 • КОМПАКТНАЯ НАСТРОЙКА ПЕРСОНАЖА</div><div class="creatorTabs">${tabs.map((n,i)=>`<button class="creatorTab ${creatorTab===i+1?'active':''}" onclick="setCreatorTab(${i+1})">${i+1}. ${n}</button>`).join('')}</div></section>${content}`;
}function renderSettings(){main.innerHTML=`<section class="card"><h3>Настройки и сохранение</h3><div class="item"><span>Персонаж</span><span class="pill">${esc(p.name||'Не создан')}</span></div><div class="item"><span>Локация</span><span class="pill">${esc(p.loc)}</span></div><div class="item"><span>Уровень</span><span class="pill">${p.level}</span></div><button class="btn cyan" onclick="save();alert('Игра сохранена')">💾 Сохранить игру</button><button class="btn" style="margin-top:8px" onclick="showScreen('create')">👤 Изменить героя</button><button class="btn" style="margin-top:8px" onclick="showScreen('guilds')">🏰 Гильдии</button><button class="btn" style="margin-top:8px" onclick="showScreen('companions')">🤝 Спутники</button><button class="btn" style="margin-top:8px" onclick="showScreen('magic')">🔮 Магия</button><button class="btn" style="margin-top:8px" onclick="showScreen('house')">🏠 Дома</button><button class="btn red" style="margin-top:8px" onclick="if(confirm('Удалить весь прогресс?')){localStorage.removeItem(KEY);p=fresh();showScreen('create')}">🗑️ Новая игра</button></section>`}
function showScreen(s){document.body.classList.toggle('combat-mode',s==='combat');document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.screen===s));if(s==='create')showCreate();else if(s==='world')renderWorld();else if(s==='map')renderMap();else if(s==='profile')renderProfile();else if(s==='skills')renderSkills();else if(s==='inv')renderInv();else if(s==='log')renderLog();else if(s==='combat')renderCombat();else if(s==='quests')renderQuests();else if(s==='guilds')renderGuilds();else if(s==='guildTrial')renderGuildTrial();else if(s==='trade')renderTrade();else if(s==='magic')renderMagic();else if(s==='house')renderHouse();else if(s==='companions')renderCompanions();else if(s==='dialog')renderDialog();else renderSettings()}
if(!p.name)showCreate();else renderWorld();
